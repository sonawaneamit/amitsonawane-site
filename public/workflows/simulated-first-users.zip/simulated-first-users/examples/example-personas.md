# Personas (EXAMPLE DATA)

| Persona | Device | Patience | Quits when |
|---|---|---|---|
| Impatient | Laptop, fast | 3 seconds | First error or a wait |
| Skeptic | Laptop | High | Price, trial end or data use is unclear |
| Mobile | 375 px, slow 3G | Medium | Button off-screen, text too small, page over 5 seconds |
| Non-native speaker | Laptop | Medium | A step depends on an idiom or jargon |
| Breaker | Laptop | High | Never; tries to break each step |
| Audience: owner, 60, first booking app | Tablet | Low | Asked to "connect a calendar" without being told why |
