# Friction list (EXAMPLE DATA)
Run 1: 2 of 5 personas reached first success. Median 14 steps.

| # | Issue | Where | Hit | Severity | Smallest fix |
|---|---|---|---|---|---|
| 1 | Card asked before the price is shown | /signup step 3 | 4/5 | 3 | Show price and trial end above the card field |
| 2 | "Sync availability" button meaning unclear | /onboarding/2 | 3/5 | 2 | Rename to "Pick the days you work" |
| 3 | Form clears after a validation error | /signup | 2/5 | 3 | Keep entered values; show error next to the field |
| 4 | Continue button below the fold on 375 px | /onboarding/3 | 1/5 | 3 | Sticky button at the bottom on mobile |
| 5 | Double-click on Pay creates 2 bookings | /book | 1/5 | 2 | Disable button after first click |

Run 2 after fixes: 5 of 5 reached first success. Median 9 steps. Issue 2 still confuses the non-native speaker: try "Choose your working days".
