# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-personas.md`: The 5 default personas plus one audience persona.
- `example-friction.md`: The merged, ranked friction list.
