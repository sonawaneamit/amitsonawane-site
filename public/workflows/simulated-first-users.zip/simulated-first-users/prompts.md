---
title: "Simulated first users: prompts"
slug: "simulated-first-users-prompts"
theme: "Validate before you build"
type: "prompts"
---

# Simulated first users: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the whole simulation

Paste with the skill loaded and a browser tool connected.

```text
Act as my launch QA lead. Use the simulated-first-users skill.

Start URL: {{url}}
First success: {{the moment a new user gets value}}
Test login or card: {{test details or "signup is free"}}
Extra persona: {{optional, from my real audience}}

Spin up the 5 personas. Each opens the app in a real browser, goes from the landing page to first success, and screenshots every moment it gets confused, stuck or annoyed. Merge everything into friction.md ranked by how many personas hit it. Then write fix-plan.md. Do not change code until I approve the plan.
```

## 2. Persona from my audience

Use to add a sixth, real-audience persona.

```text
Create a first-time-user persona for my product from this description of my customers: {{audience description}}.

Give it: name (first name only), age range, device, tech comfort (1-5), what they want in the first 5 minutes, what makes them quit, words they would not understand, and 5 rules it follows while testing. Write it in the same style as the 5 default personas.
```

## 3. No browser: screenshot review

Use when your agent cannot drive a browser. Attach screenshots of each step.

```text
Here are screenshots of every step from {{landing page}} to {{first success}}, in order.

Review them 5 times, once as each persona in the simulated-first-users skill. For each persona, list each step where they would be confused, slowed down or quit, with severity 1-3 and the screenshot number. Then merge into one friction list ranked by how many personas hit each issue.
```

## 4. Rerun and compare

After fixes ship to staging.

```text
Rerun the same 5 personas on {{url}} with fresh sessions and the same first success.
Compare with friction.md from the last run: fixed, still there, new. Report success count before vs after and median steps to success.
```
