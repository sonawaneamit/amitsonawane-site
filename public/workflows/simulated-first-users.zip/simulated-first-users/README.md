---
title: "Simulated first users"
slug: "simulated-first-users"
theme: "Validate before you build"
theme_slug: "validate-before-you-build"
theme_order: 3
order: 11
summary: "Before a launch, send 5 agent personas through your product in a real browser, from landing page to first success. Get one ranked list of where people get stuck, fix it, and rerun."
---

# Simulated first users

Before a launch, send 5 agent personas through your product in a real browser, from landing page to first success. Get one ranked list of where people get stuck, fix it, and rerun.

| | |
|---|---|
| Theme | Validate before you build |
| Time | 30 to 90 minutes per run |
| Works with | Agents that can drive a browser (a browser tool or browser automation such as Playwright). Without one, it runs on screenshots and page text. |
| You get | A ranked friction list with screenshots, a fix plan, and a before/after rerun |

## When to use it

- A launch, a new signup flow or a new onboarding is days away.
- Real users drop off and nobody can say where.
- You changed the product a lot and want a fresh pair of eyes.

## What you get

- `personas.md`: the 5 users, their goal and their rules.
- `runs/{{persona}}.md`: each user's step-by-step path with screenshots of every stuck moment.
- `friction.md`: one merged list ranked by how many users hit each issue and how badly.
- `fix-plan.md` and a rerun report that shows what is fixed.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Start URL | https://staging.example.com | Yes |
| First success | Booked first appointment with a deposit | Yes |
| Test account or card | Test-mode card, a disposable inbox | If signup needs it |
| Personas | The default 5 or your own | Optional |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Define first success.** The one moment a new user gets value. Every persona tries to reach it.
2. **Spin up 5 personas.** Each a subagent with its own rules, device size and patience.
3. **Run in a browser.** Landing page to first success. Screenshot each moment of confusion, error or doubt.
4. **Merge and rank.** One list, ranked by how many personas hit it and how bad it was.
5. **Fix in one pass.** Copy, layout, errors, speed. Smallest fix that removes the issue.
6. **Rerun.** Same 5 personas, same goal. Prove each fix worked.

## Copy-paste prompts

### 1. Run the whole simulation

Paste with the skill loaded and a browser tool connected.

```text
Act as my launch QA lead. Use the simulated-first-users skill.

Start URL: {{url}}
First success: {{the moment a new user gets value}}
Test login or card: {{test details or "signup is free"}}
Extra persona: {{optional, from my real audience}}

Spin up the 5 personas. Each opens the app in a real browser, goes from the landing page to first success, and screenshots every moment it gets confused, stuck or annoyed. Merge everything into friction.md ranked by how many personas hit it. Then write fix-plan.md. Do not change code until I approve the plan.
```

### 2. Persona from my audience

Use to add a sixth, real-audience persona.

```text
Create a first-time-user persona for my product from this description of my customers: {{audience description}}.

Give it: name (first name only), age range, device, tech comfort (1-5), what they want in the first 5 minutes, what makes them quit, words they would not understand, and 5 rules it follows while testing. Write it in the same style as the 5 default personas.
```

### 3. No browser: screenshot review

Use when your agent cannot drive a browser. Attach screenshots of each step.

```text
Here are screenshots of every step from {{landing page}} to {{first success}}, in order.

Review them 5 times, once as each persona in the simulated-first-users skill. For each persona, list each step where they would be confused, slowed down or quit, with severity 1-3 and the screenshot number. Then merge into one friction list ranked by how many personas hit each issue.
```

### 4. Rerun and compare

After fixes ship to staging.

```text
Rerun the same 5 personas on {{url}} with fresh sessions and the same first success.
Compare with friction.md from the last run: fixed, still there, new. Report success count before vs after and median steps to success.
```

## Scoring rubric

Rank = personas hit (out of 5) x worst severity.

| Severity | Meaning | Example |
|---|---|---|
| 1 | Annoyed, kept going | Vague button label |
| 2 | Slowed down, had to think or retry | Error shown only after submit, form cleared |
| 3 | Would quit | Payment page asks for a card before saying the price |

Launch gate: no severity-3 issue hit by 2+ personas, and at least 4 of 5 personas reach first success.

## Templates

**Run log line**

`| step | sees | expects | does | result | severity | screenshot |`

**Friction list row**

`| # | issue | where | personas hit | worst severity | screenshot | smallest fix |`

## Example files

Invented data that shows the format of each input and output.

- `examples/example-personas.md`: The 5 default personas plus one audience persona.
- `examples/example-friction.md`: The merged, ranked friction list.

## Troubleshooting and tips

- **The agent cannot open a browser.** Connect a browser tool or browser automation (Playwright and Chrome DevTools both have agent integrations), or use the screenshot prompt.
- **Personas all report the same thing.** Make the rules stricter and more different. The impatient one must quit at the first error; the breaker must try every field.
- **Signup needs email verification.** Give the agent a disposable test inbox it can read, or a staging flag that skips verification.
- **Payments.** Use your payment tool's test mode and its test card numbers only.
- **Too many small issues.** Fix every severity 3 first, then anything hit by 3+ personas. Leave the rest for later.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
