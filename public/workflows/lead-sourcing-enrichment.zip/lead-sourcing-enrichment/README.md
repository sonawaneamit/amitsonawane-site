---
title: "Lead sourcing and enrichment"
slug: "lead-sourcing-enrichment"
theme: "Find and reach customers"
theme_slug: "find-and-reach-customers"
theme_order: 4
order: 12
summary: "Build a small, accurate list of the right companies and people from public sources, add a reason to contact each one, clean and score it, and hand it to outreach."
---

# Lead sourcing and enrichment

Build a small, accurate list of the right companies and people from public sources, add a reason to contact each one, clean and score it, and hand it to outreach.

| | |
|---|---|
| Theme | Find and reach customers |
| Time | 2 to 4 hours for the first 200 leads |
| Works with | Any agent with web browsing. A spreadsheet. Optional: a data provider or enrichment tool you already pay for. |
| You get | A deduped, scored lead list where every row has a source and a reason to reach out |

## When to use it

- You sell to businesses and need a first list of 100 to 500 accounts.
- Your current list is big, stale and gets few replies.
- You want outreach that starts from a real reason, not a blast.

## What you get

- `icp.md` and `icp.json`: who fits, in words and as scoring rules.
- `leads_scored.csv`: one row per contact with source, signal, score and tier.
- A short note on which sources gave the best rows.

## Inputs

| Input | Example | Needed |
|---|---|---|
| What you sell and to whom | Booking app for mobile groomers | Yes |
| Best current customers | 5-10 examples, or a description | Yes |
| Regions and size | US + Canada, 1-50 staff | Yes |
| Tools you already have | A data provider, a CRM, nothing | Optional |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Write the ICP.** Firmographics, role, must-have and disqualifiers, signals.
2. **Pick sources.** Where these companies are listed in public.
3. **Pull accounts.** Company, domain, size, location, source URL.
4. **Find people.** The role that buys, with a work contact.
5. **Add signals.** A dated, specific reason to contact now.
6. **Clean and score.** Dedupe, domain check, ICP score, tier.

## Copy-paste prompts

### 1. Write my ICP

Start here.

```text
Use the lead-sourcing-enrichment skill.
I sell {{product}} at {{price}}. My best customers are: {{list or describe 5-10}}.
Regions: {{regions}}. Size: {{size}}.
Write icp.md (firmographics, buyer, must-haves, disqualifiers, signals) and icp.json scoring rules. Ask me up to 5 questions if something is unclear.
```

### 2. Build the list

After the ICP is approved.

```text
Use the lead-sourcing-enrichment skill with icp.md.
Target: {{n}} tier A leads. Sources to use: {{sources or "suggest 3 and wait for OK"}}.
Fill the output columns. Every row needs source_url and found_on. Signals need a date and link. Do not guess emails; use contact_route when no work email is public. Then run dedupe, mx and score, and show me the top 20 and bottom 20.
```

### 3. Find signals for an existing list

When you already have accounts.

```text
Here is a list of companies: {{paste or attach}}.
For each, look for one dated signal from the last 90 days that matches: {{signal types from icp.md}}. Return company, signal (one line), date, source link. Leave blank if nothing is found; do not stretch.
```

## Scoring rubric

**Row quality check (sample 20 rows)**

| Check | Pass |
|---|---|
| Has source_url and found_on | 100% |
| Company matches ICP must-haves | 90%+ |
| Contact is the buyer role | 80%+ |
| Tier A rows have a dated signal under 90 days | 100% |
| Email domain has MX, or a contact_route is given | 100% |
| No duplicates | 100% |

## Templates

**icp.json**

```json
{"rules": [
  {"column": "employees", "op": "between", "value": [2, 200], "points": 25},
  {"column": "industry", "op": "in", "value": ["veterinary", "pet services"], "points": 25},
  {"column": "title", "op": "contains_any", "value": ["owner", "founder", "manager"], "points": 20},
  {"column": "country", "op": "in", "value": ["US", "CA"], "points": 10},
  {"column": "signal", "op": "not_empty", "points": 20}
],
"tiers": {"A": 70, "B": 45}}
```

Operators: `between`, `in`, `contains_any`, `not_empty`, `equals`. Rows below tier B are tier C.

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`lead_tools.py` has three commands. Each writes `<input>_<command>.csv`.

```bash
python3 scripts/lead_tools.py dedupe leads.csv
python3 scripts/lead_tools.py mx leads_dedupe.csv
python3 scripts/lead_tools.py score leads_dedupe.csv icp.json
```

`mx` uses a public DNS-over-HTTPS resolver, so it needs internet access.

## Example files

Invented data that shows the format of each input and output.

- `examples/example-leads.csv`: A raw list with one duplicate. All companies, people and domains are made up.
- `examples/example-icp.json`: The scoring rules used.
- `examples/example-leads_dedupe_score.csv`: Real output after dedupe and score.
- `examples/example-notes.md`: What to read from the output.

## Troubleshooting and tips

- **Score order looks wrong.** Change point weights in icp.json and rescore. Do not hand-edit scores.
- **A source blocks the agent.** Use the site's export or API, a provider you pay for, or a signed-in browser session you control, within the site's terms. Do not bypass blocks.
- **Too few signals.** Widen the window to 180 days, or add a signal type (job posts usually have the most).
- **mx says ok but emails bounce.** MX only proves the domain takes mail. Run a mailbox verification service before volume sends.
- **Huge list, low quality.** Cut to tier A only and write better reasons. 100 good rows beat 2,000 weak ones.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `lead_tools.py`
