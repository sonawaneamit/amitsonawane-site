---
title: "Lead sourcing and enrichment: prompts"
slug: "lead-sourcing-enrichment-prompts"
theme: "Find and reach customers"
type: "prompts"
---

# Lead sourcing and enrichment: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Write my ICP

Start here.

```text
Use the lead-sourcing-enrichment skill.
I sell {{product}} at {{price}}. My best customers are: {{list or describe 5-10}}.
Regions: {{regions}}. Size: {{size}}.
Write icp.md (firmographics, buyer, must-haves, disqualifiers, signals) and icp.json scoring rules. Ask me up to 5 questions if something is unclear.
```

## 2. Build the list

After the ICP is approved.

```text
Use the lead-sourcing-enrichment skill with icp.md.
Target: {{n}} tier A leads. Sources to use: {{sources or "suggest 3 and wait for OK"}}.
Fill the output columns. Every row needs source_url and found_on. Signals need a date and link. Do not guess emails; use contact_route when no work email is public. Then run dedupe, mx and score, and show me the top 20 and bottom 20.
```

## 3. Find signals for an existing list

When you already have accounts.

```text
Here is a list of companies: {{paste or attach}}.
For each, look for one dated signal from the last 90 days that matches: {{signal types from icp.md}}. Return company, signal (one line), date, source link. Leave blank if nothing is found; do not stretch.
```
