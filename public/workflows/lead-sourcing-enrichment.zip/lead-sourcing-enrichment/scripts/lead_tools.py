#!/usr/bin/env python3
"""Lead list hygiene and ICP scoring. Standard library only.

Commands:
  dedupe   merge rows with the same email or the same company domain + name
  mx       check each email's domain has mail servers (DNS-over-HTTPS lookup).
           This catches dead and mistyped domains. It does not prove a mailbox
           exists; use a verification service for that.
  score    score each row against your ICP rules in icp.json, sort high to low

Usage:
  python3 lead_tools.py dedupe leads.csv
  python3 lead_tools.py mx leads.csv
  python3 lead_tools.py score leads.csv icp.json
Each command writes <input>_<command>.csv.

icp.json example:
  {"rules": [
     {"column": "employees", "op": "between", "value": [5, 200], "points": 25},
     {"column": "industry", "op": "in", "value": ["veterinary", "pet services"], "points": 25},
     {"column": "title", "op": "contains_any", "value": ["owner", "founder", "manager"], "points": 20},
     {"column": "country", "op": "in", "value": ["US", "CA"], "points": 10},
     {"column": "signal", "op": "not_empty", "points": 20}
   ],
   "tiers": {"A": 70, "B": 45}}
"""
import csv, json, sys, time, urllib.request

def read(path):
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.DictReader(f))
    return rows, (list(rows[0].keys()) if rows else [])

def write(path, rows, cols):
    with open(path, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=cols); w.writeheader(); w.writerows(rows)
    print(f"wrote {len(rows)} rows -> {path}")

def get(row, *names):
    for n in names:
        for k in row:
            if k.strip().lower() == n:
                return (row[k] or "").strip()
    return ""

def dedupe(path):
    rows, cols = read(path)
    seen, out = set(), []
    for r in rows:
        email = get(r, "email").lower()
        domain = email.split("@")[-1] if "@" in email else get(r, "domain", "website").lower()
        name = (get(r, "first_name", "first name") + get(r, "last_name", "last name") or get(r, "name")).lower()
        key = email or f"{domain}|{name}"
        if key and key not in seen:
            seen.add(key); out.append(r)
    print(f"removed {len(rows) - len(out)} duplicates")
    write(path.replace(".csv", "_dedupe.csv"), out, cols)

def mx(path):
    rows, cols = read(path)
    cache = {}
    for r in rows:
        email = get(r, "email").lower()
        dom = email.split("@")[-1] if "@" in email else ""
        if dom and dom not in cache:
            try:
                url = f"https://dns.google/resolve?name={dom}&type=MX"
                with urllib.request.urlopen(url, timeout=15) as resp:
                    ans = json.loads(resp.read()).get("Answer", [])
                cache[dom] = "ok" if any(a.get("type") == 15 for a in ans) else "no_mx"
            except Exception:
                cache[dom] = "error"
            time.sleep(0.2)
        r["mx_status"] = cache.get(dom, "no_email")
    write(path.replace(".csv", "_mx.csv"), rows, cols + ["mx_status"])

def test(rule, val):
    op, target = rule["op"], rule.get("value")
    v = val.lower()
    if op == "not_empty":
        return bool(v)
    if op == "in":
        return v in [str(t).lower() for t in target]
    if op == "contains_any":
        return any(str(t).lower() in v for t in target)
    if op == "between":
        try:
            return target[0] <= float(v.replace(",", "")) <= target[1]
        except ValueError:
            return False
    if op == "equals":
        return v == str(target).lower()
    raise ValueError(f"unknown op {op}")

def score(path, icp_path):
    rows, cols = read(path)
    icp = json.load(open(icp_path, encoding="utf-8"))
    tiers = icp.get("tiers", {"A": 70, "B": 45})
    for r in rows:
        pts, why = 0, []
        for rule in icp["rules"]:
            if test(rule, get(r, rule["column"].lower())):
                pts += rule["points"]; why.append(rule["column"])
        r["icp_score"] = pts
        r["icp_tier"] = "A" if pts >= tiers["A"] else "B" if pts >= tiers["B"] else "C"
        r["icp_matched"] = " ".join(why)
    rows.sort(key=lambda r: r["icp_score"], reverse=True)
    write(path.replace(".csv", "_score.csv"), rows, cols + ["icp_score", "icp_tier", "icp_matched"])

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    {"dedupe": lambda: dedupe(a[1]), "mx": lambda: mx(a[1]), "score": lambda: score(a[1], a[2])}[a[0]]()
