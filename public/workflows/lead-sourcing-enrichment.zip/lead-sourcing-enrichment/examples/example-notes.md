# Notes (EXAMPLE DATA)

- The duplicate Paws on Wheels row was merged; the version with a signal was kept.
- Fluffy Mobile Spa uses a free-mail address. It is the business's public address, so it stays, flagged in notes.
- Big Box Pets is tier C (too large, wrong industry). Dropped.
- The mx check marks the example.* domains as no_mx because they are reserved test domains. On real data, no_mx means fix or drop the row.
