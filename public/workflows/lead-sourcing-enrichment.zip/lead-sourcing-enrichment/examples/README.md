# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-leads.csv`: A raw list with one duplicate. All companies, people and domains are made up.
- `example-icp.json`: The scoring rules used.
- `example-leads_dedupe_score.csv`: Real output after dedupe and score.
- `example-notes.md`: What to read from the output.
