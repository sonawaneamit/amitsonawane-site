#!/usr/bin/env python3
"""Find internal-link opportunities in a folder of markdown or HTML files.
Standard library only.

Input: targets.csv with columns url, anchor (the query you want that page to
rank for; add several rows per URL for variants), and a content folder.
For every file, finds plain-text mentions of each anchor that are not already
inside a link, not in a heading, and not in the page that is the target.

Output: link_suggestions.csv (source_file, line, anchor, target_url, context).
Review it, approve rows, then apply max 3-5 new links per source page.

Usage:
  python3 internal_links.py targets.csv content_dir [--site-prefix https://www.example.com]
"""
import csv, os, re, sys

def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    targets_csv, folder = sys.argv[1], sys.argv[2]
    prefix = sys.argv[sys.argv.index("--site-prefix") + 1] if "--site-prefix" in sys.argv else ""
    targets = list(csv.DictReader(open(targets_csv, newline="", encoding="utf-8")))
    out, per_file = [], {}
    for dirpath, _, files in os.walk(folder):
        for name in files:
            if not name.endswith((".md", ".mdx", ".html", ".htm", ".astro")):
                continue
            path = os.path.join(dirpath, name)
            rel = os.path.relpath(path, folder)
            text = open(path, encoding="utf-8", errors="replace").read()
            for i, line in enumerate(text.splitlines(), 1):
                if re.match(r"\s*(#|<h[1-6])", line):
                    continue
                clean = re.sub(r"\[[^\]]*\]\([^)]*\)|<a\b.*?</a>", " ", line)
                for t in targets:
                    url, anchor = t["url"].strip(), t["anchor"].strip()
                    slug = url.replace(prefix, "").strip("/").split("/")[-1]
                    if slug and slug in rel:
                        continue  # never link a page to itself
                    path_only = url.replace(prefix, "") if prefix else url
                    if url in text or f"({path_only})" in text or f'"{path_only}"' in text:
                        continue  # page already links to the target
                    m = re.search(r"\b" + re.escape(anchor) + r"\b", clean, re.I)
                    if m and per_file.get(rel, 0) < 5:
                        per_file[rel] = per_file.get(rel, 0) + 1
                        ctx = clean[max(0, m.start() - 60): m.end() + 60].strip()
                        out.append([rel, i, m.group(0), url, ctx])
    with open("link_suggestions.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["source_file", "line", "anchor", "target_url", "context"]); w.writerows(out)
    print(f"{len(out)} suggestions in {len(per_file)} files -> link_suggestions.csv")

if __name__ == "__main__":
    main()
