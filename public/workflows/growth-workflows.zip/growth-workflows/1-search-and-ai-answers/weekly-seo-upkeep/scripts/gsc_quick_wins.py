#!/usr/bin/env python3
"""Weekly quick wins from Search Console data. Standard library only.

Input: a CSV with columns for query, clicks, impressions, CTR and position.
Works with the Performance report export (Queries.csv) and with API exports
that also have a page column (query + page is best: it tells you which page
to fix). Column names are matched loosely ("Top queries", "Query", "query").

Output: quick_wins.md with three lists
  1. Striking distance: position 4 to 20 with real impressions (push these)
  2. Low CTR for the position: rewrite title and description
  3. Pages with many striking-distance queries: add internal links to them

Usage:
  python3 gsc_quick_wins.py Queries.csv [--min-impr 100]
"""
import csv, sys
from collections import defaultdict

# Rough organic CTR by position. Use as a floor, not a fact: real CTR varies by
# query type and by how many ads and AI answers sit above the results.
EXPECTED_CTR = {1: 0.25, 2: 0.13, 3: 0.09, 4: 0.06, 5: 0.045, 6: 0.035, 7: 0.03,
                8: 0.025, 9: 0.02, 10: 0.018}

def col(row, *names):
    for k in row:
        kk = k.strip().lower()
        if any(kk == n or kk.endswith(n) for n in names):
            return row[k]
    return ""

def num(s):
    s = (s or "").replace(",", "").replace("%", "").strip()
    return float(s) if s else 0.0

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    min_impr = int(sys.argv[sys.argv.index("--min-impr") + 1]) if "--min-impr" in sys.argv else 100
    rows = []
    with open(sys.argv[1], newline="", encoding="utf-8-sig") as f:
        for r in csv.DictReader(f):
            ctr_raw = col(r, "ctr")
            ctr = num(ctr_raw) / 100 if "%" in ctr_raw or num(ctr_raw) > 1 else num(ctr_raw)
            rows.append({"query": col(r, "queries", "query"), "page": col(r, "pages", "page"),
                         "clicks": num(col(r, "clicks")), "impr": num(col(r, "impressions")),
                         "ctr": ctr, "pos": num(col(r, "position"))})
    striking = sorted([r for r in rows if 4 <= r["pos"] <= 20 and r["impr"] >= min_impr],
                      key=lambda r: r["impr"], reverse=True)
    low_ctr = []
    for r in rows:
        p = round(r["pos"])
        if 1 <= p <= 10 and r["impr"] >= min_impr and r["ctr"] < EXPECTED_CTR[p] * 0.6:
            gap = int(r["impr"] * EXPECTED_CTR[p] - r["clicks"])
            low_ctr.append({**r, "gap": gap})
    low_ctr.sort(key=lambda r: r["gap"], reverse=True)
    by_page = defaultdict(list)
    for r in striking:
        if r["page"]:
            by_page[r["page"]].append(r)

    out = ["# Search quick wins", "", f"Rows read: {len(rows)}. Minimum impressions: {min_impr}.", "",
           "## 1. Striking distance (position 4-20)", "",
           "| Query | Page | Impressions | Clicks | Position |", "|---|---|---|---|---|"]
    out += [f"| {r['query']} | {r['page'] or '-'} | {int(r['impr'])} | {int(r['clicks'])} | {r['pos']:.1f} |" for r in striking[:40]]
    out += ["", "## 2. Low CTR for the position (rewrite title and meta description)", "",
            "| Query | Page | Position | CTR | Clicks missed (est.) |", "|---|---|---|---|---|"]
    out += [f"| {r['query']} | {r['page'] or '-'} | {r['pos']:.1f} | {r['ctr']*100:.1f}% | {r['gap']} |" for r in low_ctr[:25]]
    out += ["", "## 3. Pages to link to (most striking-distance queries)", "",
            "| Page | Queries in 4-20 | Total impressions | Best anchor candidates |", "|---|---|---|---|"]
    for page, qs in sorted(by_page.items(), key=lambda kv: sum(q["impr"] for q in kv[1]), reverse=True)[:20]:
        anchors = ", ".join(q["query"] for q in sorted(qs, key=lambda q: q["impr"], reverse=True)[:3])
        out.append(f"| {page} | {len(qs)} | {int(sum(q['impr'] for q in qs))} | {anchors} |")
    if not by_page:
        out.append("| (export has no page column: use query + page data to fill this list) | | | |")
    open("quick_wins.md", "w", encoding="utf-8").write("\n".join(out) + "\n")
    print(f"striking: {len(striking)}, low CTR: {len(low_ctr)}, pages: {len(by_page)} -> quick_wins.md")

if __name__ == "__main__":
    main()
