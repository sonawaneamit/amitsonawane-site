---
title: "Weekly SEO upkeep loop"
slug: "weekly-seo-upkeep"
theme: "Get found in search and AI answers"
theme_slug: "search-and-ai-answers"
theme_order: 1
order: 5
summary: "A one-hour weekly routine on Search Console data: push pages sitting in positions 4 to 20, rewrite titles with low click-through, add internal links, and refresh facts on pages that already rank."
---

# Weekly SEO upkeep loop

A one-hour weekly routine on Search Console data: push pages sitting in positions 4 to 20, rewrite titles with low click-through, add internal links, and refresh facts on pages that already rank.

| | |
|---|---|
| Theme | Get found in search and AI answers |
| Time | About 1 hour a week |
| Works with | Any agent. Best with a Search Console connection or export and edit access to the site (CMS, repo or a connector). |
| You get | A weekly quick-wins list, approved title and link changes, and a changelog |

## When to use it

- Your site gets at least a few hundred search impressions a week.
- You publish content but rarely update old pages.
- You want steady search gains without writing new posts every week.

## What you get

- `quick_wins.md`: striking-distance queries, low-CTR pages and pages to link to.
- `changes-{{date}}.md`: proposed title, meta, refresh and link changes for your OK.
- `changelog.md`: what changed, where and when, so you can read results later.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Search Console data | Last 28 days, query + page | Yes |
| Site content | Repo folder, CMS access, or page URLs | Yes |
| Last week's changelog | changelog.md | After week 1 |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Compare last week.** Check pages changed last week against the period before.
2. **Pull data.** Last 28 days of queries and pages from Search Console.
3. **Find quick wins.** Positions 4 to 20 with impressions, low CTR for the position, pages with many near-miss queries.
4. **Propose changes.** Titles, descriptions, internal links, content refresh. Show a table and wait for OK.
5. **Apply and log.** Make approved edits, max 3 to 5 new internal links per page, log every change.

## Copy-paste prompts

### 1. Run this week's loop

Paste with the skill loaded. Attach the Search Console export.

```text
Use the weekly-seo-upkeep skill.

Site: {{site}}
Search Console export (query + page, last 28 days): {{attached}}
Content: {{repo folder | CMS connector | list of URLs}}
Last week's changelog: {{attached or "first week"}}

Compare last week's changes first. Then build quick_wins.md and changes-{{date}}.md. Show me the tables and wait for my OK before editing anything.
```

### 2. Rewrite low-CTR titles

Paste the low-CTR rows.

```text
These pages get impressions but few clicks for their main query: {{paste rows: page, query, position, CTR, current title, current description}}.
For each, write 3 title options (under 60 characters, query words early, a specific benefit or number) and 1 description (about 150 characters, answer + reason to click). Promise nothing the page does not deliver.
```

### 3. Internal link pass

Paste link_suggestions.csv or page texts.

```text
Here are internal link candidates: {{paste}}.
Keep at most 3-5 new links per source page. Drop any candidate where the anchor is in a heading, the first sentence, an existing link, or reads unnaturally. Return the final table: source page, exact sentence with the link added, target page, target query.
```

### 4. Refresh a page

Paste the page and its striking-distance queries.

```text
Page: {{url}}. Text: {{paste}}. Queries it ranks 4-20 for: {{queries}}.
Propose a refresh: claims that need a source (list each), a new section or FAQ that covers missing queries (write it), numbers to add, and a new intro that answers the main query in the first 2 sentences. Mark every change so I can review it.
```

## Scoring rubric

**Weekly checklist**

- [ ] Last week's changed pages compared (7-14 days before vs after)
- [ ] Up to 10 striking-distance pages reviewed
- [ ] Up to 5 title and description rewrites proposed
- [ ] Internal links proposed (max 3-5 per source page)
- [ ] Changes approved before editing
- [ ] Changelog updated

**Reading results** after 2+ weeks, on the target query: position up and CTR flat = keep, then work on the title. CTR up and position flat = keep. Both down for 2+ weeks = revert from the changelog.

## Templates

**changelog.md row**

`| 2026-11-10 | /blog/grooming-prices | title | "Dog grooming prices" | "Mobile dog grooming prices in 2026: $70-$140 by size" | mobile dog grooming prices | pos 6.2, CTR 1.8% |`

**Search Console API request body**

```json
{"startDate": "2026-10-13", "endDate": "2026-11-09", "dimensions": ["query", "page"], "rowLimit": 25000}
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`gsc_quick_wins.py` reads a Search Console CSV (query, optional page, clicks, impressions, CTR, position) and writes `quick_wins.md`.

```bash
python3 scripts/gsc_quick_wins.py Queries.csv --min-impr 100
```

`internal_links.py` finds plain-text mentions of target anchors in markdown or HTML files that are not linked yet, skipping headings, self-links and pages that already link to the target, and writes `link_suggestions.csv`.

```bash
python3 scripts/internal_links.py targets.csv ./content --site-prefix https://www.example.com
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-gsc-export.csv`: A query + page export.
- `examples/example-targets.csv`: Targets for the internal link script.
- `examples/example-quick_wins.md`: Output of gsc_quick_wins.py for the export above.
- `examples/example-changes.md`: A proposed change table waiting for approval.

## Troubleshooting and tips

- **The export has no page column.** The web Queries table has none. Use the API with dimensions query and page, or a connector.
- **Small site, few rows.** Lower `--min-impr` to 20 and use 3 months of data.
- **A change made things worse.** Wait 2 weeks before judging; then revert from the changelog if the target query dropped.
- **No CMS API.** Let the agent write the change table and edit by hand. Keep the changelog anyway.
- **The expected CTR curve.** It is a rough floor. Pages with ads, maps or AI answers above them get fewer clicks at every position.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `gsc_quick_wins.py`, `internal_links.py`
