---
title: "Weekly SEO upkeep loop: prompts"
slug: "weekly-seo-upkeep-prompts"
theme: "Get found in search and AI answers"
type: "prompts"
---

# Weekly SEO upkeep loop: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run this week's loop

Paste with the skill loaded. Attach the Search Console export.

```text
Use the weekly-seo-upkeep skill.

Site: {{site}}
Search Console export (query + page, last 28 days): {{attached}}
Content: {{repo folder | CMS connector | list of URLs}}
Last week's changelog: {{attached or "first week"}}

Compare last week's changes first. Then build quick_wins.md and changes-{{date}}.md. Show me the tables and wait for my OK before editing anything.
```

## 2. Rewrite low-CTR titles

Paste the low-CTR rows.

```text
These pages get impressions but few clicks for their main query: {{paste rows: page, query, position, CTR, current title, current description}}.
For each, write 3 title options (under 60 characters, query words early, a specific benefit or number) and 1 description (about 150 characters, answer + reason to click). Promise nothing the page does not deliver.
```

## 3. Internal link pass

Paste link_suggestions.csv or page texts.

```text
Here are internal link candidates: {{paste}}.
Keep at most 3-5 new links per source page. Drop any candidate where the anchor is in a heading, the first sentence, an existing link, or reads unnaturally. Return the final table: source page, exact sentence with the link added, target page, target query.
```

## 4. Refresh a page

Paste the page and its striking-distance queries.

```text
Page: {{url}}. Text: {{paste}}. Queries it ranks 4-20 for: {{queries}}.
Propose a refresh: claims that need a source (list each), a new section or FAQ that covers missing queries (write it), numbers to add, and a new intro that answers the main query in the first 2 sentences. Mark every change so I can review it.
```
