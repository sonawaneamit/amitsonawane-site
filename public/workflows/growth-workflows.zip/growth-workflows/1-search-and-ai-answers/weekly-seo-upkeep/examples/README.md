# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-gsc-export.csv`: A query + page export.
- `example-targets.csv`: Targets for the internal link script.
- `example-quick_wins.md`: Output of gsc_quick_wins.py for the export above.
- `example-changes.md`: A proposed change table waiting for approval.
