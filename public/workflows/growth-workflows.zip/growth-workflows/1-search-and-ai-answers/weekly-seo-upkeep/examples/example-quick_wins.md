# Search quick wins

Rows read: 4. Minimum impressions: 100.

## 1. Striking distance (position 4-20)

| Query | Page | Impressions | Clicks | Position |
|---|---|---|---|---|
| mobile dog grooming prices | https://www.example.com/blog/grooming-prices | 2200 | 40 | 6.2 |
| how often to groom a doodle | https://www.example.com/blog/doodle-grooming | 900 | 12 | 11.4 |
| groomer booking app | https://www.example.com/app | 700 | 5 | 8.0 |

## 2. Low CTR for the position (rewrite title and meta description)

| Query | Page | Position | CTR | Clicks missed (est.) |
|---|---|---|---|---|
| mobile dog grooming prices | https://www.example.com/blog/grooming-prices | 6.2 | 1.8% | 37 |
| groomer booking app | https://www.example.com/app | 8.0 | 0.7% | 12 |

## 3. Pages to link to (most striking-distance queries)

| Page | Queries in 4-20 | Total impressions | Best anchor candidates |
|---|---|---|---|
| https://www.example.com/blog/grooming-prices | 1 | 2200 | mobile dog grooming prices |
| https://www.example.com/blog/doodle-grooming | 1 | 900 | how often to groom a doodle |
| https://www.example.com/app | 1 | 700 | groomer booking app |
