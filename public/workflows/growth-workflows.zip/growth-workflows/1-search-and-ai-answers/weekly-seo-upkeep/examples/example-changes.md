# Changes for 10 Nov 2026 (EXAMPLE DATA, waiting for approval)

## Titles
| Page | Query | Pos | CTR | Current | Proposed |
|---|---|---|---|---|---|
| /blog/grooming-prices | mobile dog grooming prices | 6.2 | 1.8% | Dog grooming prices | Mobile dog grooming prices in 2026: $70-$140 by size |

## Internal links
| Source page | Anchor | Target | Target query | Target pos |
|---|---|---|---|---|
| /blog/doodle-grooming | mobile dog grooming prices | /blog/grooming-prices | mobile dog grooming prices | 6.2 |
