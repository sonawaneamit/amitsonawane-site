# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-questions.csv`: Part of a question set.
- `example-answers.csv`: Recorded answers with mentions and citations.
- `example-fix-list.md`: The scored summary and ranked fixes.
