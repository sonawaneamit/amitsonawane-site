# AI-answer visibility: Example Booking, 2 Nov 2026 (EXAMPLE DATA)
Mention rate 28% | First-place 5% | Citation rate 12% | Share of voice 14%
By intent: best 10%, compare 25%, problem 0%, price 60%, brand 90%.

Most cited: a review site's "best grooming software" list (cited for 14 of 40 questions). We are not on it.

| # | Fix | Type | Questions | Effort | Due |
|---|---|---|---|---|---|
| 1 | Get listed on the most cited list with verified facts and a demo account | off-site | 14 | S | 15 Nov |
| 2 | Answer-first page: "How to stop grooming no-shows" with deposit data | site | 6 | M | 30 Nov |
| 3 | Honest vs page for Rival Scheduler | site | 5 | M | 30 Nov |
| 4 | Pricing page: plan limits as text, not image | site | 4 | S | 10 Nov |
| 5 | Allow OAI-SearchBot and Claude-SearchBot (blocked by a wildcard rule) | site | all | S | 8 Nov |
| 6 | Publish /llms.txt | site | all | S | 8 Nov |
