---
title: "AI-answer visibility: prompts"
slug: "ai-answer-visibility-prompts"
theme: "Get found in search and AI answers"
type: "prompts"
---

# AI-answer visibility: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the full audit

Paste with the skill loaded and web access on.

```text
Use the ai-answer-visibility skill.

Brand: {{brand}}
Site: {{url}}
Category (buyer words): {{category}}
Competitors: {{competitors}}
Assistants I can use: {{assistants}}
Key pages: {{urls}}

Start with questions.csv and show it to me before asking any assistant. Then run steps 2 to 6 and give me fix-list.md with the scores at the top.
```

## 2. Write the question set

Use alone if you will ask the assistants by hand.

```text
Write 40 questions a buyer of {{category}} asks an AI assistant before choosing, in their words.
8 each for these intents: best, compare ({{brand}} and {{competitors}}), problem (jobs and pains: {{pains}}), price, brand.
Return CSV: id, intent, question. No questions only an existing customer would ask.
```

## 3. Score pasted answers

Paste answers you collected by hand.

```text
Below are AI assistant answers to my question set, one block per question and assistant, with any cited URLs.
Brand: {{brand}}. Competitors: {{competitors}}.

Return answers.csv rows: id, assistant, mentioned, position, sentiment, competitors named, cited URLs.
Then the mention rate, first-place rate, citation rate and share of voice, overall and by intent.

ANSWERS:
<<<
{{paste}}
>>>
```

## 4. Why do these pages get cited?

After step 4. Paste the 10 most cited URLs.

```text
These are the pages AI assistants cite most for {{category}}. Open each one.
For each: page type, what the first 2 sentences say, tables or lists used, whether it shows prices, dates, an author, pros and cons, and whether {{brand}} is on it.
Then list the 5 traits most of them share, and the 5 pages where getting {{brand}} added or corrected would cover the most questions.
```

## 5. Write llms.txt

Give it your sitemap or a list of key pages.

```text
Write an llms.txt file for {{site}}: an H1 with the site name, a blockquote with a 1-2 sentence summary of what the company does and for whom, a short paragraph of key facts (pricing model, who it is for, regions), then H2 sections with markdown link lists: Product, Pricing, Comparisons, Docs or Help, Company and policies. Add an "Optional" H2 for secondary pages. Each link gets a short note after a colon. Use only pages in this list: {{paste URLs}}.
```

## 6. Answer-first page brief

One per question cluster from the fix list.

```text
Write a page brief that answers this question cluster: {{questions}}.
The direct answer goes in the first 2 sentences. Then a comparison table with criteria, prices and limits; honest pros and cons including where competitors are better; a "last updated" date and a named author; an FAQ with 5 real questions. Target 900-1,400 words. List every fact I must verify before publishing.
```
