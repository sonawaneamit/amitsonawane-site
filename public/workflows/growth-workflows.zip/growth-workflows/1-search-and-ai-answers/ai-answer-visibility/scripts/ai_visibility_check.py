#!/usr/bin/env python3
"""AI-answer visibility check for one site. Standard library only.

Checks: robots.txt rules for AI crawlers, /llms.txt, sitemap, and whether
the home page (or any URL you pass) has readable text without JavaScript,
a title, a meta description and structured data.

Usage:
  python3 ai_visibility_check.py https://www.example.com [https://www.example.com/pricing ...]
"""
import html as htmllib, re, sys, urllib.request, urllib.robotparser
from urllib.parse import urljoin, urlparse

UA = "visibility-check/1.0 (site owner audit)"
AI_AGENTS = ["GPTBot", "OAI-SearchBot", "ChatGPT-User", "ClaudeBot", "Claude-SearchBot",
             "Claude-User", "PerplexityBot", "Perplexity-User", "Google-Extended",
             "Googlebot", "Bingbot", "Applebot", "Meta-ExternalAgent"]

def fetch(url):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    try:
        with urllib.request.urlopen(req, timeout=20) as r:
            return r.status, r.read().decode("utf-8", "replace")
    except urllib.error.HTTPError as e:
        return e.code, ""
    except Exception as e:
        return 0, str(e)

def visible_text(html):
    html = re.sub(r"(?is)<(script|style|noscript|svg)[^>]*>.*?</\1>", " ", html)
    text = re.sub(r"(?s)<[^>]+>", " ", html)
    return htmllib.unescape(re.sub(r"\s+", " ", text).strip())

def check_page(url):
    status, html = fetch(url)
    print(f"\n## Page: {url} (HTTP {status})")
    if status != 200:
        return
    title = re.search(r"(?is)<title[^>]*>(.*?)</title>", html)
    desc = re.search(r'(?is)<meta[^>]+name=["\']description["\'][^>]*content=["\'](.*?)["\']', html)
    jsonld = re.findall(r'(?is)<script[^>]+application/ld\+json[^>]*>(.*?)</script>', html)
    types = re.findall(r'"@type"\s*:\s*"([^"]+)"', " ".join(jsonld))
    words = len(visible_text(html).split())
    h1 = re.findall(r"(?is)<h1[^>]*>(.*?)</h1>", html)
    print(f"- title: {visible_text(title.group(1)) if title else 'MISSING'}")
    print(f"- meta description: {'present' if desc else 'MISSING'}")
    print(f"- h1 count: {len(h1)}")
    print(f"- structured data types: {', '.join(sorted(set(types))) or 'none'}")
    flag = "  <- low: content may need JavaScript to render" if words < 150 else ""
    print(f"- words readable without JavaScript: {words}{flag}")

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    base = sys.argv[1].rstrip("/")
    root = f"{urlparse(base).scheme}://{urlparse(base).netloc}"
    print(f"# AI visibility check: {root}")

    status, robots = fetch(root + "/robots.txt")
    print(f"\n## robots.txt (HTTP {status})")
    rp = urllib.robotparser.RobotFileParser()
    rp.parse(robots.splitlines())
    for agent in AI_AGENTS:
        ok = rp.can_fetch(agent, root + "/")
        print(f"- {agent}: {'allowed' if ok else 'BLOCKED'} on /")
    sitemaps = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", robots)
    print(f"- sitemaps listed: {len(sitemaps)}")

    status, llms = fetch(root + "/llms.txt")
    print(f"\n## /llms.txt (HTTP {status})")
    if status == 200 and llms.lstrip("\ufeff").startswith("# "):
        links = re.findall(r"\[[^\]]+\]\((https?://[^)]+)\)", llms)
        print(f"- present, H1: {llms.splitlines()[0][2:]}, links: {len(links)}")
    else:
        print("- missing or not in the expected format (an H1 on the first line)")

    if not sitemaps:
        status, _ = fetch(root + "/sitemap.xml")
        print(f"\n## /sitemap.xml (HTTP {status})")

    for url in [base] + sys.argv[2:]:
        check_page(url)

if __name__ == "__main__":
    main()
