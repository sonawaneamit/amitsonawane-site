---
title: "AI-answer visibility"
slug: "ai-answer-visibility"
theme: "Get found in search and AI answers"
theme_slug: "search-and-ai-answers"
theme_order: 1
order: 1
summary: "Find out whether AI assistants mention you when buyers ask about your category, see which sources they cite instead, and fix the gaps on your site and around the web."
---

# AI-answer visibility

Find out whether AI assistants mention you when buyers ask about your category, see which sources they cite instead, and fix the gaps on your site and around the web.

| | |
|---|---|
| Theme | Get found in search and AI answers |
| Time | 2 to 3 hours for the first audit, then 30 minutes a month |
| Works with | Any agent with web access. Best when it can also query AI assistants with web search turned on. |
| You get | A mention and citation scorecard, a list of cited sources to win, and a fix list for your site |

## When to use it

- Buyers in your category ask AI assistants for recommendations and you do not know whether you show up.
- A competitor keeps getting named in AI answers and you do not.
- You are launching a site or a big content update and want it readable by AI crawlers from day one.

## What you get

- `questions.csv`: 30 to 60 buyer questions, grouped by intent.
- `answers.csv`: per question and assistant, whether you are mentioned, your position, competitors named, and cited URLs.
- `citations.md`: the domains and page types assistants cite most, and why they get picked.
- `site-check.md`: crawler access, llms.txt, rendering, structured data, per key page.
- `fix-list.md`: ranked fixes on your site and off it, with owners and dates.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Brand and site | Example Booking, https://www.example.com | Yes |
| Category | Booking software for mobile pet groomers | Yes |
| Competitors | 3 to 5 names | Yes |
| Assistants to check | 2 to 4 chat assistants or AI search tools you can access | Yes |
| Key pages | Home, pricing, 2 comparison pages | Optional |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Build the question set.** 30 to 60 questions a buyer asks before choosing, in buyer words.
2. **Ask the assistants.** Each question in each assistant with web search on. Record mentions, rank and cited URLs.
3. **Score visibility.** Share of questions where you are mentioned, cited, or first.
4. **Study the citations.** Which domains and page types get cited for your category, and what they have in common.
5. **Check your site.** Crawler access, readable HTML, llms.txt, structured data, answer-first pages.
6. **Fix and re-measure.** Ship site fixes and off-site work, then rerun the same questions monthly.

## Copy-paste prompts

### 1. Run the full audit

Paste with the skill loaded and web access on.

```text
Use the ai-answer-visibility skill.

Brand: {{brand}}
Site: {{url}}
Category (buyer words): {{category}}
Competitors: {{competitors}}
Assistants I can use: {{assistants}}
Key pages: {{urls}}

Start with questions.csv and show it to me before asking any assistant. Then run steps 2 to 6 and give me fix-list.md with the scores at the top.
```

### 2. Write the question set

Use alone if you will ask the assistants by hand.

```text
Write 40 questions a buyer of {{category}} asks an AI assistant before choosing, in their words.
8 each for these intents: best, compare ({{brand}} and {{competitors}}), problem (jobs and pains: {{pains}}), price, brand.
Return CSV: id, intent, question. No questions only an existing customer would ask.
```

### 3. Score pasted answers

Paste answers you collected by hand.

```text
Below are AI assistant answers to my question set, one block per question and assistant, with any cited URLs.
Brand: {{brand}}. Competitors: {{competitors}}.

Return answers.csv rows: id, assistant, mentioned, position, sentiment, competitors named, cited URLs.
Then the mention rate, first-place rate, citation rate and share of voice, overall and by intent.

ANSWERS:
<<<
{{paste}}
>>>
```

### 4. Why do these pages get cited?

After step 4. Paste the 10 most cited URLs.

```text
These are the pages AI assistants cite most for {{category}}. Open each one.
For each: page type, what the first 2 sentences say, tables or lists used, whether it shows prices, dates, an author, pros and cons, and whether {{brand}} is on it.
Then list the 5 traits most of them share, and the 5 pages where getting {{brand}} added or corrected would cover the most questions.
```

### 5. Write llms.txt

Give it your sitemap or a list of key pages.

```text
Write an llms.txt file for {{site}}: an H1 with the site name, a blockquote with a 1-2 sentence summary of what the company does and for whom, a short paragraph of key facts (pricing model, who it is for, regions), then H2 sections with markdown link lists: Product, Pricing, Comparisons, Docs or Help, Company and policies. Add an "Optional" H2 for secondary pages. Each link gets a short note after a colon. Use only pages in this list: {{paste URLs}}.
```

### 6. Answer-first page brief

One per question cluster from the fix list.

```text
Write a page brief that answers this question cluster: {{questions}}.
The direct answer goes in the first 2 sentences. Then a comparison table with criteria, prices and limits; honest pros and cons including where competitors are better; a "last updated" date and a named author; an FAQ with 5 real questions. Target 900-1,400 words. List every fact I must verify before publishing.
```

## Scoring rubric

| Score | Formula | Aim for |
|---|---|---|
| Mention rate | questions where you are named / all questions | Rising month over month |
| First-place rate | questions where you are named first / all | Above your share of the market |
| Citation rate | questions citing your domain / all | 20%+ on compare and price questions |
| Share of voice | your mentions / all brand mentions | Higher than your strongest competitor |

Rank fixes by: questions affected x ease of winning the cited source (easy 3, hard 1) / effort (S=1, M=2, L=3).

## Templates

**llms.txt skeleton**

```markdown
# {{Site name}}

> {{One or two sentences: what you do, for whom.}}

{{Key facts: pricing model, regions, who it is not for.}}

## Product
- [Overview]({{url}}): what it does and main features
- [Pricing]({{url}}): plans, limits and prices

## Comparisons
- [{{Brand}} vs {{Competitor}}]({{url}}): honest side-by-side

## Docs
- [Getting started]({{url}}): setup in 5 minutes

## Optional
- [Blog]({{url}}): guides and updates
```

**answers.csv header**

`id,assistant,date,run,mentioned,position,sentiment,competitors_named,cited_urls`

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`ai_visibility_check.py` checks robots.txt rules for common AI and search crawlers, `/llms.txt`, sitemaps, and for each URL: title, meta description, H1 count, structured data types, and how many words are readable without JavaScript.

```bash
python3 scripts/ai_visibility_check.py https://www.example.com https://www.example.com/pricing https://www.example.com/vs/competitor
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-questions.csv`: Part of a question set.
- `examples/example-answers.csv`: Recorded answers with mentions and citations.
- `examples/example-fix-list.md`: The scored summary and ranked fixes.

## Troubleshooting and tips

- **Answers change every time you ask.** Ask each question twice in fresh chats and compare monthly trends, not single runs.
- **The assistant answers from memory with no citations.** Turn on web search or browsing, or add "search the web" to the question. Record whether it searched.
- **You are cited but not named.** Your page is used as a source but the brand is unclear on it. Put the brand name and a one-line description near the facts that get quoted.
- **A wildcard robots.txt rule blocks AI crawlers.** Add explicit `User-agent` groups for the search and user-triggered crawlers you want, with `Allow: /`.
- **JavaScript-only pages.** If the script finds under about 150 readable words, render key pages on the server or pre-render them.
- **Slow movement.** Off-site sources (review sites, lists, community threads) usually move answers more than on-site changes. Work on both.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `ai_visibility_check.py`
