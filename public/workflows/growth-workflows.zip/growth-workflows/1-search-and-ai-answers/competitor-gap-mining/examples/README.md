# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-intel.md`: Findings for one competitor.
- `example-gaps.md`: Ranked gaps and first builds.
