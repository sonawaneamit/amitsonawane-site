# Intel: rival-scheduler.example (EXAMPLE DATA)
Checked 2 Nov 2026.

## robots.txt hints
- Disallow: /lp/ -> 14 public landing pages, all used for paid traffic. Shared headline: "Fill your calendar, skip the no-shows".

## Sitemap
1,940 URLs. Location 1,210 | templates 310 | compare 22 | alternative 9 | integrations 48.
New in the last 90 days: /vs/example-booking (12 Oct), /alternatives/groom-pro (3 Oct), 140 new location pages.

## Ads running 60+ days
| Platform | Started | Hook | Offer | Landing page |
|---|---|---|---|---|
| Meta | 2026-06-02 | "I lost $400 to no-shows last month" | 30-day free trial | /lp/no-shows |
| Search | ongoing | "No-show protection for groomers" | Free trial | /lp/groomers |

## History
- Pricing: Starter $29 -> $19 on 2026-04-11 (archive snapshots); annual plan added 2026-05.
