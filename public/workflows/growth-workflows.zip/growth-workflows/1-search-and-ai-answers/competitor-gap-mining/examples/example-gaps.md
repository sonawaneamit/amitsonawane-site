# Gaps and plan (EXAMPLE DATA)

| # | Gap | Evidence | Value | Confidence | Effort | Priority |
|---|---|---|---|---|---|---|
| 1 | No vs page for Rival Scheduler; theirs about us is live | /vs/example-booking added 12 Oct | 5 | 3 | S | 15 |
| 2 | No-show angle in ads | Same angle active 150+ days | 4 | 3 | M | 6 |
| 3 | No location pages | 1,210 location pages, still adding | 4 | 3 | L | 4 |

First 5 builds: 1) honest vs page, 2) "Rival Scheduler alternatives" page, 3) no-show ad test with our own deposit data, 4) 30 location pages as a pilot, 5) no-show cost calculator.
