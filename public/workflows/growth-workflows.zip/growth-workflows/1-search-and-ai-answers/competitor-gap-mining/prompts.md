---
title: "Competitor gap mining: prompts"
slug: "competitor-gap-mining-prompts"
theme: "Get found in search and AI answers"
type: "prompts"
---

# Competitor gap mining: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the full teardown

Paste with the skill loaded.

```text
Use the competitor-gap-mining skill.

Competitors: {{domains}}
My site: {{url}}
Window: last {{months}} months
Market: {{country}}
Keyword exports: {{attached or "none"}}

Start with the public files for each competitor and show me page-type counts and the newest flagged URLs. Then do ads, history, timeline, gaps, and plan.md with the first 5 things to build.
```

## 2. Read a URL list

Attach the CSV from site_intel.py.

```text
Here is the sitemap URL list for {{competitor}} with lastmod dates and page-type tags.
1. Count pages by type and by month added or changed.
2. List every compare, alternative and landing page added in the last 90 days.
3. What does the mix say about their growth strategy?
4. Which page types do they have that {{my site}} does not?
```

## 3. Ad library notes

Paste notes or screenshots from an ad library.

```text
Here are active ads for {{competitor}} with their start dates.
For every ad running 60+ days: hook (first line or first 3 seconds), format, offer, proof used, landing page.
Then the 3 angles they keep running and, for each, how we could make an honest version with our own proof.
```

## 4. Growth timeline

After collecting signals.

```text
Build a dated growth timeline for {{competitor}} from these signals: {{paste notes, archive dates, ads, launches}}.
Table: date, channel, move, evidence, likely effect. Oldest first.
Then 3 lines: what drives their growth, what they will do next, what is fragile.
```

## 5. Honest comparison page

One per main competitor.

```text
Write a "{{my product}} vs {{competitor}}" page brief.
Use only facts from these pages: {{our pricing/features URLs}} and {{their pricing/features URLs}}, with the date checked.
Include: who each is best for, a side-by-side table (price, limits, key features), 3 places they are better, 3 places we are better, how to switch, FAQ. Neutral tone. Flag every claim I must re-check before publishing.
```
