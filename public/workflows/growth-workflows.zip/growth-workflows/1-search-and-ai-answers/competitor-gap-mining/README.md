---
title: "Competitor gap mining"
slug: "competitor-gap-mining"
theme: "Get found in search and AI answers"
theme_slug: "search-and-ai-answers"
theme_order: 1
order: 3
summary: "Work out what competitors do to grow from public files and public data: hidden landing pages, new pages in their sitemaps, long-running ads, pricing changes, and the keywords and pages you are missing."
---

# Competitor gap mining

Work out what competitors do to grow from public files and public data: hidden landing pages, new pages in their sitemaps, long-running ads, pricing changes, and the keywords and pages you are missing.

| | |
|---|---|
| Theme | Get found in search and AI answers |
| Time | 2 to 4 hours per competitor |
| Works with | Any agent with web access. A browser helps for ad libraries; scripts cover robots.txt, sitemaps and the web archive. |
| You get | A dated growth timeline per competitor, a gap list, and the first pages and tests to build |

## When to use it

- You know your 3 to 5 main competitors and want to know what works for them.
- You are planning comparison pages, ads or a content push.
- A competitor suddenly grew and you want to know what changed.

## What you get

- `intel/{{domain}}_urls.csv`: every URL in their sitemaps with dates and page-type tags.
- `intel/{{domain}}.md`: hidden pages, new pages, longest-running ads, pricing and headline changes.
- `timeline.md`: a dated growth timeline per competitor across channels.
- `gaps.md`: keywords, page types and claims they cover and you do not, ranked.
- `plan.md`: the first 5 pages or tests to build, including honest comparison pages.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Competitors | 3 to 5 domains | Yes |
| Your site | https://www.example.com | Yes |
| Time window | Last 12 months | Default |
| Keyword tool export | Organic keywords for you and competitors | Optional |
| Market | US | Default |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Public files.** robots.txt Disallow lines and every sitemap URL with dates.
2. **New and hidden pages.** Comparison, alternative, landing, pricing and use-case pages, and what changed recently.
3. **Ads.** Ads running longest in public ad libraries, and where they send people.
4. **History.** Pricing and headline changes from web archive snapshots.
5. **Timeline.** Every dated move in one table per competitor.
6. **Gaps and plan.** What they cover that you do not, and what to build first.

## Copy-paste prompts

### 1. Run the full teardown

Paste with the skill loaded.

```text
Use the competitor-gap-mining skill.

Competitors: {{domains}}
My site: {{url}}
Window: last {{months}} months
Market: {{country}}
Keyword exports: {{attached or "none"}}

Start with the public files for each competitor and show me page-type counts and the newest flagged URLs. Then do ads, history, timeline, gaps, and plan.md with the first 5 things to build.
```

### 2. Read a URL list

Attach the CSV from site_intel.py.

```text
Here is the sitemap URL list for {{competitor}} with lastmod dates and page-type tags.
1. Count pages by type and by month added or changed.
2. List every compare, alternative and landing page added in the last 90 days.
3. What does the mix say about their growth strategy?
4. Which page types do they have that {{my site}} does not?
```

### 3. Ad library notes

Paste notes or screenshots from an ad library.

```text
Here are active ads for {{competitor}} with their start dates.
For every ad running 60+ days: hook (first line or first 3 seconds), format, offer, proof used, landing page.
Then the 3 angles they keep running and, for each, how we could make an honest version with our own proof.
```

### 4. Growth timeline

After collecting signals.

```text
Build a dated growth timeline for {{competitor}} from these signals: {{paste notes, archive dates, ads, launches}}.
Table: date, channel, move, evidence, likely effect. Oldest first.
Then 3 lines: what drives their growth, what they will do next, what is fragile.
```

### 5. Honest comparison page

One per main competitor.

```text
Write a "{{my product}} vs {{competitor}}" page brief.
Use only facts from these pages: {{our pricing/features URLs}} and {{their pricing/features URLs}}, with the date checked.
Include: who each is best for, a side-by-side table (price, limits, key features), 3 places they are better, 3 places we are better, how to switch, FAQ. Neutral tone. Flag every claim I must re-check before publishing.
```

## Scoring rubric

**Gap priority** = value (1-5) x confidence the signal is real (1-3) / effort (S=1, M=2, L=3)

| Signal | Strong evidence | Weak evidence |
|---|---|---|
| An ad angle works | Same ad active 90+ days, several variants | One new ad |
| A page type works | Dozens of pages, still adding | A handful, none added this year |
| A pricing move | Price or plan changed and stayed | One snapshot |
| Next target | New vs or alternative pages in the last 90 days | Old pages only |

## Templates

**timeline.md row**

`| 2026-03 | ads | Started "switch in 5 minutes" video ads; 3 variants still active | ad library, started 2026-03-04 | Pulls switchers from the market leader |`

**plan.md item**

```text
1. {{page or test}}
   Why: {{gap and evidence}}
   Build: {{what exactly}}
   Measure: {{metric}} by {{date}}
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`site_intel.py` reads a site's robots.txt and every sitemap it lists (nested and gzipped too), tags URLs by page type, flags URLs changed in the last N days, and writes `<domain>_urls.csv`.

```bash
python3 scripts/site_intel.py https://www.rival-scheduler.example.com --days 90 --max-sitemaps 40
```

Web archive history for one page (no script needed):

```bash
curl -s "https://web.archive.org/cdx/search/cdx?url=rival-scheduler.example.com/pricing&output=json&fl=timestamp,statuscode,digest&collapse=digest&from=2025"
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-intel.md`: Findings for one competitor.
- `examples/example-gaps.md`: Ranked gaps and first builds.

## Troubleshooting and tips

- **No sitemap found.** Try /sitemap_index.xml or /sitemap-index.xml, or search `site:domain` instead.
- **Huge sitemaps.** Raise `--max-sitemaps` slowly, or read only the sitemaps whose names match blog, compare, lp or alternatives.
- **The ad library shows nothing.** Search by the advertiser's page name and check the country filter. Some ads show only in some regions.
- **Too much data.** Stop at the timeline. Three clear growth moves per competitor are enough to plan with.
- **Their comparison page about you is wrong.** Publish your own honest one with dates and sources; do not argue on their page.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `site_intel.py`
