#!/usr/bin/env python3
"""Public-file intel on a competitor site. Standard library only.

Reads only public files a site publishes for crawlers:
  - robots.txt Disallow lines (often hint at landing pages kept out of search)
  - sitemap.xml and nested sitemaps (every listed URL, with lastmod dates)
Then flags URLs that look like comparison, alternative, pricing, landing,
template, integration or use-case pages, and URLs added or changed recently.

Writes <domain>_urls.csv and prints a summary.

Usage:
  python3 site_intel.py https://www.rival-scheduler.example.com [--days 90] [--max-sitemaps 40]
"""
import csv, gzip, re, sys, time, urllib.request
from datetime import datetime, timedelta, timezone
from urllib.parse import urlparse

UA = {"User-Agent": "site-intel/1.0 (public files only)"}
PATTERNS = {
    "compare": r"(-vs-|/vs/|versus|compare|comparison)",
    "alternative": r"alternative",
    "pricing": r"(pricing|plans|price)",
    "landing": r"(/lp/|/go/|/try/|/get/|/demo|/offer|/promo|/campaign)",
    "template": r"(template|examples?/)",
    "integration": r"(integration|/apps/|/connect)",
    "use_case": r"(use-case|/for-|/solutions/|/industries/|/teams/)",
    "location": r"(/locations?/|/city/|/near-)",
}

def fetch(url):
    req = urllib.request.Request(url, headers=UA)
    with urllib.request.urlopen(req, timeout=30) as r:
        data = r.read()
    if url.endswith(".gz") or data[:2] == b"\x1f\x8b":
        data = gzip.decompress(data)
    return data.decode("utf-8", "replace")

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    root = sys.argv[1].rstrip("/")
    days = int(sys.argv[sys.argv.index("--days") + 1]) if "--days" in sys.argv else 90
    max_maps = int(sys.argv[sys.argv.index("--max-sitemaps") + 1]) if "--max-sitemaps" in sys.argv else 40
    host = urlparse(root).netloc
    try:
        robots = fetch(root + "/robots.txt")
    except Exception as e:
        robots = ""; print(f"robots.txt: {e}")
    disallow = sorted(set(re.findall(r"(?im)^\s*disallow:\s*(\S+)", robots)))
    print(f"# {host}\n\n## robots.txt Disallow lines ({len(disallow)})")
    for d in disallow:
        print("-", d)

    queue = re.findall(r"(?im)^\s*sitemap:\s*(\S+)", robots) or [root + "/sitemap.xml"]
    seen_maps, urls = set(), {}
    while queue and len(seen_maps) < max_maps:
        sm = queue.pop(0)
        if sm in seen_maps:
            continue
        seen_maps.add(sm)
        try:
            xml = fetch(sm)
        except Exception as e:
            print(f"sitemap {sm}: {e}"); continue
        if "<sitemapindex" in xml:
            queue += re.findall(r"<loc>\s*(.*?)\s*</loc>", xml)
            continue
        for block in re.findall(r"(?s)<url>(.*?)</url>", xml):
            loc = re.search(r"<loc>\s*(.*?)\s*</loc>", block)
            mod = re.search(r"<lastmod>\s*(.*?)\s*</lastmod>", block)
            if loc:
                urls[loc.group(1)] = mod.group(1)[:10] if mod else ""
        time.sleep(0.5)
    if queue:
        print(f"\nnote: stopped after {max_maps} sitemaps, {len(queue)} not read (raise --max-sitemaps)")

    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d")
    rows, counts, recent = [], {k: 0 for k in PATTERNS}, 0
    for u, mod in urls.items():
        tags = [k for k, p in PATTERNS.items() if re.search(p, u, re.I)]
        for t in tags:
            counts[t] += 1
        is_recent = bool(mod) and mod >= cutoff
        recent += is_recent
        rows.append([u, mod, "yes" if is_recent else "", " ".join(tags)])
    rows.sort(key=lambda r: r[1], reverse=True)
    out = f"{host}_urls.csv"
    with open(out, "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["url", "lastmod", f"changed_last_{days}d", "page_type"]); w.writerows(rows)
    print(f"\n## Sitemaps read: {len(seen_maps)}, URLs: {len(urls)}, changed in last {days} days: {recent}")
    for k, v in counts.items():
        print(f"- {k}: {v}")
    print("\n## Newest flagged URLs")
    for r in [r for r in rows if r[3] and r[2]][:25]:
        print(f"- {r[1]}  {r[0]}  [{r[3]}]")
    print(f"\nsaved {out}")

if __name__ == "__main__":
    main()
