#!/usr/bin/env python3
"""A/B test helper for click-through or conversion rates. Standard library only.

Two modes:
  size     how many impressions (or visitors) each variant needs before you look
  compare  is variant B different from A? (two-sided two-proportion z-test)

Usage:
  python3 ab_test.py size --base 0.02 --lift 0.25 [--power 0.8] [--alpha 0.05]
      base = current rate (2% CTR), lift = smallest relative change you care about (25%)
  python3 ab_test.py compare A:10000:210 B:10000:260 [C:10000:190 ...]
      each arm is name:impressions:clicks; every arm is compared with the first one
"""
import math, sys
from statistics import NormalDist

N = NormalDist()

def size(base, lift, power=0.8, alpha=0.05):
    p1, p2 = base, base * (1 + lift)
    za, zb = N.inv_cdf(1 - alpha / 2), N.inv_cdf(power)
    pbar = (p1 + p2) / 2
    num = (za * math.sqrt(2 * pbar * (1 - pbar)) + zb * math.sqrt(p1 * (1 - p1) + p2 * (1 - p2))) ** 2
    return math.ceil(num / (p2 - p1) ** 2)

def compare(a, b):
    (na, ka), (nb, kb) = a, b
    pa, pb = ka / na, kb / nb
    p = (ka + kb) / (na + nb)
    se = math.sqrt(p * (1 - p) * (1 / na + 1 / nb))
    z = (pb - pa) / se if se else 0
    return pa, pb, z, 2 * (1 - N.cdf(abs(z)))

def opt(args, name, default):
    return float(args[args.index(name) + 1]) if name in args else default

def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    if args[0] == "size":
        base, lift = opt(args, "--base", 0.02), opt(args, "--lift", 0.2)
        n = size(base, lift, opt(args, "--power", 0.8), opt(args, "--alpha", 0.05))
        print(f"base {base:.2%} -> {base*(1+lift):.2%}: about {n:,} per variant before you call it")
    elif args[0] == "compare":
        arms = [a.split(":") for a in args[1:]]
        name0, n0, k0 = arms[0][0], int(arms[0][1]), int(arms[0][2])
        k_tests = max(1, len(arms) - 1)
        for name, n, k in arms[1:]:
            pa, pb, z, pval = compare((n0, k0), (int(n), int(k)))
            adj = min(1.0, pval * k_tests)  # Bonferroni when testing several arms
            verdict = "different" if adj < 0.05 else "not proven yet"
            print(f"{name} vs {name0}: {pb:.2%} vs {pa:.2%} (relative {((pb/pa)-1) if pa else 0:+.0%}), p={adj:.3f}{' (adjusted for ' + str(k_tests) + ' comparisons)' if k_tests > 1 else ''} -> {verdict}")
    else:
        sys.exit(__doc__)

if __name__ == "__main__":
    main()
