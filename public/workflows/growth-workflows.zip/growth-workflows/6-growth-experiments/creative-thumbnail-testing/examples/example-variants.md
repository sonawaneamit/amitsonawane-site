# Variants: "How I de-mat a doodle in 20 minutes" (EXAMPLE DATA)

Hypothesis: a close-up of the finished coat beats the current wide van shot on CTR, because the result is the promise.

| Arm | Changes | Description |
|---|---|---|
| A | (current) | Wide shot of the van, groomer waving |
| B | framing: result | Close-up of the fluffy finished coat, 2 words "20 MIN" |
| C | face | Groomer's face, surprised, holding a mat |

Size: about 6,745 impressions per arm. Method: each as an ad, same audience and budget, in the platform's experiment feature.

Result: B wins (+37% CTR, "different"). C not proven. learnings.md: "result close-up beats van shot for tutorials".
