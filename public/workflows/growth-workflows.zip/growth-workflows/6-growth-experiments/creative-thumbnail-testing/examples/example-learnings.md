| date | asset | variable | winner | lift | sample per variant | note |
|---|---|---|---|---|---|---|
| 2026-10-12 | de-mat video | framing | result close-up | +37% | 6000 | tutorials |
| 2026-10-26 | deposit ad | hook line | number hook | +18% | 9000 | "4 no-shows" beat "Stop no-shows" |
| 2026-11-08 | nail video | text amount | not proven | - | 7000 | keep current |
