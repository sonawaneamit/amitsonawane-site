# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-size-output.txt`: Real output: 4% baseline CTR, smallest lift 25%.
- `example-compare-output.txt`: Real output for three made-up thumbnail variants.
- `example-variants.md`: A variant plan for a made-up grooming video.
- `example-learnings.md`: A learning log after a few rounds.
