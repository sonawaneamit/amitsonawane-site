---
title: "Creative and thumbnail testing"
slug: "creative-thumbnail-testing"
theme: "Growth experiments"
theme_slug: "growth-experiments"
theme_order: 6
order: 19
summary: "Generate many variants of a thumbnail, hook or ad, pretest them cheaply with small ad budgets or built-in platform tests, change one thing at a time, and only call a winner when the numbers are big enough."
---

# Creative and thumbnail testing

Generate many variants of a thumbnail, hook or ad, pretest them cheaply with small ad budgets or built-in platform tests, change one thing at a time, and only call a winner when the numbers are big enough.

| | |
|---|---|
| Theme | Growth experiments |
| Time | 1 to 3 hours per test round |
| Works with | Any agent. An image tool for variants. A small ad budget or a platform's built-in test feature. |
| You get | A variant set with what each tests, a sample-size plan, a winner call you can trust, and a learning log |

## When to use it

- You publish videos or ads and pick thumbnails or hooks by gut.
- A big launch or video is coming and you want the best first impression.
- You run A/B tests but are not sure the winner is real.

## What you get

- A variant set (4 to 8), each labelled with the one thing it changes.
- A sample-size plan before the test starts.
- A winner call with numbers, and a line in `learnings.md`.

## Inputs

| Input | Example | Needed |
|---|---|---|
| What you are testing | Video thumbnail, ad, hook, headline | Yes |
| Current baseline rate | 4% CTR | Yes, or a guess |
| Smallest lift worth finding | 25% relative | Yes |
| Test method | Built-in split test, small ad budget, or email split | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Hypothesis.** What you think will win and why.
2. **Generate variants.** One variable per variant, 4 to 8 total.
3. **Size the test.** Script: impressions per variant before you look.
4. **Pretest.** Small ad budget or a built-in platform test.
5. **Compare.** Script: is the difference real?
6. **Log and ship.** Winner live, learning written down.

## Copy-paste prompts

### 1. Plan a test

Start here.

```text
Use the creative-thumbnail-testing skill.
Asset: {{video/ad/headline}}. Current version: {{describe or attach}}. Baseline: {{rate}}. Smallest lift that matters: {{lift}}. Method: {{built-in / paid / email}}.
Write the hypothesis, list 6 variants each changing one variable, run the size calculation, and estimate cost and time to reach it.
```

### 2. Thumbnail variants

For an image tool.

```text
Video: {{title and one-line summary}}. Current thumbnail: {{describe}}.
Write 6 image prompts for thumbnail variants at 1280x720. Each changes one variable from the current one: (1) close-up face with {{expression}}, (2) no face, the result object only, (3) 2-word text "{{text}}", (4) different background colour, (5) before/after split, (6) {{your idea}}. Text must be readable at phone size. No real people other than me.
```

### 3. Call the result

When the size is reached.

```text
Results: {{name:impressions:clicks for each variant, current first}}.
Run ab_test.py compare. Tell me the winner only if the script says "different". Write the learnings.md line.
```

## Scoring rubric

**Test quality**

- [ ] Hypothesis written before the test
- [ ] Each variant changes one variable
- [ ] Sample size calculated before launch
- [ ] No stopping before the size is reached
- [ ] Winner only when the script says "different"
- [ ] Learning logged

**Variant quality**: readable at phone size, delivers what the content does, consent for any person shown.

## Templates

**learnings.md**

`| date | asset | variable | winner | lift | sample per variant | note |`

**Variable menu**: face, expression, text amount, text wording, colour, framing, object vs result, first line, first frame, format, offer framing.

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`ab_test.py` sizes a test and compares variants with a two-proportion z-test (two-sided), adjusting for multiple comparisons when there are more than two arms.

```bash
python3 scripts/ab_test.py size --base 0.04 --lift 0.25
python3 scripts/ab_test.py compare A:6000:228 B:6000:312 C:6000:240
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-size-output.txt`: Real output: 4% baseline CTR, smallest lift 25%.
- `examples/example-compare-output.txt`: Real output for three made-up thumbnail variants.
- `examples/example-variants.md`: A variant plan for a made-up grooming video.
- `examples/example-learnings.md`: A learning log after a few rounds.

## Troubleshooting and tips

- **Never enough impressions.** Test bigger changes (a larger lift needs a smaller sample), fewer variants, or a cheaper placement.
- **Winner fades after launch.** Novelty effects are common. Keep a slice of traffic on the old version for a week to confirm.
- **Ad CTR winner flops as a thumbnail.** Ad audiences differ from subscribers. Use built-in platform tests on the real audience when available.
- **Too many variables at once.** Split into rounds: framing first, then text, then colour.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `ab_test.py`
