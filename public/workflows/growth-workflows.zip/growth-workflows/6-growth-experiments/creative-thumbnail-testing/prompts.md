---
title: "Creative and thumbnail testing: prompts"
slug: "creative-thumbnail-testing-prompts"
theme: "Growth experiments"
type: "prompts"
---

# Creative and thumbnail testing: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Plan a test

Start here.

```text
Use the creative-thumbnail-testing skill.
Asset: {{video/ad/headline}}. Current version: {{describe or attach}}. Baseline: {{rate}}. Smallest lift that matters: {{lift}}. Method: {{built-in / paid / email}}.
Write the hypothesis, list 6 variants each changing one variable, run the size calculation, and estimate cost and time to reach it.
```

## 2. Thumbnail variants

For an image tool.

```text
Video: {{title and one-line summary}}. Current thumbnail: {{describe}}.
Write 6 image prompts for thumbnail variants at 1280x720. Each changes one variable from the current one: (1) close-up face with {{expression}}, (2) no face, the result object only, (3) 2-word text "{{text}}", (4) different background colour, (5) before/after split, (6) {{your idea}}. Text must be readable at phone size. No real people other than me.
```

## 3. Call the result

When the size is reached.

```text
Results: {{name:impressions:clicks for each variant, current first}}.
Run ab_test.py compare. Tell me the winner only if the script says "different". Write the learnings.md line.
```
