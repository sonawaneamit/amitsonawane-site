#!/usr/bin/env python3
"""Measure how much you changed an AI draft before publishing. Standard library only.

Edit rate = 1 - (words kept unchanged / words in the longer version), from a
word-level diff. 0% means you published the draft as is; 100% means a rewrite. Lower is better: it means the drafting loop
already sounds like you. Each run appends a row to edit_log.csv so you can
watch the trend per content type.

Usage:
  python3 edit_rate.py draft.md final.md [--type x-post] [--version v3]
"""
import csv, datetime, difflib, os, re, sys

def words(path):
    return re.findall(r"\S+", open(path, encoding="utf-8").read())

def main():
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    a, b = words(sys.argv[1]), words(sys.argv[2])
    kind = sys.argv[sys.argv.index("--type") + 1] if "--type" in sys.argv else ""
    ver = sys.argv[sys.argv.index("--version") + 1] if "--version" in sys.argv else ""
    sm = difflib.SequenceMatcher(None, a, b, autojunk=False)
    changed = 0
    print("Changes:")
    for op, i1, i2, j1, j2 in sm.get_opcodes():
        if op == "equal":
            continue
        changed += max(i2 - i1, j2 - j1)
        before, after = " ".join(a[i1:i2])[:80], " ".join(b[j1:j2])[:80]
        print(f"- {op}: '{before}' -> '{after}'")
    kept = sum(blk.size for blk in sm.get_matching_blocks())
    rate = 1 - kept / max(1, len(a), len(b))
    print(f"\ndraft words: {len(a)}, final words: {len(b)}, words changed: {changed}, edit rate: {rate:.1%}")
    new = not os.path.exists("edit_log.csv")
    with open("edit_log.csv", "a", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        if new:
            w.writerow(["date", "type", "version", "draft", "final", "draft_words", "edit_rate"])
        w.writerow([datetime.date.today().isoformat(), kind, ver, sys.argv[1], sys.argv[2], len(a), f"{rate:.3f}"])
    print("logged to edit_log.csv")

if __name__ == "__main__":
    main()
