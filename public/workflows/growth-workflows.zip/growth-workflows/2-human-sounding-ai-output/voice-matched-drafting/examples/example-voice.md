# Voice profile v2 (short posts) - EXAMPLE DATA

## Measurables
- Sentence length: median 9 words, often a 3-word line after a long one.
- Length: 60-120 words. No hashtags. Emoji: none.

## Openers
- Starts with a scene from the van: "Third doodle this week with matted ears."
- Or a number: "Two hours. That's what a matted coat costs me."

## Closers
- A plain instruction: "Brush behind the ears on Sundays."

## Vocabulary
- Often: coat, van, mat, "honestly no", "my clients"
- Never (checked): journey, game-changer, passionate, pawsome

## Never
- Shame owners. Profile rule from 4 edits where "lazy owners" was cut.

## Changelog
- v2: added "never shame owners" after 4 edits of the same kind.
