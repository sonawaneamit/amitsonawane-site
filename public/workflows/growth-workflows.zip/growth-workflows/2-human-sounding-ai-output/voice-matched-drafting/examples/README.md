# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-voice.md`: A short voice profile for a made-up groomer who posts tips.
- `example-edit_log.csv`: A month of edit rates.
- `example-judge-report.md`: A judge report for one round.
