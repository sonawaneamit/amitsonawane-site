---
title: "Voice-matched drafting loop"
slug: "voice-matched-drafting"
theme: "Make AI output sound human"
theme_slug: "human-sounding-ai-output"
theme_order: 2
order: 7
summary: "Turn a pile of your own past writing into a voice profile and a drafting loop that gets measurably closer to how you write, tracked by how much you edit each draft."
---

# Voice-matched drafting loop

Turn a pile of your own past writing into a voice profile and a drafting loop that gets measurably closer to how you write, tracked by how much you edit each draft.

| | |
|---|---|
| Theme | Make AI output sound human |
| Time | 2 hours to set up, then minutes per draft |
| Works with | Any agent with file access. Works best in a coding agent or a project with a folder. |
| You get | A voice profile, a draft-judge-revise loop, and an edit-rate log that shows if it is improving |

## When to use it

- You publish under your own name and AI drafts never sound like you.
- You want to know if your prompts are getting better, with a number.
- Someone else (an assistant, an agency) drafts for you.

## What you get

- `voice.md`: a voice profile built from your own writing.
- A drafting loop: draft, judge against your real writing, revise up to 3 times.
- `edit_log.csv`: edit rate per draft, so you can see the loop improve.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Your past writing | 30+ pieces of the type you want drafted | Yes |
| Raw inputs for new pieces | Voice notes, bullet notes, transcripts | Yes |
| A second model for judging | Any model other than the drafter | Recommended |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Set up folders.** corpus, holdout, inputs, drafts, final, evals.
2. **Build the voice profile.** Extract rules and examples from the corpus only.
3. **Draft.** From raw inputs, using the profile and 3 closest corpus examples.
4. **Judge and revise.** A second model compares the draft with holdout pieces. Max 3 rounds.
5. **Predict, then edit.** Seal a guess of what you will change; edit; compare.
6. **Measure and update.** Edit rate per piece; turn repeated edits into profile rules.

## Copy-paste prompts

### 1. Build my voice profile

Run once with the corpus folder.

```text
Use the voice-matched-drafting skill.

Content type: {{type}}
My writing is in {{folder or pasted below}}. Shuffle it and put 20% in holdout/; do not read holdout again.
Build voice.md from corpus/ only. Every rule needs a quoted example. Check "never used" words by searching the corpus.
```

### 2. Draft a piece

For each new input.

```text
Use the voice-matched-drafting skill.
Input: inputs/{{file}}. Content type: {{type}}. Target length: {{length}}.
Draft with voice.md and the 3 closest corpus pieces. Facts from the input only; mark gaps [NEED: ...]. Then run the judge step with {{judge model}} and revise, max 3 rounds. Save every round. Write the sealed edit prediction to evals/ and do not show it to me.
```

### 3. Judge prompt

Give this to the second model.

```text
You are judging whether a draft sounds like one specific person.
Voice profile: {{voice.md}}
Three real pieces by them: {{holdout pieces}}
Draft: {{draft}}
Input notes the draft must be based on: {{input}}

Return: (1) voice match 1-10; (2) the 3 lines that sound least like this person, why, and a rewrite of each in their voice; (3) any fact, name or number in the draft not in the input notes; (4) generic AI-writing tells. Be strict. A 10 means you could not tell it from the real pieces.
```

### 4. Monthly review

Once a month.

```text
Read evals/edit_log.csv, the predictions and the matching drafts and finals for this month.
Report: median edit rate by type and voice.md version; the edit classes (cut, voice, fact, structure, taste) with counts; prediction hit rate; and up to 5 proposed changes to voice.md, each backed by 3+ real edits. Wait for my OK before changing voice.md.
```

## Scoring rubric

**Judge scorecard per draft**

| Check | Pass |
|---|---|
| Voice match (judge) | 8+ out of 10 |
| Facts not in input | 0 |
| Generic AI tells | 0 strong tells |
| Length within the profile's normal range | yes |
| Opener style seen in the corpus | yes |

**System health (monthly)**: median edit rate falling, prediction hit rate rising, voice.md rules each backed by examples.

## Templates

**voice.md skeleton**

```markdown
# Voice profile v1 ({{type}})
## Measurables
## Openers (5 quoted)
## Closers (5 quoted)
## Vocabulary: often / never
## Moves
## Stance
## Never
## Changelog
- v1 {{date}}: built from {{n}} pieces
```

**Sealed prediction**

```markdown
# Prediction for {{slug}} (do not show before editing)
- Will cut: ...
- Will change words: ...
- Will rewrite opener: yes/no, because ...
- Expected edit rate: ...%
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`edit_rate.py` diffs a draft against what was published, prints each change, and appends the edit rate to `edit_log.csv`. 0% means published as is; 100% means fully rewritten.

```bash
python3 scripts/edit_rate.py drafts/deposit-post-r2.md final/deposit-post.md --type short-post --version v3
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-voice.md`: A short voice profile for a made-up groomer who posts tips.
- `examples/example-edit_log.csv`: A month of edit rates.
- `examples/example-judge-report.md`: A judge report for one round.

## Troubleshooting and tips

- **Not enough past writing.** Use voice notes: record 10 minutes on 5 topics, transcribe, and use the transcripts as corpus. Spoken voice is still your voice.
- **The judge always gives 9s.** Use a different model, show it real holdout pieces, and ask for the 3 weakest lines every time.
- **Edit rate does not fall.** Check the edit classes. If most are facts, the inputs are thin. If most are taste, the profile needs more examples, not more rules.
- **Drafts drift toward generic after revisions.** Stop at 3 rounds. Pick the best round, not the last.
- **Several content types.** One voice.md per type. They can share the stance and never-lists.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `edit_rate.py`
