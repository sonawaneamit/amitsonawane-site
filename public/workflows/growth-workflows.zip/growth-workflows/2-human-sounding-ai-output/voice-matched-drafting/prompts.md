---
title: "Voice-matched drafting loop: prompts"
slug: "voice-matched-drafting-prompts"
theme: "Make AI output sound human"
type: "prompts"
---

# Voice-matched drafting loop: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Build my voice profile

Run once with the corpus folder.

```text
Use the voice-matched-drafting skill.

Content type: {{type}}
My writing is in {{folder or pasted below}}. Shuffle it and put 20% in holdout/; do not read holdout again.
Build voice.md from corpus/ only. Every rule needs a quoted example. Check "never used" words by searching the corpus.
```

## 2. Draft a piece

For each new input.

```text
Use the voice-matched-drafting skill.
Input: inputs/{{file}}. Content type: {{type}}. Target length: {{length}}.
Draft with voice.md and the 3 closest corpus pieces. Facts from the input only; mark gaps [NEED: ...]. Then run the judge step with {{judge model}} and revise, max 3 rounds. Save every round. Write the sealed edit prediction to evals/ and do not show it to me.
```

## 3. Judge prompt

Give this to the second model.

```text
You are judging whether a draft sounds like one specific person.
Voice profile: {{voice.md}}
Three real pieces by them: {{holdout pieces}}
Draft: {{draft}}
Input notes the draft must be based on: {{input}}

Return: (1) voice match 1-10; (2) the 3 lines that sound least like this person, why, and a rewrite of each in their voice; (3) any fact, name or number in the draft not in the input notes; (4) generic AI-writing tells. Be strict. A 10 means you could not tell it from the real pieces.
```

## 4. Monthly review

Once a month.

```text
Read evals/edit_log.csv, the predictions and the matching drafts and finals for this month.
Report: median edit rate by type and voice.md version; the edit classes (cut, voice, fact, structure, taste) with counts; prediction hit rate; and up to 5 proposed changes to voice.md, each backed by 3+ real edits. Wait for my OK before changing voice.md.
```
