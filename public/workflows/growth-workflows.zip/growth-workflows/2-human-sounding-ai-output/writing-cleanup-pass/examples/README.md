# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-before.md`: An AI-drafted product update.
- `example-after.md`: The same update after the cleanup pass.
- `example-changes.md`: The change log and scores.
