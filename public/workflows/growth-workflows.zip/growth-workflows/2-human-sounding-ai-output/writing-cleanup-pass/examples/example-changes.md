# Changes (EXAMPLE DATA)

| # | Pattern | Before | After |
|---|---|---|---|
| 1 | Stock filler | "In today's fast-paced world" | cut |
| 2 | Inflated words | "robust", "seamless", "game-changer", "empowers", "navigate" | replaced with what the feature does |
| 3 | Binary contrast | "It's not just a payment tool, it's a partner" | cut |
| 4 | Throat-clearing | "Here's the thing:" | cut |
| 5 | Triad | "time, money, and peace of mind" | "a drive and a half-day slot" (from the brief) |
| 6 | Vague attribution | "Experts agree" | cut; asked for beta numbers |
| 7 | Fake emphasis | "Let that sink in." | cut |
| 8 | Em dash | 1 | 0 |

Scores from slop_scan.py: before 12 issues (16.9 per 100 words), after 0.
