Clients now pay a deposit when they book. You set the amount; it comes off their bill on the day.

If a client cancels within 24 hours or does not show, you keep the deposit. Groomers in our beta told us a no-show costs them a drive and a half-day slot, so this is the feature they asked for most.

[NEED: beta numbers, if you want to quote how many no-shows dropped]
