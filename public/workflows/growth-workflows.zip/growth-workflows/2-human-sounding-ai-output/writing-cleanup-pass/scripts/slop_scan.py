#!/usr/bin/env python3
"""Scan text for common AI-writing tells. Standard library only.

Flags word-level tells (inflated vocabulary, filler, hedges), structural tells
(binary contrasts, triads, throat-clearing openers, chat leftovers, em dashes)
and rhythm (sentence lengths that are too even). It points at lines to fix;
it does not rewrite. Use it before and after a cleanup pass.

Usage:
  python3 slop_scan.py draft.md [--json]
  cat draft.txt | python3 slop_scan.py -
"""
import json, re, statistics, sys

WORDS = ["delve", "delves", "tapestry", "testament", "leverage", "leveraging", "seamless", "seamlessly",
         "robust", "elevate", "unlock", "unlocks", "harness", "realm", "landscape", "navigate",
         "navigating", "pivotal", "crucial", "vibrant", "foster", "fostering", "showcase", "showcasing",
         "underscore", "underscores", "intricate", "multifaceted", "holistic", "synergy", "game-changer",
         "cutting-edge", "embark", "ever-evolving", "paradigm", "transformative", "empower", "empowering",
         "streamline", "meticulous", "meticulously", "bustling", "enhance", "boasts", "nestled",
         "groundbreaking", "revolutionize", "supercharge", "elevating", "resonate", "resonates"]
FILLER = ["really", "truly", "genuinely", "honestly", "literally", "simply", "actually", "deeply",
          "fundamentally", "importantly", "crucially", "interestingly", "essentially", "basically"]
PHRASES = [
    r"here'?s the thing", r"here'?s why", r"here'?s what", r"let that sink in", r"make no mistake",
    r"it'?s worth noting", r"at the end of the day", r"when it comes to", r"in today'?s [\w-]+",
    r"in a world where", r"at its core", r"the reality is", r"the truth is", r"let me be clear",
    r"full stop", r"plot twist", r"i hope this helps", r"great question", r"certainly!", r"absolutely!",
    r"as an ai", r"in conclusion", r"in summary", r"to sum up", r"dive (?:deep|into)", r"deep dive",
    r"game[- ]changer", r"(?:a|the) journey", r"rich (?:history|tapestry)", r"plays a (?:crucial|vital|key) role",
    r"serves as a", r"stands as a", r"not only .{1,60} but also", r"whether you'?re .{1,40} or",
    r"experts (?:say|believe)", r"studies show", r"many (?:people|experts) believe",
]
STRUCTURES = {
    "binary contrast": r"\b(?:it'?s|this is|that'?s|is|was|isn'?t|wasn'?t)\s+not\s+(?:just\s+|about\s+)?[^.,;]{1,50}[,;.]\s*(?:it'?s|but|this is|that'?s)\b",
    "negation reveal": r"\bthe (?:answer|question|problem|point) (?:isn'?t|is not) [^.]{1,60}\.\s*it'?s\b",
    "triad": r"\b\w+(?:\s\w+)?,\s\w+(?:\s\w+)?,?\s(?:and|or)\s\w+",
    "rhetorical setup": r"(?:^|\.\s)(?:what if|think about it|imagine|the result\?|the catch\?|the best part\?)",
    "dramatic fragment": r"(?:^|\.\s)\w+\.\s(?:that'?s it|period|full stop)\.",
}

def sentences(text):
    parts = re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", text))
    return [p for p in parts if len(p.split()) > 2]

def scan(text):
    issues = []
    for n, line in enumerate(text.splitlines(), 1):
        low = line.lower()
        for w in WORDS:
            if re.search(rf"\b{re.escape(w)}\b", low):
                issues.append((n, "inflated word", w))
        for w in FILLER:
            if re.search(rf"\b{w}\b", low):
                issues.append((n, "filler", w))
        for p in PHRASES:
            m = re.search(p, low)
            if m:
                issues.append((n, "stock phrase", m.group(0)))
        for name, p in STRUCTURES.items():
            m = re.search(p, low)
            if m:
                issues.append((n, name, m.group(0)[:70]))
        dashes = line.count("\u2014") + line.count(" -- ")
        if dashes:
            issues.append((n, "em dash", f"{dashes}x"))
    sents = sentences(text)
    lengths = [len(s.split()) for s in sents]
    stats = {"words": len(text.split()), "sentences": len(sents)}
    if len(lengths) >= 5:
        stats["avg_sentence_words"] = round(statistics.mean(lengths), 1)
        stats["sentence_length_stdev"] = round(statistics.pstdev(lengths), 1)
        runs = sum(1 for i in range(len(lengths) - 2)
                   if max(lengths[i:i + 3]) - min(lengths[i:i + 3]) <= 2)
        stats["even_rhythm_runs"] = runs
    stats["issues"] = len(issues)
    stats["issues_per_100_words"] = round(100 * len(issues) / max(1, stats["words"]), 1)
    return issues, stats

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    text = sys.stdin.read() if sys.argv[1] == "-" else open(sys.argv[1], encoding="utf-8").read()
    issues, stats = scan(text)
    if "--json" in sys.argv:
        print(json.dumps({"stats": stats, "issues": issues}, indent=2)); return
    for n, kind, hit in issues:
        print(f"line {n}: {kind}: {hit}")
    print("\n" + ", ".join(f"{k}={v}" for k, v in stats.items()))
    if stats.get("sentence_length_stdev", 99) < 4:
        print("rhythm: sentence lengths are very even. Mix short and long sentences.")

if __name__ == "__main__":
    main()
