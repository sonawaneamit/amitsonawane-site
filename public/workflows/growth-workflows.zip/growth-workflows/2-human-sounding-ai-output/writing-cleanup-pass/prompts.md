---
title: "Writing cleanup pass: prompts"
slug: "writing-cleanup-pass-prompts"
theme: "Make AI output sound human"
type: "prompts"
---

# Writing cleanup pass: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Clean a draft

Paste with the skill loaded.

```text
Use the writing-cleanup-pass skill on the draft below.

Audience and format: {{audience}}, {{format}}
Tone: {{tone}}
My writing sample (optional): {{paste 2-3 pieces or "none"}}

Keep every fact. Mark anything missing as [NEED: ...]. Return the cleaned text, the change table and the before/after scores.

DRAFT:
<<<
{{paste}}
>>>
```

## 2. Add to any writing prompt

Paste at the end of a prompt that asks an AI to write something.

```text
Writing rules: lead with the point. Plain words. Name who does what. Use specifics (numbers, examples) from my notes only; never invent them. Vary sentence length. No stock openers ("Here's the thing", "In today's world"), no "it's not X, it's Y" contrasts, no lists of three by default, no em dashes, no hype words (seamless, robust, game-changer, unlock, elevate, leverage, delve). No closing summary or offer to help further.
```

## 3. Diagnose only

When you want to fix it yourself.

```text
Read this text and list every AI-writing tell from the writing-cleanup-pass catalog, with the line and a one-line fix suggestion. Do not rewrite the text. Then give the 3 changes that would improve it most.

TEXT:
<<<
{{paste}}
>>>
```

## 4. Build my house style

Run once with samples of your writing.

```text
Here are {{n}} pieces I wrote myself: {{paste}}.
Write a one-page style sheet an editor could follow: typical sentence length, words and phrases I use, words I never use, how I open and close, how I use formatting, contractions, humour, and 5 before/after examples taken from my own text. I will add this to the writing-cleanup-pass skill.
```
