---
title: "Writing cleanup pass"
slug: "writing-cleanup-pass"
theme: "Make AI output sound human"
theme_slug: "human-sounding-ai-output"
theme_order: 2
order: 6
summary: "A two-pass edit that strips the patterns that make AI-written text read as AI: inflated words, stock phrases, formula structures and even rhythm. Keeps every fact and the writer's tone."
---

# Writing cleanup pass

A two-pass edit that strips the patterns that make AI-written text read as AI: inflated words, stock phrases, formula structures and even rhythm. Keeps every fact and the writer's tone.

| | |
|---|---|
| Theme | Make AI output sound human |
| Time | 2 to 10 minutes per piece |
| Works with | Any agent. The scan script runs anywhere Python does. |
| You get | A cleaned draft, a list of what changed and why, and a before/after scan score |

## When to use it

- Before you publish or send anything an AI drafted or helped draft.
- When a draft is correct but reads flat, salesy or machine-made.
- As the last step of any other workflow in this set that produces text.

## What you get

- The cleaned text.
- A short change log: each pattern found, where, and what replaced it.
- A before and after score from the scan script (tells per 100 words, rhythm).

## Inputs

| Input | Example | Needed |
|---|---|---|
| Draft | Any text | Yes |
| Audience and format | Cold email to clinic owners | Yes |
| Tone | Plain, direct, a bit warm | Optional |
| Writing sample | 2-3 pieces the person wrote themselves | Optional, improves voice |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Separate brief from text.** Know what the piece must say and for whom before touching it.
2. **Scan.** Run the scan script or read for the patterns in the catalog.
3. **Pass 1: cut.** Delete filler, stock phrases, chat leftovers and hand-holding.
4. **Pass 2: rebuild.** Fix structure and rhythm, name the actor, make claims specific.
5. **Check facts.** Every fact, number and name in the output was in the input.
6. **Rescan.** Compare scores and read it aloud once.

## Copy-paste prompts

### 1. Clean a draft

Paste with the skill loaded.

```text
Use the writing-cleanup-pass skill on the draft below.

Audience and format: {{audience}}, {{format}}
Tone: {{tone}}
My writing sample (optional): {{paste 2-3 pieces or "none"}}

Keep every fact. Mark anything missing as [NEED: ...]. Return the cleaned text, the change table and the before/after scores.

DRAFT:
<<<
{{paste}}
>>>
```

### 2. Add to any writing prompt

Paste at the end of a prompt that asks an AI to write something.

```text
Writing rules: lead with the point. Plain words. Name who does what. Use specifics (numbers, examples) from my notes only; never invent them. Vary sentence length. No stock openers ("Here's the thing", "In today's world"), no "it's not X, it's Y" contrasts, no lists of three by default, no em dashes, no hype words (seamless, robust, game-changer, unlock, elevate, leverage, delve). No closing summary or offer to help further.
```

### 3. Diagnose only

When you want to fix it yourself.

```text
Read this text and list every AI-writing tell from the writing-cleanup-pass catalog, with the line and a one-line fix suggestion. Do not rewrite the text. Then give the 3 changes that would improve it most.

TEXT:
<<<
{{paste}}
>>>
```

### 4. Build my house style

Run once with samples of your writing.

```text
Here are {{n}} pieces I wrote myself: {{paste}}.
Write a one-page style sheet an editor could follow: typical sentence length, words and phrases I use, words I never use, how I open and close, how I use formatting, contractions, humour, and 5 before/after examples taken from my own text. I will add this to the writing-cleanup-pass skill.
```

## Scoring rubric

| Check | Pass |
|---|---|
| Strong tells (catalog 1-6) | 0 |
| Structural tells | 1 or fewer per 300 words |
| Issues per 100 words (scan script) | under 2 for most formats |
| Sentence length spread (stdev) | 5+ words for prose |
| New facts in the output | 0 |
| Read-aloud stumbles | 0 |

## Templates

**Plain-word swaps**

| Instead of | Write |
|---|---|
| leverage, utilize | use |
| seamless | (say what does not break) |
| robust | (say what it handles) |
| navigate the landscape | deal with, choose between |
| unlock, empower | let, help |
| in order to | to |
| at this point in time | now |
| a wide range of | (name 2 of them) |

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`slop_scan.py` flags inflated words, filler, stock phrases, binary contrasts, triads, rhetorical setups, em dashes and even sentence rhythm, with line numbers and a score.

```bash
python3 scripts/slop_scan.py draft.md
cat draft.txt | python3 scripts/slop_scan.py -
python3 scripts/slop_scan.py draft.md --json
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-before.md`: An AI-drafted product update.
- `examples/example-after.md`: The same update after the cleanup pass.
- `examples/example-changes.md`: The change log and scores.

## Troubleshooting and tips

- **The cleaned text is shorter and less exciting.** Good. Add excitement with a specific fact (a number, a customer's words), not adjectives.
- **It keeps adding new tells while fixing old ones.** Run the scan after each pass and paste the hits back with "fix only these lines".
- **The writer likes a flagged word.** Keep it. The catalog is a list of defaults, not a ban list for every voice.
- **Formal documents.** Skip rhythm rules and contractions; keep the cuts for filler, inflation and vague attribution.
- **Non-English text.** The scan script's word lists are English. Ask the agent to apply the structural rules, which travel across languages.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `slop_scan.py`
