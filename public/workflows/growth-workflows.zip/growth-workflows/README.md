---
title: "Growth Workflows"
slug: "growth-workflows"
summary: "19 plug-and-play agent workflows for search, AI answers, writing, validation, outreach, content, ads and growth experiments."
order: 0
---

# Growth Workflows

19 workflows for finding customers and growing a product, written as skill files an AI agent can follow. Each one has the skill file, copy-paste prompts, example inputs and outputs, a scoring rubric or checklist, templates, and scripts where they help.

They work with any capable agent: chat assistants, coding agents and agents with browsers. Nothing here depends on one vendor.

## How to use a skill file

Every workflow folder has a `SKILL.md`. It tells the agent what to do, step by step, with inputs, data sources, output formats and guardrails.

1. **Any chat assistant.** Attach `SKILL.md` or paste it as your first message. Then paste prompt 1 from the folder's `prompts.md` with the placeholders filled in.
2. **Agents with a skills folder.** Copy the workflow folder into the agent's skills directory so the path ends in `<slug>/SKILL.md`. For example, Claude Code reads `.claude/skills/<slug>/SKILL.md` in a project and `~/.claude/skills/<slug>/SKILL.md` for all projects. Then ask: "Use the <slug> skill for {{your case}}". Check your agent's docs for its folder.
3. **Coding agents with rules or instruction files.** Put the folder in your project and point the agent at it: "Follow ./growth-workflows/<path>/SKILL.md".
4. **Assistants with projects or custom instructions.** Add `SKILL.md` (and the examples) to the project's files, then start each chat with prompt 1.

Tips:

- Fill every `{{placeholder}}` before you send a prompt. Specific beats broad.
- Give the agent web access or a browser when the workflow collects data. Most workflows also accept pasted text.
- Scripts in `scripts/` need only Python 3 (standard library). Run them yourself or let the agent run them.
- Everything in `examples/` is invented data that shows the format.
- Outputs from one workflow feed others. Pain-point mining feeds the smoke test; lead sourcing feeds cold outbound; the writing cleanup pass works on everything.

## Index

### 1. Get found in search and AI answers

- **[AI-answer visibility](1-search-and-ai-answers/ai-answer-visibility/README.md)** (`ai-answer-visibility`): Find out whether AI assistants mention you when buyers ask about your category, see which sources they cite instead, and fix the gaps on your site and around the web.
- **[Keyword and programmatic pages](1-search-and-ai-answers/keyword-and-programmatic-pages/README.md)** (`keyword-and-programmatic-pages`): Pick a low-competition keyword with many long-tail variants, build the product or page set around it, and generate one genuinely useful page per entity from your own data.
- **[Competitor gap mining](1-search-and-ai-answers/competitor-gap-mining/README.md)** (`competitor-gap-mining`): Work out what competitors do to grow from public files and public data: hidden landing pages, new pages in their sitemaps, long-running ads, pricing changes, and the keywords and pages you are missing.
- **[Ranking on community platforms and video review searches](1-search-and-ai-answers/community-and-video-search/README.md)** (`community-and-video-search`): Show up where buyers research before they buy: community threads that already rank for 'best X', and video searches like 'X honest review' and 'X vs Y'. Done in the open, with real help and disclosed affiliation.
- **[Weekly SEO upkeep loop](1-search-and-ai-answers/weekly-seo-upkeep/README.md)** (`weekly-seo-upkeep`): A one-hour weekly routine on Search Console data: push pages sitting in positions 4 to 20, rewrite titles with low click-through, add internal links, and refresh facts on pages that already rank.

### 2. Make AI output sound human

- **[Writing cleanup pass](2-human-sounding-ai-output/writing-cleanup-pass/README.md)** (`writing-cleanup-pass`): A two-pass edit that strips the patterns that make AI-written text read as AI: inflated words, stock phrases, formula structures and even rhythm. Keeps every fact and the writer's tone.
- **[Voice-matched drafting loop](2-human-sounding-ai-output/voice-matched-drafting/README.md)** (`voice-matched-drafting`): Turn a pile of your own past writing into a voice profile and a drafting loop that gets measurably closer to how you write, tracked by how much you edit each draft.
- **[Code and UI slop check](2-human-sounding-ai-output/code-ui-slop-check/README.md)** (`code-ui-slop-check`): A review pass for AI-written app code and interface copy: catch type escapes, swallowed errors and leftover debug code, then cut UI text down with a deletion ladder and keep the design system consistent.

### 3. Validate before you build

- **[Pain-point mining](3-validate-before-you-build/pain-point-mining/README.md)** (`pain-point-mining`): Find and rank the problems your target customers already complain about in public, with real quotes, before you build anything.
- **[Smoke test with a fake door and payment link](3-validate-before-you-build/smoke-test-fake-door/README.md)** (`smoke-test-fake-door`): Put a promise in front of real people before you build: a mockup, a one-page offer, daily short videos and a way to sign up or pay a deposit. Let the numbers pick the idea.
- **[Simulated first users](3-validate-before-you-build/simulated-first-users/README.md)** (`simulated-first-users`): Before a launch, send 5 agent personas through your product in a real browser, from landing page to first success. Get one ranked list of where people get stuck, fix it, and rerun.

### 4. Find and reach customers

- **[Lead sourcing and enrichment](4-find-and-reach-customers/lead-sourcing-enrichment/README.md)** (`lead-sourcing-enrichment`): Build a small, accurate list of the right companies and people from public sources, add a reason to contact each one, clean and score it, and hand it to outreach.
- **[Cold outbound that stays out of spam](4-find-and-reach-customers/cold-outbound-at-volume/README.md)** (`cold-outbound-at-volume`): Set up separate sending domains, authenticate and warm them, write short signal-based emails, send at low per-inbox caps, and run a weekly review on replies, bounces and complaints, inside the law.
- **[Community and competitor-switcher outreach](4-find-and-reach-customers/community-competitor-outreach/README.md)** (`community-competitor-outreach`): Find people who say in public that they need what you offer, or that a competing tool lets them down, and reach them honestly: helpful public replies first, disclosed affiliation, and one-to-one messages only where the platform and the person allow it.

### 5. AI-run content and ads

- **[Content repurposing engine](5-ai-run-content-and-ads/content-repurposing-engine/README.md)** (`content-repurposing-engine`): Turn one strong idea or a few voice notes into a month of posts across formats, using patterns from your own best posts, with you approving everything before it goes out.
- **[Ad research and daily ads loop](5-ai-run-content-and-ads/ad-research-ads-loop/README.md)** (`ad-research-ads-loop`): Study long-running ads in public ad libraries to find angles that last, turn them into your own briefs, and run a daily health check that flags ads to pause, refresh or scale, with you approving every budget change.
- **[Copy and landing page stress test](5-ai-run-content-and-ads/copy-landing-stress-test/README.md)** (`copy-landing-stress-test`): Put a landing page or ad through readability checks, three skeptical buyer personas, an objection gauntlet and a friction audit, then rewrite and repeat until it clears a set score.

### 6. Growth experiments

- **[Channel test cadence](6-growth-experiments/channel-test-cadence/README.md)** (`channel-test-cadence`): Test growth channels one at a time on a fixed cadence with a written hypothesis, a budget and a kill line, count your own hours as cost, and go deep on the one that pays. Includes creator tests and an honest review prompt for apps.
- **[Creative and thumbnail testing](6-growth-experiments/creative-thumbnail-testing/README.md)** (`creative-thumbnail-testing`): Generate many variants of a thumbnail, hook or ad, pretest them cheaply with small ad budgets or built-in platform tests, change one thing at a time, and only call a winner when the numbers are big enough.

## Folder layout

```text
growth-workflows/
  README.md            this file
  manifest.json        machine-readable index for publishing
  <n>-<theme-slug>/
    <slug>/
      README.md        the human page: when to use, what you get, how to run, prompts, rubric, tips
      SKILL.md         the skill file for the agent
      prompts.md       copy-paste prompts on their own
      examples/        example inputs and outputs (invented data)
      scripts/         optional Python helpers
```

## Note for a coding agent publishing these on a website

- Read `manifest.json`. It is an array with one entry per workflow: `slug`, `title`, `theme`, `theme_slug`, `theme_order`, `order`, `summary`, `path`, `files[]`. Sort by `theme_order`, then `order`.
- Make one page per workflow from its `README.md`. The frontmatter holds `title`, `slug`, `theme`, `theme_slug`, `theme_order`, `order` and `summary`; the body is plain markdown (GitHub-flavoured: tables and fenced code blocks).
- Suggested URLs: `/workflows/<slug>`, with theme index pages at `/workflows/theme/<theme_slug>` and this README as `/workflows`.
- Give every fenced code block a copy button. Prompts are in ```text blocks.
- Offer each workflow folder as a download (zip), and link `SKILL.md` on its own as "Download skill file". Serve `.md`, `.py`, `.csv`, `.json` and `.jsonl` files as plain text.
- Links between files are relative (`examples/...`, `scripts/...`). Rewrite them to your download URLs or render them as file links.
- `SKILL.md` and `prompts.md` keep their own frontmatter. Do not merge it into the page frontmatter.
