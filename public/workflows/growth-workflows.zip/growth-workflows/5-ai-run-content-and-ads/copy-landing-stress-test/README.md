---
title: "Copy and landing page stress test"
slug: "copy-landing-stress-test"
theme: "AI-run content and ads"
theme_slug: "ai-run-content-and-ads"
theme_order: 5
order: 17
summary: "Put a landing page or ad through readability checks, three skeptical buyer personas, an objection gauntlet and a friction audit, then rewrite and repeat until it clears a set score."
---

# Copy and landing page stress test

Put a landing page or ad through readability checks, three skeptical buyer personas, an objection gauntlet and a friction audit, then rewrite and repeat until it clears a set score.

| | |
|---|---|
| Theme | AI-run content and ads |
| Time | 30 to 90 minutes per page |
| Works with | Any agent. Works on pasted copy, a URL the agent can read, or a screenshot. |
| You get | A scored audit, a ranked fix list, a rewritten page, and a before/after score |

## When to use it

- A page is about to get paid traffic.
- Traffic is fine but sign-ups are low.
- You wrote the copy yourself and cannot see it fresh.

## What you get

- A scorecard (0-100) across clarity, specificity, objections, friction and trust.
- Persona reactions and the objections the page fails to answer.
- A ranked fix list and a rewritten page.

## Inputs

| Input | Example | Needed |
|---|---|---|
| The page or copy | URL, paste, or screenshot | Yes |
| Who it is for | Solo mobile groomers, 1 van | Yes |
| The one action | Start a free trial | Yes |
| Proof you hold | Numbers, reviews, guarantees | Yes |
| Customer words | From reviews, calls or pain-point-mining | Recommended |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Fluency check.** Script: reading ease, long sentences, jargon.
2. **5-second test.** What is it, for whom, what to do?
3. **Personas.** Three skeptical buyers read and react.
4. **Objection gauntlet.** Top objections; does the page answer each?
5. **Specificity and friction audits.** Vague claims; cognitive, emotional, UX, trust friction.
6. **Score, rewrite, repeat.** Until the score threshold or 3 rounds.

## Copy-paste prompts

### 1. Full stress test

Paste with the skill loaded.

```text
Use the copy-landing-stress-test skill.
Page: {{url or paste}}
For: {{audience}}. Action: {{action}}.
Proof we hold: {{proof}}
Customer words: {{quotes or "none"}}
Run all steps, score with the rubric, then give the ranked fix list and a rewrite. Repeat with fresh personas until the score is {{75}}+ or 3 rounds. Do not invent proof.
```

### 2. Persona read

Run each persona in a fresh session.

```text
You are {{persona description}}. You found this page while {{situation}}. Read it as that person would, top to bottom: {{page}}.
Say out loud where you hesitate, what you don't believe, what is missing, and whether you take the action ({{action}}). Be honest and specific. Quote the lines that caused each reaction.
```

### 3. Objection gauntlet

When you have customer words.

```text
Customer words: {{paste reviews, calls, threads}}. Page: {{page}}.
List the 10 most likely objections to {{action}}, in the customers' words. For each: answered on the page? where? score 0-2. Then write the missing answers using only this proof: {{proof}}.
```

### 4. Ad copy version

For ads instead of pages.

```text
Stress-test these ad variants for {{platform}}: {{paste}}.
For each: 5-second test on the first line, specificity audit, top objection it raises, and fluency. Score each 0-10 and rewrite the bottom two.
```

## Scoring rubric

**Score (100)**

| Area | Points | Full marks when |
|---|---|---|
| 5-second clarity | 20 | All four questions answered correctly |
| Specificity | 15 | 80%+ of claims are specific |
| Objections | 20 | Top 5 objections scored 2 |
| Persona outcomes | 15 | 2 of 3 personas say yes or maybe with a clear reason |
| Friction | 15 | No high-severity items |
| Trust | 10 | Real proof, contact details, risk reversal |
| Fluency | 5 | Reading ease 60+, no jargon flags |

Pass: 75+. Below 60: fix before any paid traffic.

## Templates

**Fix list**

`| # | Fix | Area | Severity | Evidence (persona, objection or audit line) |`

**Page skeleton that usually clears the test**

1. Headline: the outcome, for whom. 2. Subhead: how, in one line. 3. Button with the action and the risk reversal. 4. Proof near the top. 5. How it works in 3 steps. 6. Objections as short answers. 7. Price. 8. Button again.

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`readability.py` reports words per sentence, long-word share, Flesch reading ease, grade level, long paragraphs, sentence runs, passive-voice hints and jargon (list at the top of the script).

```bash
python3 scripts/readability.py page.md
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-before.md`: A made-up landing page section before the test.
- `examples/example-before-readability.txt`: Real script output for the page above.
- `examples/example-after.md`: The same section after one round.
- `examples/example-after-readability.txt`: Real script output after the rewrite.
- `examples/example-audit.md`: The audit and score for the before page.

## Troubleshooting and tips

- **Personas agree with each other too much.** Run each in a fresh session, give each a different situation, and ask for the strongest reason to say no.
- **The rewrite lost the brand voice.** Give the agent 2-3 pages you like as voice examples, and run the writing-cleanup-pass skill after.
- **Score is high but conversion is still low.** The test is a simulation. Check traffic quality and the offer, then A/B test the top fix.
- **No customer words.** Run the pain-point-mining skill first; objections in real words make this test far better.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `readability.py`
