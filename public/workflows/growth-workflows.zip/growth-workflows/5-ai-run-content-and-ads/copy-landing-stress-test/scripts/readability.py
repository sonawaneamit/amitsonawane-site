#!/usr/bin/env python3
"""Processing-fluency check for ad and landing-page copy. Standard library only.

Reports per paragraph and overall: words per sentence, long words (3+ syllables),
Flesch reading ease (higher = easier; 60-70 is plain English, 80+ is very easy),
grade level, paragraphs over 4 sentences, three long or three short sentences
in a row, passive-voice hints, and jargon from a small list you can extend.

Usage:
  python3 readability.py page.md
"""
import re, sys

JARGON = ["leverage", "synergy", "utilize", "facilitate", "optimize", "solution", "seamless", "robust",
          "best-in-class", "end-to-end", "scalable", "innovative", "holistic", "paradigm", "ecosystem",
          "empower", "streamline", "cutting-edge", "next-generation", "world-class"]

def syllables(w):
    w = w.lower().strip(".,!?;:\"'()")
    if not w:
        return 0
    groups = re.findall(r"[aeiouy]+", w)
    n = len(groups)
    if w.endswith("e") and n > 1 and not w.endswith(("le", "ee")):
        n -= 1
    return max(1, n)

def sents(text):
    return [s for s in re.split(r"(?<=[.!?])\s+", text.strip()) if re.search(r"\w", s)]

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    raw = open(sys.argv[1], encoding="utf-8").read()
    raw = re.sub(r"(?m)^\s*[#>*-]+\s*", "", raw)
    paras = [p.strip() for p in re.split(r"\n\s*\n", raw) if p.strip()]
    all_s, all_w, flags = [], [], []
    for i, p in enumerate(paras, 1):
        ss = sents(p)
        all_s += ss
        all_w += re.findall(r"[A-Za-z']+", p)
        if len(ss) > 4:
            flags.append(f"paragraph {i}: {len(ss)} sentences (max 4)")
        lens = [len(s.split()) for s in ss]
        for j in range(len(lens) - 2):
            trio = lens[j:j + 3]
            if min(trio) >= 20:
                flags.append(f"paragraph {i}: three long sentences in a row")
            if max(trio) <= 6:
                flags.append(f"paragraph {i}: three very short sentences in a row")
        for s in ss:
            if len(s.split()) > 25:
                flags.append(f"paragraph {i}: long sentence ({len(s.split())} words): {s[:80]}...")
            if re.search(r"\b(?:is|are|was|were|be|been|being)\s+\w+ed\b", s):
                flags.append(f"paragraph {i}: passive voice? {s[:80]}")
        for w in JARGON:
            stem = re.escape(w[:-1] if w.endswith("e") else w)
            if re.search(rf"\b{stem}(?:e|es|s|d|ed|ing|ation|ations)?\b", p, re.I):
                flags.append(f"paragraph {i}: jargon '{w}'")
    nw, ns = max(1, len(all_w)), max(1, len(all_s))
    syl = sum(syllables(w) for w in all_w)
    long_words = sum(1 for w in all_w if syllables(w) >= 3)
    fre = 206.835 - 1.015 * (nw / ns) - 84.6 * (syl / nw)
    grade = 0.39 * (nw / ns) + 11.8 * (syl / nw) - 15.59
    print(f"words {nw}, sentences {ns}, words/sentence {nw/ns:.1f}, long words {long_words/nw:.0%}")
    print(f"Flesch reading ease {fre:.0f}, grade level {grade:.1f}\n")
    for fl in flags:
        print("-", fl)
    if not flags:
        print("no flags")

if __name__ == "__main__":
    main()
