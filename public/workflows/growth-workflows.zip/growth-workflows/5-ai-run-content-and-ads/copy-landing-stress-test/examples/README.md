# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-before.md`: A made-up landing page section before the test.
- `example-before-readability.txt`: Real script output for the page above.
- `example-after.md`: The same section after one round.
- `example-after-readability.txt`: Real script output after the rewrite.
- `example-audit.md`: The audit and score for the before page.
