# Stress test round 1 (EXAMPLE DATA)

Score: 34/100

## 5-second test
- What is it? "Some kind of business platform." Wrong (too vague).
- Who for? "Pet care professionals." Partly.
- What to do? "Start your journey." Unclear.

## Personas
- Skeptic: "All-in-one, best-in-class: says who? No numbers, no reviews." No.
- Busy one: left at the second paragraph (30-word sentence). No.
- Comparer: "Can't tell how this beats the paper diary." No.

## Top objections not answered
1. Will my clients actually book online? (0)
2. What does it cost? (0)
3. How long to set up? (0)

## Fix list
| # | Fix | Area | Severity |
|---|---|---|---|
| 1 | Headline says the outcome: bookings plus deposits | Clarity | High |
| 2 | Replace jargon paragraph with what happens when a client books | Specificity | High |
| 3 | Button: "Try it free for 14 days" + "No card needed" | Friction | High |
| 4 | Add price and setup time | Objections | Medium |

Round 2 score: 78/100 (passes).
