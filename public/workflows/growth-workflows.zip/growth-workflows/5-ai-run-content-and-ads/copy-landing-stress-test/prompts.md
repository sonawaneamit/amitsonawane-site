---
title: "Copy and landing page stress test: prompts"
slug: "copy-landing-stress-test-prompts"
theme: "AI-run content and ads"
type: "prompts"
---

# Copy and landing page stress test: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Full stress test

Paste with the skill loaded.

```text
Use the copy-landing-stress-test skill.
Page: {{url or paste}}
For: {{audience}}. Action: {{action}}.
Proof we hold: {{proof}}
Customer words: {{quotes or "none"}}
Run all steps, score with the rubric, then give the ranked fix list and a rewrite. Repeat with fresh personas until the score is {{75}}+ or 3 rounds. Do not invent proof.
```

## 2. Persona read

Run each persona in a fresh session.

```text
You are {{persona description}}. You found this page while {{situation}}. Read it as that person would, top to bottom: {{page}}.
Say out loud where you hesitate, what you don't believe, what is missing, and whether you take the action ({{action}}). Be honest and specific. Quote the lines that caused each reaction.
```

## 3. Objection gauntlet

When you have customer words.

```text
Customer words: {{paste reviews, calls, threads}}. Page: {{page}}.
List the 10 most likely objections to {{action}}, in the customers' words. For each: answered on the page? where? score 0-2. Then write the missing answers using only this proof: {{proof}}.
```

## 4. Ad copy version

For ads instead of pages.

```text
Stress-test these ad variants for {{platform}}: {{paste}}.
For each: 5-second test on the first line, specificity audit, top objection it raises, and fluency. Score each 0-10 and rewrite the bottom two.
```
