#!/usr/bin/env python3
"""Daily ads health check from an ad-level daily export. Standard library only.

Input CSV, one row per ad per day, columns (names matched loosely):
  date, campaign, ad, spend, impressions, clicks, conversions, frequency (optional)
Export it from the ads manager (breakdown by day, level = ad) or pull it from
the platform API. Target CPA comes from you.

Rules (edit THRESHOLDS to taste; they are starting points, not laws):
  PAUSE    CPA above 2.5x target over the last 2 days with real spend,
           or spend above 3x target CPA with zero conversions
  FATIGUE  frequency above 3.5, or CTR down 30%+ vs the ad's first 3 days
  SCALE    CPA at or below 0.7x target over the last 3 days with 3+ conversions
  WATCH    everything else with spend

Writes ads_brief.md: what to pause, refresh, scale, plus account totals.
Usage:
  python3 ads_health.py daily.csv --target-cpa 40
"""
import csv, sys
from collections import defaultdict

THRESHOLDS = {"pause_cpa_x": 2.5, "pause_nospend_x": 3.0, "fatigue_freq": 3.5,
              "ctr_drop": 0.30, "scale_cpa_x": 0.7, "scale_min_conv": 3}

def f(v):
    try:
        return float(str(v).replace(",", "").replace("$", "").replace("%", "") or 0)
    except ValueError:
        return 0.0

def g(r, *names):
    for k in r:
        if k.strip().lower() in names:
            return r[k]
    return ""

def main():
    if len(sys.argv) < 2 or "--target-cpa" not in sys.argv:
        sys.exit(__doc__)
    target = float(sys.argv[sys.argv.index("--target-cpa") + 1])
    ads = defaultdict(list)
    for r in csv.DictReader(open(sys.argv[1], newline="", encoding="utf-8-sig")):
        key = (g(r, "campaign", "campaign name"), g(r, "ad", "ad name"))
        ads[key].append({"date": g(r, "date", "day", "reporting starts"), "spend": f(g(r, "spend", "amount spent", "cost")),
                         "impr": f(g(r, "impressions")), "clicks": f(g(r, "clicks", "link clicks")),
                         "conv": f(g(r, "conversions", "results", "purchases", "leads")),
                         "freq": f(g(r, "frequency"))})
    out = {"PAUSE": [], "FATIGUE": [], "SCALE": [], "WATCH": []}
    tot = {"spend": 0, "conv": 0}
    for (camp, ad), days in ads.items():
        days.sort(key=lambda d: d["date"])
        for d in days:
            tot["spend"] += d["spend"]; tot["conv"] += d["conv"]
        last2, last3, first3 = days[-2:], days[-3:], days[:3]
        s2, c2 = sum(d["spend"] for d in last2), sum(d["conv"] for d in last2)
        s3, c3 = sum(d["spend"] for d in last3), sum(d["conv"] for d in last3)
        ctr = lambda ds: (sum(d["clicks"] for d in ds) / sum(d["impr"] for d in ds)) if sum(d["impr"] for d in ds) else 0
        ctr_now, ctr_start = ctr(last3), ctr(first3)
        freq = max((d["freq"] for d in last3), default=0)
        name = f"{camp} / {ad}"
        cpa2 = s2 / c2 if c2 else None
        if (cpa2 and cpa2 > THRESHOLDS["pause_cpa_x"] * target) or (not c2 and s2 > THRESHOLDS["pause_nospend_x"] * target):
            out["PAUSE"].append(f"{name}: last 2 days spend {s2:.0f}, conversions {c2:.0f}, CPA {cpa2:.0f}" if cpa2 else f"{name}: last 2 days spend {s2:.0f}, no conversions")
        elif freq > THRESHOLDS["fatigue_freq"] or (len(days) >= 6 and ctr_start and ctr_now < (1 - THRESHOLDS["ctr_drop"]) * ctr_start):
            out["FATIGUE"].append(f"{name}: frequency {freq:.1f}, CTR {ctr_start:.2%} -> {ctr_now:.2%}")
        elif c3 >= THRESHOLDS["scale_min_conv"] and s3 / c3 <= THRESHOLDS["scale_cpa_x"] * target:
            out["SCALE"].append(f"{name}: last 3 days CPA {s3/c3:.0f} on {c3:.0f} conversions")
        elif s3 > 0:
            out["WATCH"].append(f"{name}: last 3 days spend {s3:.0f}, conversions {c3:.0f}")
    lines = [f"# Ads brief", "", f"Target CPA {target:.0f}. Account: spend {tot['spend']:.0f}, conversions {tot['conv']:.0f}, CPA {tot['spend']/tot['conv']:.0f}" if tot["conv"] else f"Target CPA {target:.0f}. Account spend {tot['spend']:.0f}, no conversions", ""]
    labels = {"PAUSE": "Pause (needs your OK)", "FATIGUE": "Refresh creative", "SCALE": "Scale 20-30% (needs your OK)", "WATCH": "Watch"}
    for k, items in out.items():
        lines += [f"## {labels[k]} ({len(items)})"] + [f"- {i}" for i in items] + [""]
    open("ads_brief.md", "w", encoding="utf-8").write("\n".join(lines))
    print("\n".join(lines))

if __name__ == "__main__":
    main()
