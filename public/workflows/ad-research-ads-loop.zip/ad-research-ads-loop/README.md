---
title: "Ad research and daily ads loop"
slug: "ad-research-ads-loop"
theme: "AI-run content and ads"
theme_slug: "ai-run-content-and-ads"
theme_order: 5
order: 16
summary: "Study long-running ads in public ad libraries to find angles that last, turn them into your own briefs, and run a daily health check that flags ads to pause, refresh or scale, with you approving every budget change."
---

# Ad research and daily ads loop

Study long-running ads in public ad libraries to find angles that last, turn them into your own briefs, and run a daily health check that flags ads to pause, refresh or scale, with you approving every budget change.

| | |
|---|---|
| Theme | AI-run content and ads |
| Time | 3 hours to start, then 15 minutes a day |
| Works with | Any agent with a browser for ad libraries. A daily ad-level export or an ads API connection for the loop. |
| You get | An angle bank from public ads, creative briefs, and a daily ads brief with pause, refresh and scale calls |

## When to use it

- You are about to start paid ads and need angles that are proven in your category.
- You run ads but check them only when something looks wrong.
- Creative goes stale and you notice too late.

## What you get

- `angle_bank.md`: hooks, angles, formats and offers seen in long-running ads.
- Creative briefs for your own ads.
- `ads_brief.md` every day: pause, refresh, scale and watch lists.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Competitors and category terms | 3-10 brands, 3-5 search terms | Yes |
| Target CPA | 40 per trial start | Yes |
| Daily ad-level data | Export or API: date, ad, spend, impressions, clicks, conversions, frequency | For the loop |
| Brand rules | What you can and cannot claim | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Search ad libraries.** Competitors and category terms; note run length.
2. **Pick long runners.** Ads running 60+ days usually earn their spend.
3. **Build the angle bank.** Hook, angle, format, offer, proof type.
4. **Write briefs.** Your own versions, from your real proof.
5. **Daily check.** Script on yesterday's data; brief with calls.
6. **Approve changes.** You OK every pause, scale or budget move.

## Copy-paste prompts

### 1. Research a category

With a browser.

```text
Use the ad-research-ads-loop skill, part A.
Competitors: {{list}}. Category terms: {{terms}}. Countries: {{countries}}.
Search the public ad libraries in the browser. Save up to 30 ads running 60+ days. Build angle_bank.md. Then write 3 briefs for {{product}} using only this proof: {{proof}}.
```

### 2. Daily check

Every morning.

```text
Use the ad-research-ads-loop skill, part B.
Data: {{attached daily.csv or "pull from the ads connector, last 14 days, ad level, read-only"}}. Target CPA: {{target}}.
Run ads_health.py, add judgment notes (tracking, holidays, learning phase), and send me ads_brief.md. Change nothing.
```

### 3. Refresh a fatigued ad

For each FATIGUE item.

```text
This ad is fatigued: {{ad copy/description, numbers}}. Its angle: {{angle}}.
Write 3 new versions that keep the angle and change the hook and visual idea. Use only this proof: {{proof}}. Note what each version tests.
```

## Scoring rubric

**Daily brief check**

- [ ] Data covers the last 7-14 days at ad level
- [ ] Each PAUSE and SCALE has numbers and needs approval
- [ ] Judgment notes added (tracking, holidays, learning phase)
- [ ] No changes made without approval
- [ ] Changes logged

**Brief quality**: angle from the bank; 3 hooks; only proof you hold; original copy; compliance notes.

## Templates

**angle_bank.md row**

`| angle | long runners | example hooks (paraphrased) | formats | offers |`

**Creative brief**

```markdown
## Brief: {{angle}}
Audience: ...
Hooks: 1) ... 2) ... 3) ...
Format: ...
Proof we hold: ...
Offer and CTA: ...
Policy notes: ...
Success: CPA under {{target}} after {{n}} conversions
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`ads_health.py` reads a daily ad-level CSV (column names matched loosely) and writes `ads_brief.md`. Thresholds are at the top of the script.

```bash
python3 scripts/ads_health.py daily.csv --target-cpa 40
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-daily.csv`: Made-up daily ad-level data for 4 ads over 7 days.
- `examples/example-ads_brief.md`: Real script output for the data above.
- `examples/example-angle_bank.md`: An angle bank from a made-up category scan.

## Troubleshooting and tips

- **The ad library will not load in a script.** Expected. Use a browser session. Note what you saw by hand if screenshots are not possible.
- **Everything looks like PAUSE after a tracking issue.** Fix tracking, then judge. Write the outage into the brief so no one acts on bad data.
- **Few conversions a day.** Raise the window: judge on 7 days instead of 2-3, or use a higher-volume event (lead, add to cart) as a proxy.
- **Scaling broke a winner.** Raise budget 20-30% at a time with a few days between steps, or duplicate into a new ad set.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `ads_health.py`
