---
title: "Ad research and daily ads loop: prompts"
slug: "ad-research-ads-loop-prompts"
theme: "AI-run content and ads"
type: "prompts"
---

# Ad research and daily ads loop: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Research a category

With a browser.

```text
Use the ad-research-ads-loop skill, part A.
Competitors: {{list}}. Category terms: {{terms}}. Countries: {{countries}}.
Search the public ad libraries in the browser. Save up to 30 ads running 60+ days. Build angle_bank.md. Then write 3 briefs for {{product}} using only this proof: {{proof}}.
```

## 2. Daily check

Every morning.

```text
Use the ad-research-ads-loop skill, part B.
Data: {{attached daily.csv or "pull from the ads connector, last 14 days, ad level, read-only"}}. Target CPA: {{target}}.
Run ads_health.py, add judgment notes (tracking, holidays, learning phase), and send me ads_brief.md. Change nothing.
```

## 3. Refresh a fatigued ad

For each FATIGUE item.

```text
This ad is fatigued: {{ad copy/description, numbers}}. Its angle: {{angle}}.
Write 3 new versions that keep the angle and change the hook and visual idea. Use only this proof: {{proof}}. Note what each version tests.
```
