# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-daily.csv`: Made-up daily ad-level data for 4 ads over 7 days.
- `example-ads_brief.md`: Real script output for the data above.
- `example-angle_bank.md`: An angle bank from a made-up category scan.
