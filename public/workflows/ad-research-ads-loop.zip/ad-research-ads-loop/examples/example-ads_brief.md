# Ads brief

Target CPA 40. Account: spend 945, conversions 28, CPA 34

## Pause (needs your OK) (1)
- Groomers US / A2 route-static: last 2 days spend 140, no conversions

## Refresh creative (1)
- Groomers US / A3 no-show-video: frequency 5.2, CTR 1.37% -> 0.95%

## Scale 20-30% (needs your OK) (1)
- Groomers US / A1 deposit-ugc: last 3 days CPA 10 on 6 conversions

## Watch (1)
- Groomers US / A4 price-carousel: last 3 days spend 45, conversions 0
