---
title: "Code and UI slop check"
slug: "code-ui-slop-check"
theme: "Make AI output sound human"
theme_slug: "human-sounding-ai-output"
theme_order: 2
order: 8
summary: "A review pass for AI-written app code and interface copy: catch type escapes, swallowed errors and leftover debug code, then cut UI text down with a deletion ladder and keep the design system consistent."
---

# Code and UI slop check

A review pass for AI-written app code and interface copy: catch type escapes, swallowed errors and leftover debug code, then cut UI text down with a deletion ladder and keep the design system consistent.

| | |
|---|---|
| Theme | Make AI output sound human |
| Time | 15 to 45 minutes per feature |
| Works with | Coding agents (any). The scan script works on TypeScript, JavaScript, Vue, Svelte and HTML. |
| You get | A findings list, fixed code, shorter UI copy, and lint rules so the same issues do not come back |

## When to use it

- An agent wrote most of a feature and you are about to merge it.
- The app works but the interface feels wordy, cluttered or inconsistent.
- You keep fixing the same AI habits in review.

## What you get

- `findings.md`: each issue with file, line, severity and fix.
- A copy table: every visible string, its shorter version, or deleted.
- Lint rules and agent-instruction lines that block repeat issues.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Code to review | A branch, PR diff or folder | Yes |
| Design system | Tokens file, component list | Optional |
| Product voice | 2-3 lines on how the UI talks | Optional |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Scan.** Run the script on the changed folders.
2. **Code review.** Fix type escapes, error handling, debug leftovers, long functions.
3. **Copy ladder.** Delete, shorten, then rewrite every visible string.
4. **Design hygiene.** Tokens, spacing, components and states.
5. **Prevent.** Add lint rules and agent instructions for repeat findings.

## Copy-paste prompts

### 1. Review a branch

In a coding agent, with the skill loaded.

```text
Use the code-ui-slop-check skill on {{branch or folder}}.
Design system: {{tokens file / component folder / "none"}}
Product voice: {{2-3 lines}}

Run the scan, review the code, run the copy ladder on every visible string and check design hygiene. Write findings.md first and wait for my OK. Then fix in small commits and run the tests after each.
```

### 2. Copy ladder only

Paste strings from a screen.

```text
Here are all visible strings on the {{screen}} screen: {{paste}}.
For each, apply the deletion ladder: delete, replace with UI, shorten, rewrite. Return a table: string, step used, result (or DELETE), reason. Keep legal and safety text.
```

### 3. Write my guard rules

After 2-3 reviews.

```text
Here are findings from the last {{n}} reviews: {{paste findings.md files}}.
Group repeat issues. For each group seen 3+ times, write (1) a lint rule config for {{eslint / biome / oxlint}} if one exists, and (2) a line for my agent instructions file with one bad and one good example. Do not invent rule names; if unsure a rule exists, say so.
```

## Scoring rubric

**Merge checklist**

- [ ] 0 empty or swallow-all catch blocks
- [ ] 0 `as any` / ts-ignore without a reason comment
- [ ] 0 console.log and commented-out code
- [ ] Every visible string went through the ladder
- [ ] Buttons say the result; errors say what to do next
- [ ] Raw colour and spacing values replaced with tokens
- [ ] Focus, disabled, loading and error states present
- [ ] Tests pass
- [ ] Repeat findings turned into a guard

## Templates

**Error message pattern**: what happened + what to do. "Couldn't save your booking. Check your connection and try again."

**Empty state pattern**: what goes here + the action. "No bookings yet. Share your booking link."

**Agent instruction line**

```markdown
- Never leave an empty catch. Bad: `catch (e) {}`. Good: `catch (e) { showError("Couldn't save. Try again."); throw e; }`
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`code_slop_scan.py` walks a folder (skipping node_modules, build output and .git) and prints each finding with file and line, then a summary.

```bash
python3 scripts/code_slop_scan.py src
python3 scripts/code_slop_scan.py app --ext .tsx,.ts --max-fn-lines 60
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-BookingForm.tsx`: An AI-written component with typical issues.
- `examples/example-scan-output.txt`: Real output of code_slop_scan.py on the file above.
- `examples/example-findings.md`: The review written from the scan plus manual checks.

## Troubleshooting and tips

- **Too many findings to fix at once.** Fix High first in this PR, open an issue for the rest, and add guards so the count stops growing.
- **The script flags `!` in a string or a not-equals.** It is a pattern match, so it has false positives. Treat it as a pointer, not a verdict.
- **Designers or PMs disagree with copy cuts.** Show before and after screenshots side by side; keep anything with a clear job.
- **Not a JS/TS project.** The code checks are JS/TS-specific; the copy ladder, design hygiene and guard steps apply to any stack.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `code_slop_scan.py`
