import { useState } from "react";

export function BookingForm({ slots }: { slots: any }) {
  const [sel, setSel] = useState<string | null>(null);
  // TODO fix later
  async function submit() {
    try {
      const res = await fetch("/api/book", { method: "POST", body: JSON.stringify({ slot: sel }) });
      const data = (await res.json()) as any;
      console.log(data);
      return data.booking!.id;
    } catch (e) {}
  }
  return (
    <div>
      <h2>Simply pick a time that works for you and we'll take care of the rest!</h2>
      <p>Please note that you can easily change your booking later. Don't worry!</p>
      {slots.filter((s: any) => s.open).map((s: any) => <button onClick={() => setSel(s.id)}>{s.label}</button>)}
      <button onClick={submit}>Click here to submit your booking request now</button>
    </div>
  );
}
