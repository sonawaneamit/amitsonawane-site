# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-BookingForm.tsx`: An AI-written component with typical issues.
- `example-scan-output.txt`: Real output of code_slop_scan.py on the file above.
- `example-findings.md`: The review written from the scan plus manual checks.
