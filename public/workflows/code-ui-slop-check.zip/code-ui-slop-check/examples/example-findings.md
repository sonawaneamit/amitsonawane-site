# Findings: BookingForm (EXAMPLE DATA)

| Severity | File:line | Issue | Fix |
|---|---|---|---|
| High | BookingForm.tsx:12 | Empty catch: booking failures are silent | Show an error and keep the selection |
| High | BookingForm.tsx:9,11 | `as any` and `!` on API data | Validate the response; type `Booking` |
| Med | BookingForm.tsx:3 | `slots: any` | `slots: Slot[]` |
| Med | BookingForm.tsx:18 | Buttons have no key, no selected state | Add `key`, `aria-pressed` |
| Low | BookingForm.tsx:10 | console.log | Remove |
| Low | BookingForm.tsx:5 | TODO without owner | Remove or link an issue |

## Copy
| Where | Before | After |
|---|---|---|
| h2 | Simply pick a time that works for you and we'll take care of the rest! | Pick a time |
| p | Please note that you can easily change your booking later. Don't worry! | You can change this later. |
| submit button | Click here to submit your booking request now | Book {{time}} |
| (new) error | none | Couldn't book this slot. Pick another time or try again. |
