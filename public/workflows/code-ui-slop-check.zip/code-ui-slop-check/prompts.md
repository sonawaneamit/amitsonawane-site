---
title: "Code and UI slop check: prompts"
slug: "code-ui-slop-check-prompts"
theme: "Make AI output sound human"
type: "prompts"
---

# Code and UI slop check: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Review a branch

In a coding agent, with the skill loaded.

```text
Use the code-ui-slop-check skill on {{branch or folder}}.
Design system: {{tokens file / component folder / "none"}}
Product voice: {{2-3 lines}}

Run the scan, review the code, run the copy ladder on every visible string and check design hygiene. Write findings.md first and wait for my OK. Then fix in small commits and run the tests after each.
```

## 2. Copy ladder only

Paste strings from a screen.

```text
Here are all visible strings on the {{screen}} screen: {{paste}}.
For each, apply the deletion ladder: delete, replace with UI, shorten, rewrite. Return a table: string, step used, result (or DELETE), reason. Keep legal and safety text.
```

## 3. Write my guard rules

After 2-3 reviews.

```text
Here are findings from the last {{n}} reviews: {{paste findings.md files}}.
Group repeat issues. For each group seen 3+ times, write (1) a lint rule config for {{eslint / biome / oxlint}} if one exists, and (2) a line for my agent instructions file with one bad and one good example. Do not invent rule names; if unsure a rule exists, say so.
```
