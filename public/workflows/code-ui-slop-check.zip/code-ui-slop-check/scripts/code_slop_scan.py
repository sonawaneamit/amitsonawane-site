#!/usr/bin/env python3
"""Find common low-evidence patterns in AI-written TypeScript/JavaScript and UI copy.
Standard library only. It reports; you or your agent decide what to fix.

Code checks: type escapes (as any, @ts-ignore, non-null !), disabled lint rules,
empty or swallow-all catch blocks, leftover console.log, TODO without owner,
large commented-out blocks, and very long functions.
UI copy checks: visible strings in JSX/TSX/HTML that are long, hedge, apologise,
or restate the obvious, so you can run them through the copy deletion ladder.

Usage:
  python3 code_slop_scan.py path/to/src [--ext .ts,.tsx,.js,.jsx] [--max-fn-lines 80]
"""
import os, re, sys

CODE = {
    "type escape: as any": r"\bas\s+any\b",
    "type escape: ts-ignore/expect-error": r"@ts-(?:ignore|expect-error|nocheck)",
    "lint disabled": r"eslint-disable|oxlint-disable|biome-ignore",
    "empty catch": r"catch\s*(?:\([^)]*\))?\s*\{\s*\}",
    "swallow error": r"catch\s*\([^)]*\)\s*\{\s*(?:return\s*(?:null|undefined|\[\]|\{\})?;?|console\.\w+\([^)]*\);?)\s*\}",
    "console.log": r"\bconsole\.log\(",
    "todo without owner": r"//\s*(?:TODO|FIXME)(?!\s*\()",
    "non-null assertion": r"\w[\])]?!\.(?!=)",
    "unknown cast chain": r"as\s+unknown\s+as\b",
}
COPY_FLAGS = [
    (r"\b(?:simply|just|easily|seamlessly|effortlessly)\b", "minimizer"),
    (r"\b(?:please note|note that|don'?t worry|rest assured|no need to)\b", "pre-empts a worry"),
    (r"\b(?:sorry|oops|whoops|uh oh)\b", "apology"),
    (r"\b(?:powerful|robust|amazing|beautiful|blazing|cutting-edge|next-gen)\b", "self-praise"),
    (r"\b(?:this (?:button|field|page|section) (?:will|lets|allows))\b", "describes the UI to itself"),
]

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    root = sys.argv[1]
    exts = tuple(sys.argv[sys.argv.index("--ext") + 1].split(",")) if "--ext" in sys.argv else (".ts", ".tsx", ".js", ".jsx", ".vue", ".svelte", ".html")
    max_fn = int(sys.argv[sys.argv.index("--max-fn-lines") + 1]) if "--max-fn-lines" in sys.argv else 80
    counts, findings = {}, []
    for dp, dirs, files in os.walk(root):
        dirs[:] = [d for d in dirs if d not in ("node_modules", ".git", "dist", "build", ".next", "coverage")]
        for name in files:
            if not name.endswith(exts):
                continue
            path = os.path.join(dp, name)
            lines = open(path, encoding="utf-8", errors="replace").read().splitlines()
            comment_run, fn_start, depth = 0, None, 0
            for i, line in enumerate(lines, 1):
                for label, pat in CODE.items():
                    if re.search(pat, line):
                        counts[label] = counts.get(label, 0) + 1
                        findings.append(f"{path}:{i}: {label}: {line.strip()[:100]}")
                if re.match(r"\s*//.*[;{}()=]\s*$", line):
                    comment_run += 1
                else:
                    if comment_run >= 5:
                        counts["commented-out code"] = counts.get("commented-out code", 0) + 1
                        findings.append(f"{path}:{i - comment_run}: commented-out code: {comment_run} lines")
                    comment_run = 0
                if re.search(r"\bfunction\b|=>\s*\{", line) and fn_start is None:
                    fn_start, depth = i, 0
                if fn_start is not None:
                    depth += line.count("{") - line.count("}")
                    if depth <= 0 and i > fn_start:
                        if i - fn_start > max_fn:
                            counts["long function"] = counts.get("long function", 0) + 1
                            findings.append(f"{path}:{fn_start}: long function: {i - fn_start} lines")
                        fn_start = None
                if name.endswith((".tsx", ".jsx", ".vue", ".svelte", ".html")):
                    for text in re.findall(r">\s*([A-Z][^<>{}]{25,})\s*<", line) + re.findall(r"(?:label|title|placeholder|description|aria-label)=\"([^\"]{25,})\"", line):
                        hits = [lab for pat, lab in COPY_FLAGS if re.search(pat, text, re.I)]
                        if len(text.split()) > 14 or hits:
                            counts["ui copy to review"] = counts.get("ui copy to review", 0) + 1
                            findings.append(f"{path}:{i}: ui copy ({', '.join(hits) or 'long'}): \"{text.strip()[:110]}\"")
    for f in findings:
        print(f)
    print("\nSummary:")
    for k, v in sorted(counts.items(), key=lambda kv: -kv[1]):
        print(f"- {k}: {v}")

if __name__ == "__main__":
    main()
