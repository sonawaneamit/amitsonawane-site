---
title: "Community and competitor-switcher outreach: prompts"
slug: "community-competitor-outreach-prompts"
theme: "Find and reach customers"
type: "prompts"
---

# Community and competitor-switcher outreach: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Set up my watch list

Run once.

```text
Use the community-competitor-outreach skill.
I offer: {{offer}}. For: {{who}}.
Competitors and known gaps: {{list}}.
Communities: {{list, or "suggest 5 and wait for OK"}}.
Write the request, comparison and complaint queries for each community and note each community's self-promotion rules (quote them with a link).
```

## 2. Daily queue

Every day.

```text
Use the community-competitor-outreach skill.
Run the saved queries for posts from the last {{7}} days. Build queue.csv with intent scores. Draft replies for every 4 and 5, following step 4, with disclosure. Show me the queue and drafts. Post nothing.
```

## 3. Reply to one thread

When you find a thread yourself.

```text
Thread: {{url or paste}}. Community rules: {{paste or "check them"}}.
Draft a reply that answers their question first, names honest options, mentions {{product}} once only if it fits their requirements, and says "I work on {{product}}". Under 120 words, no link unless needed.
```

## 4. Weekly review

Once a week.

```text
Read conversations.csv and queue.csv for this week. Report: replies posted, responses, private conversations, sign-ups if known, by community and query type. Which queries to drop, which to add. Any reply that got pushback, and why.
```
