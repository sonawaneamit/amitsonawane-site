---
title: "Community and competitor-switcher outreach"
slug: "community-competitor-outreach"
theme: "Find and reach customers"
theme_slug: "find-and-reach-customers"
theme_order: 4
order: 14
summary: "Find people who say in public that they need what you offer, or that a competing tool lets them down, and reach them honestly: helpful public replies first, disclosed affiliation, and one-to-one messages only where the platform and the person allow it."
---

# Community and competitor-switcher outreach

Find people who say in public that they need what you offer, or that a competing tool lets them down, and reach them honestly: helpful public replies first, disclosed affiliation, and one-to-one messages only where the platform and the person allow it.

| | |
|---|---|
| Theme | Find and reach customers |
| Time | 30 to 60 minutes a day |
| Works with | Any agent with web browsing. Works best paired with pain-point-mining, which finds the threads. |
| You get | A daily queue of high-intent posts, disclosed reply drafts for your approval, and a tracker of conversations |

## When to use it

- People ask for tools like yours in public, and nobody useful answers.
- A competitor has a known weak spot that users complain about.
- You need your first 10 to 50 customers and want real conversations.

## What you get

- `queue.csv`: today's high-intent posts with an intent score.
- Reply drafts with your affiliation stated, waiting for your OK.
- `conversations.csv`: who replied, what they need, next step.

## Inputs

| Input | Example | Needed |
|---|---|---|
| What you offer | One paragraph and who it is for | Yes |
| Competitors and their known gaps | From reviews or your own knowledge | Yes |
| Communities to watch | Forums, groups, Q&A sites, review pages | Yes |
| Your accounts | Real accounts you are allowed to post from | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Set queries.** Request, comparison and complaint phrases per community.
2. **Collect posts.** Search daily; keep recent, open, on-topic posts.
3. **Score intent.** Asking now > comparing > complaining > venting.
4. **Draft replies.** Answer the question first; disclose; mention yourself only if it fits.
5. **Approve and post.** You post from your own account, inside community rules.
6. **Follow up.** One-to-one only on invitation; track every thread.

## Copy-paste prompts

### 1. Set up my watch list

Run once.

```text
Use the community-competitor-outreach skill.
I offer: {{offer}}. For: {{who}}.
Competitors and known gaps: {{list}}.
Communities: {{list, or "suggest 5 and wait for OK"}}.
Write the request, comparison and complaint queries for each community and note each community's self-promotion rules (quote them with a link).
```

### 2. Daily queue

Every day.

```text
Use the community-competitor-outreach skill.
Run the saved queries for posts from the last {{7}} days. Build queue.csv with intent scores. Draft replies for every 4 and 5, following step 4, with disclosure. Show me the queue and drafts. Post nothing.
```

### 3. Reply to one thread

When you find a thread yourself.

```text
Thread: {{url or paste}}. Community rules: {{paste or "check them"}}.
Draft a reply that answers their question first, names honest options, mentions {{product}} once only if it fits their requirements, and says "I work on {{product}}". Under 120 words, no link unless needed.
```

### 4. Weekly review

Once a week.

```text
Read conversations.csv and queue.csv for this week. Report: replies posted, responses, private conversations, sign-ups if known, by community and query type. Which queries to drop, which to add. Any reply that got pushback, and why.
```

## Scoring rubric

**Before posting any reply**

- [ ] Answers the actual question in the first lines
- [ ] Useful even if they never use the product
- [ ] Affiliation stated if the product is mentioned
- [ ] Product mentioned at most once
- [ ] Allowed by this community's rules
- [ ] Posted from the person's own real account
- [ ] No link, or a link the person needs

**Weekly health**: 0 removed posts or moderator warnings; response rate on replies rising; private conversations only on invitation.

## Templates

**queue.csv**

`url,community,date,author_type,quote,need,intent,draft_status`

**Reply shape**

```text
{{direct answer to their question, 2-3 sentences}}
{{options: what usually works for their case, competitors included if they fit}}
I work on {{product}}, so I'm biased, but it {{one fact that matches their stated need}}. Happy to answer questions here.
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-queue.csv`: A day's queue. Posts and communities are made up.
- `examples/example-reply.md`: A disclosed reply to the intent-5 post.
- `examples/example-conversations.csv`: The tracker after a week.

## Troubleshooting and tips

- **Moderators removed a reply.** Read the rules again, apologise to the moderators if needed, and only mention the product where self-promotion is allowed.
- **Few intent-5 posts.** Add comparison queries and app or review pages for competitors; these usually have more buyers than general forums.
- **Replies get no response.** Lead with a better answer. If the reply would be useful with the product line deleted, it is a good reply.
- **A forum cannot be searched by the agent.** Use a signed-in browser session you control and are allowed to use, or paste threads in. Do not scrape members-only areas.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
