# Reply to forum.example.org/t/1201 (EXAMPLE DATA, waiting for approval)

Deposits are the fastest fix I've seen for no-shows. Two common setups: send a payment link when you confirm by text (works with any app), or use a booking tool that takes the deposit at booking and applies it to the bill. Set a clear cancellation window, 24 hours is common, and put it in the confirmation.

Groom Pro and Example Booking both take deposits at booking. I work on Example Booking, so I'm biased; it also lets you keep the deposit automatically on a late cancel. Happy to answer questions here.
