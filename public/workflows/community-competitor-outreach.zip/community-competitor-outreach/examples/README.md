# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-queue.csv`: A day's queue. Posts and communities are made up.
- `example-reply.md`: A disclosed reply to the intent-5 post.
- `example-conversations.csv`: The tracker after a week.
