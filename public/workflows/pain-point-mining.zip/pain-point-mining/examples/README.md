# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-raw.jsonl`: A few lines of collected raw items.
- `example-pain-points.md`: The ranked output table with commentary.
- `example-promises.md`: Promises written from the top 2 pains.
