# Pain points: solo mobile dog groomers (EXAMPLE DATA)
Read 412 items from 5 sources, Nov 2025 to Oct 2026.

| # | Pain point | F | I | W | G | Score | Quote 1 | Quote 2 | Sources |
|---|-----------|---|---|---|---|-------|---------|---------|---------|
| 1 | Clients cancel last minute and I eat the cost | 5 | 5 | 4 | 3 | 26 | "Third no-show this month and the app has no way to take a deposit." | "I drove 40 minutes for nothing." | app store, forum |
| 2 | Planning routes between appointments takes hours | 4 | 3 | 4 | 3 | 22 | "I spend an hour every Sunday doing it by hand" | "I'd pay for routing alone" | forum, video comments |
| 3 | App double-books me when I lose signal | 3 | 5 | 3 | 4 | 21 | "Then it double-booked me twice." | "offline mode is a joke" | review site, app store |
| 4 | Asking for deposits feels awkward | 3 | 3 | 4 | 2 | 19 | "I hate chasing people for money" | "clients get offended when I ask" | forum, video comments |
| 5 | Monthly fee too high for a solo groomer | 4 | 3 | 3 | 2 | 19 | "Too expensive for a one-person business." | "I use 2 features out of 30" | app store, review site |
| 6 | Pet notes are scattered across apps | 3 | 2 | 2 | 4 | 16 | "I have notes in 3 different apps" | "I forgot which dog bites" | video comments, forum |

## Top 2 and why
1. No-shows: most frequent and tied to lost money. Deposits exist in some tools but are buried or cost extra.
2. Route planning: people already do it by hand every week, and two said they would pay for it alone.

## 3 things that surprised you
- Nobody complained about price until they compared it with how few features they use.
- Offline problems come only from people who work in vans, never from salon owners.
- Several people keep pet temperament notes in their phone's notes app.

## Stress test
| Question | Answer from evidence | Strength |
|---|---|---|
| Will groomers pay for deposits when clients push back? | 9 items mention losing clients over deposits; 4 say they would still charge | weak |
| Why hasn't an existing tool fixed this? | Deposits exist but sit behind the top plan in 2 of 3 tools | strong |

## What to test next
Smoke-test promise 1 (deposits + reminders) against promise 2 (weekly route plan) with the same audience.
