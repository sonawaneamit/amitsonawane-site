# Promises (EXAMPLE DATA)

## Pain 1: last-minute cancellations
- For solo mobile groomers who lose money to no-shows, a booking link that takes a deposit up front, so you never drive 40 minutes for nothing again.  <- pick
- For groomers tired of last-minute cancellations, reminders and deposits that keep your day full.
- For one-person grooming vans, booking that charges a deposit before you leave the driveway.

## Pain 2: route planning
- For mobile groomers who plan routes by hand every Sunday, a weekly route built from your bookings in one click.  <- pick
- For groomers on the road, appointments ordered by drive time automatically.
- For mobile groomers, stop spending an hour every week in a map app.
