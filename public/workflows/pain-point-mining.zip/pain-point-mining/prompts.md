---
title: "Pain-point mining: prompts"
slug: "pain-point-mining-prompts"
theme: "Validate before you build"
type: "prompts"
---

# Pain-point mining: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the whole workflow

Paste with the skill file loaded. The agent does every step.

```text
Use the pain-point-mining skill.

Niche: {{niche}}
Competitors: {{competitors}}
Communities I already know: {{communities}}
Market: {{country}}, {{language}}
Window: last {{months}} months

Collect at least 300 items from at least 3 source types. Save raw.jsonl, then give me pain-points.md and promises.md. If a source blocks you, tell me which one and ask me to paste it instead of skipping it. Ask me only for things you cannot find yourself.
```

## 2. Find where they complain

Use before collecting if you do not know the communities yet.

```text
I want to find where {{niche}} complain about {{problem area}}.

List 10 public places where they describe problems in their own words: subreddits, forums, public groups, review pages of competing products, video channels whose comments are full of questions, Q&A sites.

For each give: link, type, rough activity (posts in the last 30 days if you can see it), and one example complaint you found there.

Rank them by how often people describe real problems, not by size. Leave out anything that needs a login to read.
```

## 3. Extract pains from a batch

Paste 30 to 80 raw reviews, posts or comments at the end.

```text
Below are {{n}} raw items from {{source}} written by {{niche}}.

For every item that contains a complaint, wish, workaround, price objection or switching story, return one row in a markdown table:

| pain (short, their words) | type | intensity cue | pay signal | quote (verbatim, max 30 words) | source |

type is one of: complaint, wish, workaround, price, switching.
intensity cue: the exact words that show how much it hurts.
pay signal: any mention of price, paying, budget, switching, or "I'd pay". Write "none" if there is none.

Copy quotes exactly. Skip praise, spam and one-off support requests. Do not summarise skipped items.

RAW ITEMS:
<<<
{{paste here}}
>>>
```

## 4. Cluster and score

After all batches are extracted. Paste every row from prompt 3.

```text
Here are all extracted rows from {{n}} items across {{k}} sources.

1. Merge them into 15 to 30 pain points. Name each in the customer's language, 4 to 10 words.
2. Frequency = number of distinct items that mention it. Convert to F (1-5): under 1% = 1, 1-2% = 2, 3-5% = 3, 6-10% = 4, over 10% = 5.
3. Score I (intensity), W (willingness to pay) and G (gap vs existing products) from 1 to 5 using the rubric in the skill.
4. Score = 2F + I + 2W + G. Sort high to low.
5. For each, keep the 2 strongest verbatim quotes from 2 different sources.

Output pain-points.md with the table, then "Top 2 and why", "3 things that surprised you", and "What to test next".

ROWS:
<<<
{{paste here}}
>>>
```

## 5. Find the unspoken insight

Optional depth pass. Paste competitor landing and pricing pages first.

```text
Use only the evidence in pain-points.md, raw.jsonl and the competitor pages I pasted.

1. What does every successful product in this market understand that its customers never say out loud?
2. List the 3 assumptions this market is built on. For each, say what would have to be true for it to be wrong, and quote any evidence that it already is.
3. Which pain point in my list do current products ignore on purpose, and why might that be?

Cite the quote or source behind every claim. Write "no evidence" where there is none.
```

## 6. Try to kill the idea

Run on your top pain point before you build anything.

```text
Pain point #{{n}} in pain-points.md is my best candidate.

Write the 5 questions a skeptical investor would ask to kill a product built on it. Answer each using only evidence in pain-points.md and raw.jsonl.

Rate each answer's evidence strong, weak or missing. For every weak or missing answer, tell me the one thing I could collect in under a day to fix it.

Then give me the strongest case for this idea, and where it still breaks.
```

## 7. Write the promises

Last step. Feeds the smoke-test workflow.

```text
For the top 2 pain points in pain-points.md, write 3 one-line promises each using this template:

For {{who}} who {{situation}}, {{product type}} that {{result}}, so you never {{pain in their words}} again.

Use words from the quotes, not marketing words. No numbers you cannot back up. Under 25 words each.

Pick the best promise per pain point and write a smoke-test page for it: headline, subheadline, 3 bullets taken from real quotes, one call to action.
```
