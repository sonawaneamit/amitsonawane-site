---
title: "Pain-point mining"
slug: "pain-point-mining"
theme: "Validate before you build"
theme_slug: "validate-before-you-build"
theme_order: 3
order: 9
summary: "Find and rank the problems your target customers already complain about in public, with real quotes, before you build anything."
---

# Pain-point mining

Find and rank the problems your target customers already complain about in public, with real quotes, before you build anything.

| | |
|---|---|
| Theme | Validate before you build |
| Time | 60 to 120 minutes, mostly agent time |
| Works with | Any agent. Best with web access or a browser; works with pasted text too. |
| You get | A ranked pain-point table with verbatim quotes, plus 2 promises ready to test |

## When to use it

- You have a niche in mind and want to know what to build first.
- You have 2 or 3 ideas and want evidence for which pain is biggest.
- You want to know why customers leave a competitor, in their words.
- You need real customer language for a landing page, ad or pitch.

## What you get

- `raw.jsonl`: every review, post and comment collected, one per line.
- `pain-points.md`: 15 to 30 pain points, scored and ranked, each with 2 verbatim quotes.
- `promises.md`: one-line promises for the top 2 pains, ready for the smoke-test workflow.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Niche | Solo mobile dog groomers, US | Yes |
| Competitors | 2 booking apps, a paper diary | Yes |
| Communities | A groomer forum, 2 subreddits | Optional |
| Market | US, English | Default |
| Window | Last 12 months | Default |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Pick sources.** 4 to 6 places where the niche vents: competitor low-star reviews, communities, comments under popular videos, Q&A sites.
2. **Collect.** 300 to 1,000 raw items into `raw.jsonl`, using open endpoints, a browser, or pasted text.
3. **Extract.** One row per complaint, wish, workaround, price objection or switching story, with a verbatim quote.
4. **Cluster.** Merge into 15 to 30 pain points named in the customer's words.
5. **Score.** Frequency, intensity, willingness to pay and gap. Sort high to low.
6. **Stress-test.** Find the unspoken insight and try to kill the top idea with the evidence.
7. **Write promises.** One-line promises for the top 2 pains.

## Copy-paste prompts

### 1. Run the whole workflow

Paste with the skill file loaded. The agent does every step.

```text
Use the pain-point-mining skill.

Niche: {{niche}}
Competitors: {{competitors}}
Communities I already know: {{communities}}
Market: {{country}}, {{language}}
Window: last {{months}} months

Collect at least 300 items from at least 3 source types. Save raw.jsonl, then give me pain-points.md and promises.md. If a source blocks you, tell me which one and ask me to paste it instead of skipping it. Ask me only for things you cannot find yourself.
```

### 2. Find where they complain

Use before collecting if you do not know the communities yet.

```text
I want to find where {{niche}} complain about {{problem area}}.

List 10 public places where they describe problems in their own words: subreddits, forums, public groups, review pages of competing products, video channels whose comments are full of questions, Q&A sites.

For each give: link, type, rough activity (posts in the last 30 days if you can see it), and one example complaint you found there.

Rank them by how often people describe real problems, not by size. Leave out anything that needs a login to read.
```

### 3. Extract pains from a batch

Paste 30 to 80 raw reviews, posts or comments at the end.

```text
Below are {{n}} raw items from {{source}} written by {{niche}}.

For every item that contains a complaint, wish, workaround, price objection or switching story, return one row in a markdown table:

| pain (short, their words) | type | intensity cue | pay signal | quote (verbatim, max 30 words) | source |

type is one of: complaint, wish, workaround, price, switching.
intensity cue: the exact words that show how much it hurts.
pay signal: any mention of price, paying, budget, switching, or "I'd pay". Write "none" if there is none.

Copy quotes exactly. Skip praise, spam and one-off support requests. Do not summarise skipped items.

RAW ITEMS:
<<<
{{paste here}}
>>>
```

### 4. Cluster and score

After all batches are extracted. Paste every row from prompt 3.

```text
Here are all extracted rows from {{n}} items across {{k}} sources.

1. Merge them into 15 to 30 pain points. Name each in the customer's language, 4 to 10 words.
2. Frequency = number of distinct items that mention it. Convert to F (1-5): under 1% = 1, 1-2% = 2, 3-5% = 3, 6-10% = 4, over 10% = 5.
3. Score I (intensity), W (willingness to pay) and G (gap vs existing products) from 1 to 5 using the rubric in the skill.
4. Score = 2F + I + 2W + G. Sort high to low.
5. For each, keep the 2 strongest verbatim quotes from 2 different sources.

Output pain-points.md with the table, then "Top 2 and why", "3 things that surprised you", and "What to test next".

ROWS:
<<<
{{paste here}}
>>>
```

### 5. Find the unspoken insight

Optional depth pass. Paste competitor landing and pricing pages first.

```text
Use only the evidence in pain-points.md, raw.jsonl and the competitor pages I pasted.

1. What does every successful product in this market understand that its customers never say out loud?
2. List the 3 assumptions this market is built on. For each, say what would have to be true for it to be wrong, and quote any evidence that it already is.
3. Which pain point in my list do current products ignore on purpose, and why might that be?

Cite the quote or source behind every claim. Write "no evidence" where there is none.
```

### 6. Try to kill the idea

Run on your top pain point before you build anything.

```text
Pain point #{{n}} in pain-points.md is my best candidate.

Write the 5 questions a skeptical investor would ask to kill a product built on it. Answer each using only evidence in pain-points.md and raw.jsonl.

Rate each answer's evidence strong, weak or missing. For every weak or missing answer, tell me the one thing I could collect in under a day to fix it.

Then give me the strongest case for this idea, and where it still breaks.
```

### 7. Write the promises

Last step. Feeds the smoke-test workflow.

```text
For the top 2 pain points in pain-points.md, write 3 one-line promises each using this template:

For {{who}} who {{situation}}, {{product type}} that {{result}}, so you never {{pain in their words}} again.

Use words from the quotes, not marketing words. No numbers you cannot back up. Under 25 words each.

Pick the best promise per pain point and write a smoke-test page for it: headline, subheadline, 3 bullets taken from real quotes, one call to action.
```

## Scoring rubric

Score = 2F + I + 2W + G (max 30)

| Factor | 1 | 3 | 5 |
|---|---|---|---|
| F, frequency | Under 1% of items | 3 to 5% | Over 10% |
| I, intensity | Mild annoyance | Repeated frustration, lost hours | Lost money or clients, "I'm switching" |
| W, willingness to pay | No money talk | Compares prices or tools | Says they would pay |
| G, gap | Solved well today | Partly solved | Nobody solves it; spreadsheets and hacks |

- 22 to 30: test now with a smoke test.
- 16 to 21: watch. Collect more evidence.
- Under 16: drop for now.

## Templates

**One-line promise**

`For {{who}} who {{situation}}, {{product type}} that {{result}}, so you never {{pain in their words}} again.`

**Smoke-test page**

```text
Headline: {{the promise, 10 words or fewer}}
Subheadline: {{who it is for}} + {{the result}} + {{how fast or how easy}}
Bullets (real quotes, trimmed for length only):
- "{{quote about the pain}}" -> {{what the product does about it}}
- "{{quote about the workaround}}" -> {{how this replaces it}}
- "{{quote about price or switching}}" -> {{price or plan answer}}
Call to action: {{Join the waitlist | Get early access | Reserve a spot for $X}}
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`collect.py` pulls 1 to 3 star App Store reviews and Hacker News comments into `raw.jsonl`. It retries failed pages and skips a page after 3 tries.

```bash
python3 scripts/collect.py appstore "Competitor App Name" us
python3 scripts/collect.py appstore "Competitor App Name" gb
python3 scripts/collect.py hn "invoicing software" 365
wc -l raw.jsonl
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-raw.jsonl`: A few lines of collected raw items.
- `examples/example-pain-points.md`: The ranked output table with commentary.
- `examples/example-promises.md`: Promises written from the top 2 pains.

## Troubleshooting and tips

- **Reddit returns 403, a login page, or an empty page.** Expected for scripts since 2026. Read threads in a browser you are signed in to, use the official API if you already have access, or paste threads in (method D).
- **Review sites block the agent.** Most software review sites block plain scripts. Use a browser filtered to 1 and 2 stars, or paste reviews in.
- **The App Store feed runs out.** It returns up to 10 pages of 50 reviews. Repeat with other country codes (gb, ca, au) for more English reviews.
- **Fewer than 150 items.** Widen the window to 24 months, add 2 more competitors, or add an adjacent audience.
- **Every pain is generic ("too expensive", "buggy").** Ask the agent for the moment it happens: who, when, what they did next. A pain with no moment is not ready to score.
- **You suspect invented quotes.** Ask: "Pick 10 random quotes and show the exact raw.jsonl line for each." Drop any that do not match.
- **The same 3 complaints keep coming up.** Good sign. Run a second pass that searches only those phrases to measure them better.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `collect.py`
