#!/usr/bin/env python3
"""Pain-point collector. Standard library only.
Pulls low-star App Store reviews and Hacker News comments into raw.jsonl.
Usage:
  python3 collect.py appstore "App Name" [country]
  python3 collect.py hn "search phrase" [days]
"""
import json, sys, time, urllib.parse, urllib.request

UA = {"User-Agent": "pain-point-research/1.0 (personal research)"}
OUT = "raw.jsonl"

def get(url, tries=3):
    for i in range(tries):
        try:
            req = urllib.request.Request(url, headers=UA)
            with urllib.request.urlopen(req, timeout=30) as r:
                return json.loads(r.read().decode("utf-8"))
        except Exception as e:
            if i == tries - 1:
                raise
            time.sleep(3 * (i + 1))

def save(rows):
    with open(OUT, "a", encoding="utf-8") as f:
        for r in rows:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    print(f"saved {len(rows)} rows to {OUT}")

def appstore(name, country="us"):
    q = urllib.parse.quote(name)
    hits = get(f"https://itunes.apple.com/search?term={q}&entity=software&limit=1&country={country}")["results"]
    if not hits:
        sys.exit(f"no app found for {name}")
    app_id, title = hits[0]["trackId"], hits[0]["trackName"]
    print(f"app: {title} ({app_id})")
    rows = []
    for page in range(1, 11):  # the feed stops at page 10 (50 reviews a page)
        url = (f"https://itunes.apple.com/{country}/rss/customerreviews/"
               f"page={page}/id={app_id}/sortby=mostrecent/json")
        try:
            entries = get(url).get("feed", {}).get("entry", [])
        except Exception as e:
            print(f"page {page}: {e}"); continue
        if isinstance(entries, dict):
            entries = [entries]
        if not entries:
            break
        for e in entries:
            if "im:rating" not in e:
                continue
            stars = int(e["im:rating"]["label"])
            if stars <= 3:
                rows.append({"source": "app_store", "app": title, "stars": stars,
                             "date": e["updated"]["label"][:10],
                             "title": e["title"]["label"],
                             "text": e["content"]["label"]})
        time.sleep(1)
    save(rows)

def hn(phrase, days=365):
    since = int(time.time()) - int(days) * 86400
    q = urllib.parse.quote(phrase)
    rows = []
    for page in range(0, 5):
        url = (f"https://hn.algolia.com/api/v1/search?query={q}&tags=comment"
               f"&numericFilters=created_at_i%3E{since}&hitsPerPage=100&page={page}")
        hits = get(url)["hits"]
        if not hits:
            break
        for h in hits:
            rows.append({"source": "hacker_news", "date": h["created_at"][:10],
                         "thread": h.get("story_title"),
                         "url": f"https://news.ycombinator.com/item?id={h['objectID']}",
                         "text": h.get("comment_text", "")})
        time.sleep(1)
    save(rows)

if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    kind, arg = sys.argv[1], sys.argv[2]
    extra = sys.argv[3:]
    {"appstore": appstore, "hn": hn}[kind](arg, *extra)
