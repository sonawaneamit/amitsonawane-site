# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-serp-map.csv`: Mapped searches and what ranks.
- `example-reply.md`: A disclosed thread reply.
- `example-video-plan.md`: One review video outline.
