# Video plan: Rival Scheduler honest review (EXAMPLE DATA)
Search: "rival scheduler honest review" (top video is from 2023, 4 minutes long).
Title: Rival Scheduler honest review (2026): who it's for

| Time | Section | On screen |
|---|---|---|
| 0:00 | Who I am, disclosure, what I tested for 2 weeks | Face + text: "I make a competing app" |
| 0:40 | Setup and first booking | Screen recording |
| 3:00 | What it does well: reminders, calendar sync, support reply time | Recordings, timestamps |
| 6:30 | Limit 1: deposits only on the top plan | Pricing page, dated |
| 8:00 | Limit 2: no offline mode | Phone in airplane mode |
| 9:30 | Who should pick it, who should not | Summary card |
| 10:30 | What we do differently (20 seconds) | Short demo |
