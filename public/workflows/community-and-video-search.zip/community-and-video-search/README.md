---
title: "Ranking on community platforms and video review searches"
slug: "community-and-video-search"
theme: "Get found in search and AI answers"
theme_slug: "search-and-ai-answers"
theme_order: 1
order: 4
summary: "Show up where buyers research before they buy: community threads that already rank for 'best X', and video searches like 'X honest review' and 'X vs Y'. Done in the open, with real help and disclosed affiliation."
---

# Ranking on community platforms and video review searches

Show up where buyers research before they buy: community threads that already rank for 'best X', and video searches like 'X honest review' and 'X vs Y'. Done in the open, with real help and disclosed affiliation.

| | |
|---|---|
| Theme | Get found in search and AI answers |
| Time | 2 hours to map, then 2 to 4 hours a week |
| Works with | Any agent with web access for research and drafting. You post from your own real accounts. |
| You get | A map of ranking threads and video searches, disclosed reply drafts, video outlines and a tracker |

## When to use it

- Searches for "best {{category}}" show forum or community threads near the top.
- Competitors spend heavily on ads, so their buyers look up reviews before paying.
- You can write useful answers or record fair review videos every week.

## What you get

- `serp-map.csv`: buyer searches, the threads and videos that rank for them, and whether you appear.
- `replies/`: drafts of helpful, disclosed answers for the best threads.
- `video-plan.md`: review and comparison video outlines for the most searched competitors.
- `tracker.csv`: weekly positions, clicks and signups from each thread and video.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Category and product | Booking app for mobile groomers | Yes |
| Competitors | 3 to 10, especially ones running ads | Yes |
| Your accounts | Real accounts on the communities and the video platform | Yes |
| Affiliation line | "I make a booking app for groomers" | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Map buyer searches.** "best", "vs", "alternative", "honest review" and "worth it" searches for your category and competitors.
2. **Find what ranks.** Community threads, group posts and videos already in the top results.
3. **Pick targets.** Threads still open and active; video searches nobody covers well.
4. **Contribute.** Answer the question fully, disclose who you are, mention the product only where it fits.
5. **Make review videos.** Fair reviews and comparisons of competitors that advertise, with a disclosed note on your product.
6. **Track.** Weekly positions, clicks and signups.

## Copy-paste prompts

### 1. Run the mapping

Paste with the skill loaded and web access on.

```text
Use the community-and-video-search skill.

Category: {{category}}
Product: {{product}}
Competitors (mark ones running ads): {{competitors}}
Communities where I have real accounts: {{communities}}
Video platform: {{platform}}
Affiliation line: {{line}}

Build serp-map.csv for the buyer searches, then pick the 10 best thread targets and 3 best video targets and tell me why.
```

### 2. Draft a thread reply

Paste the thread text and the community rules.

```text
This thread ranks for "{{search}}": {{paste thread}}.
Community rules on self-promotion: {{paste rules}}.

Draft a reply that first answers the question fully: criteria, 3-5 options including competitors with honest pros and cons, and which to pick for which situation. Then disclose "{{affiliation line}}" and mention {{product}} once, only if it fits a need someone stated. Plain and friendly, no marketing words, under 250 words. No link unless the rules allow it.
```

### 3. Plan a fair review video

One per competitor.

```text
Plan a fair review video of {{competitor}} for people searching "{{competitor}} honest review".
I will use a real account. Tasks I will try: {{tasks}}.

Give me: title options (search words first), a timestamped outline for 8-12 minutes, what to show on screen for each claim, at least 3 things they do well, their 2 biggest limits and the evidence I must capture, who should pick it, and a 20-second disclosed close about {{product}}.
```

### 4. Thread for my own community

For a group or forum you run.

```text
Write a thread for my community about {{topic}}, titled the way people search ("{{search}}").
Structure: short answer, criteria, member-recommended options (placeholders for member quotes; do not invent them), and a question that invites members to share their experience. Under 300 words. Add a "last updated" line.
```

## Scoring rubric

**Target score** (thread or video search), 0 to 10:

| Factor | Points |
|---|---|
| Ranks top 3 for a buyer search (top 4-10: 1) | 3 |
| Open for replies and active in the last 30 days | 2 |
| Rules allow disclosed self-mention (unclear: 1; banned: skip) | 2 |
| Your product fits the stated need | 2 |
| Video slot: top results are old, short or one-sided | 1 |

Work targets scoring 6+ first.

## Templates

**Disclosed reply skeleton**

```text
{{Direct answer in 1-2 sentences.}}

What I'd look at: {{criterion 1}}, {{criterion 2}}, {{criterion 3}}.

- {{Option A}}: good for {{who}}, weak at {{what}}.
- {{Option B}}: good for {{who}}, weak at {{what}}.
- {{Option C}}: good for {{who}}, weak at {{what}}.

Disclosure: {{affiliation line}}. {{One sentence on where it fits, only if it does.}}
```

**Video title patterns**

- `{{Competitor}} honest review ({{year}}): who it's for`
- `{{A}} vs {{B}} for {{use case}}: I used both for {{time}}`
- `Is {{Competitor}} worth it in {{year}}? {{n}} things to know before you pay`

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`keyword_suggest.py` finds the review and comparison searches people type for each competitor.

```bash
python3 scripts/keyword_suggest.py "Rival Scheduler" "Groom Pro" --mode reviews
python3 scripts/keyword_suggest.py "Rival Scheduler" --mode compare
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-serp-map.csv`: Mapped searches and what ranks.
- `examples/example-reply.md`: A disclosed thread reply.
- `examples/example-video-plan.md`: One review video outline.

## Troubleshooting and tips

- **The thread is archived.** Many platforms lock old threads. Look for newer threads on the same search, or start a useful one where the rules allow.
- **Moderators removed the post.** Read the rules again and ask what is allowed. Never repost from another account.
- **Nobody clicks.** Help that works without the product earns trust; clicks come from people whose need matches. Track signups, not clicks alone.
- **A competitor disputes a review.** Keep your recordings and dates. Fix factual errors fast and note the update in the description.
- **Ranking tricks.** Some guides suggest editing group posts and pushing them to indexing services, or stacking comments from extra accounts. Skip all of it: it breaks platform rules and burns trust.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `keyword_suggest.py`
