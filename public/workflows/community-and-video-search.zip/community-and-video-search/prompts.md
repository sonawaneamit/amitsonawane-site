---
title: "Ranking on community platforms and video review searches: prompts"
slug: "community-and-video-search-prompts"
theme: "Get found in search and AI answers"
type: "prompts"
---

# Ranking on community platforms and video review searches: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the mapping

Paste with the skill loaded and web access on.

```text
Use the community-and-video-search skill.

Category: {{category}}
Product: {{product}}
Competitors (mark ones running ads): {{competitors}}
Communities where I have real accounts: {{communities}}
Video platform: {{platform}}
Affiliation line: {{line}}

Build serp-map.csv for the buyer searches, then pick the 10 best thread targets and 3 best video targets and tell me why.
```

## 2. Draft a thread reply

Paste the thread text and the community rules.

```text
This thread ranks for "{{search}}": {{paste thread}}.
Community rules on self-promotion: {{paste rules}}.

Draft a reply that first answers the question fully: criteria, 3-5 options including competitors with honest pros and cons, and which to pick for which situation. Then disclose "{{affiliation line}}" and mention {{product}} once, only if it fits a need someone stated. Plain and friendly, no marketing words, under 250 words. No link unless the rules allow it.
```

## 3. Plan a fair review video

One per competitor.

```text
Plan a fair review video of {{competitor}} for people searching "{{competitor}} honest review".
I will use a real account. Tasks I will try: {{tasks}}.

Give me: title options (search words first), a timestamped outline for 8-12 minutes, what to show on screen for each claim, at least 3 things they do well, their 2 biggest limits and the evidence I must capture, who should pick it, and a 20-second disclosed close about {{product}}.
```

## 4. Thread for my own community

For a group or forum you run.

```text
Write a thread for my community about {{topic}}, titled the way people search ("{{search}}").
Structure: short answer, criteria, member-recommended options (placeholders for member quotes; do not invent them), and a question that invites members to share their experience. Under 300 words. Add a "last updated" line.
```
