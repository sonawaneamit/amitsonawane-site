#!/usr/bin/env python3
"""Expand seed phrases into long-tail search queries using search autocomplete.
Standard library only. Writes suggestions.csv (seed, modifier, suggestion).

The autocomplete endpoint is unofficial and can change or rate-limit you.
Keep runs small (a few hundred requests) and pause between calls.

Usage:
  python3 keyword_suggest.py "invoice app" [--country us] [--lang en] [--mode alphabet|questions|compare|reviews]
"""
import csv, json, string, sys, time, urllib.parse, urllib.request

MODES = {
    "alphabet": [""] + [f" {c}" for c in string.ascii_lowercase],
    "questions": [" how", " what", " why", " can", " is", " best", " for", " without", " near me"],
    "compare": [" vs", " versus", " alternative", " alternatives", " or", " compared to", " like"],
    "reviews": [" review", " honest review", " worth it", " reddit", " problems", " complaints",
                 " pricing", " scam", " cancel", " not working"],
}

def suggest(q, country, lang):
    url = ("https://suggestqueries.google.com/complete/search?client=firefox"
           f"&hl={lang}&gl={country}&q={urllib.parse.quote(q)}")
    req = urllib.request.Request(url, headers={"User-Agent": "keyword-research/1.0"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return json.loads(r.read().decode("utf-8", "replace"))[1]

def main():
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    opts = {"--country": "us", "--lang": "en", "--mode": "alphabet"}
    seeds = []
    i = 0
    while i < len(args):
        if args[i] in opts:
            opts[args[i]] = args[i + 1]; i += 2
        else:
            seeds.append(args[i]); i += 1
    seen, rows = set(), []
    for seed in seeds:
        for mod in MODES[opts["--mode"]]:
            q = seed + mod
            try:
                for s in suggest(q, opts["--country"], opts["--lang"]):
                    if s not in seen:
                        seen.add(s); rows.append([seed, mod.strip(), s])
            except Exception as e:
                print(f"skip '{q}': {e}")
            time.sleep(0.5)
    with open("suggestions.csv", "w", newline="", encoding="utf-8") as f:
        w = csv.writer(f); w.writerow(["seed", "modifier", "suggestion"]); w.writerows(rows)
    print(f"saved {len(rows)} unique suggestions to suggestions.csv")

if __name__ == "__main__":
    main()
