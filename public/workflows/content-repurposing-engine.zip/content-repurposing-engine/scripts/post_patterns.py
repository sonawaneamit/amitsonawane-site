#!/usr/bin/env python3
"""Find what top-performing posts have in common. Standard library only.

Input: posts.csv with a text column and at least one engagement column
(likes, reposts, comments, replies, saves, impressions). Optional: author, format.
Score = likes + 2*comments/replies + 3*reposts/shares + 3*saves, divided by
impressions when present (engagement rate), otherwise raw. Ranks are computed
within each author when an author column exists, so big accounts do not
drown out small ones.

Compares the top 10% with the bottom 50% on: length, line breaks, hook length,
first-line question, numbers in hook, lists/arrows, links, CTA at the end,
emoji, and format. Writes top_posts.md for the agent to turn into templates.

Usage:
  python3 post_patterns.py posts.csv
"""
import csv, re, statistics, sys
from collections import defaultdict

CTA = r"(comment|reply|repost|share|follow|save this|bookmark|dm me|link in|sign up|grab|download|join|what do you think|agree\?|\?\s*$)"

def n(v):
    try:
        return float(str(v).replace(",", "") or 0)
    except ValueError:
        return 0.0

def g(row, *names):
    for k in row:
        if k.strip().lower() in names:
            return row[k]
    return ""

def features(t):
    lines = [l for l in t.splitlines() if l.strip()]
    hook = lines[0] if lines else ""
    last = lines[-1].lower() if lines else ""
    return {
        "chars": len(t),
        "lines": len(lines),
        "hook_words": len(hook.split()),
        "hook_question": int(hook.strip().endswith("?")),
        "hook_number": int(bool(re.search(r"\d", hook))),
        "list_or_arrows": int(bool(re.search(r"(?m)^\s*(?:->|=>|[-*\u2022\u2192\u21b3>]|\d+[.)/])\s", t))),
        "has_link": int("http" in t),
        "cta_end": int(bool(re.search(CTA, last))),
        "emoji": int(bool(re.search(r"[\U0001F300-\U0001FAFF\u2600-\u27BF]", t))),
    }

def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    rows = list(csv.DictReader(open(sys.argv[1], newline="", encoding="utf-8-sig")))
    for r in rows:
        eng = (n(g(r, "likes", "reactions")) + 2 * n(g(r, "comments", "replies")) +
               3 * n(g(r, "reposts", "shares", "retweets")) + 3 * n(g(r, "saves", "bookmarks")))
        imp = n(g(r, "impressions", "views"))
        r["_score"] = eng / imp if imp else eng
        r["_text"] = g(r, "text", "content", "post")
        r["_author"] = g(r, "author", "account", "handle") or "all"
        r["_format"] = g(r, "format", "type") or "text"
    by_author = defaultdict(list)
    for r in rows:
        by_author[r["_author"]].append(r)
    top, bottom = [], []
    for posts in by_author.values():
        posts.sort(key=lambda r: r["_score"], reverse=True)
        k = max(1, len(posts) // 10)
        top += posts[:k]
        bottom += posts[len(posts) // 2:]
    print(f"posts: {len(rows)}, top 10%: {len(top)}, bottom 50%: {len(bottom)}\n")
    print(f"{'feature':<16}{'top':>8}{'bottom':>9}")
    keys = features("").keys()
    for key in keys:
        t = statistics.mean(features(r["_text"])[key] for r in top) if top else 0
        b = statistics.mean(features(r["_text"])[key] for r in bottom) if bottom else 0
        print(f"{key:<16}{t:>8.2f}{b:>9.2f}")
    fmt_top = defaultdict(int)
    for r in top:
        fmt_top[r["_format"]] += 1
    print("\nformats in top 10%:", dict(fmt_top))
    with open("top_posts.md", "w", encoding="utf-8") as f:
        f.write("# Top posts (top 10% per account)\n\n")
        for r in sorted(top, key=lambda r: r["_score"], reverse=True):
            f.write(f"## score {r['_score']:.4g} | {r['_format']}\n\n{r['_text'].strip()}\n\n")
    print("wrote top_posts.md")

if __name__ == "__main__":
    main()
