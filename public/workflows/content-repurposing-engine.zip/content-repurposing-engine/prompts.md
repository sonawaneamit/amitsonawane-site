---
title: "Content repurposing engine: prompts"
slug: "content-repurposing-engine-prompts"
theme: "AI-run content and ads"
type: "prompts"
---

# Content repurposing engine: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Mine my patterns

Run once a month with an export.

```text
Use the content-repurposing-engine skill.
Here is my post export: {{attached}}. Main channel: {{channel}}.
Run post_patterns.py, read top_posts.md, and write patterns.md with 5-8 patterns, each with 2 of my real examples. Mark patterns based on fewer than 3 posts as "test".
```

## 2. Voice note to posts

After each voice note.

```text
Here is a voice note transcript: {{paste}}.
Pull out every postable idea (a claim, story, number, mistake, tip). For each, give the pillar, 2 angles and the best format. Then draft the strongest one as a {{format}} for {{channel}} using patterns.md and my voice profile. Use only what I said; mark gaps [NEED: ...].
```

## 3. Snowball a month

Monthly.

```text
Use the content-repurposing-engine skill.
Pillars: {{3-4 pillars}}. Ideas folder: {{attached}}. Channels: {{main}} + {{others}}.
Build calendar.csv for {{month}} following step 4. Show it before drafting anything.
```

## 4. Carousel script

For one calendar slot.

```text
Turn this idea into a {{8}}-slide carousel: {{idea}}.
Slide 1: hook (under 10 words). Slides 2-7: one point each, under 25 words, concrete. Last slide: takeaway or question. Add a one-line visual note per slide. Only facts from the idea.
```
