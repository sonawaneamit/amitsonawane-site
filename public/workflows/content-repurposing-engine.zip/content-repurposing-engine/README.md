---
title: "Content repurposing engine"
slug: "content-repurposing-engine"
theme: "AI-run content and ads"
theme_slug: "ai-run-content-and-ads"
theme_order: 5
order: 15
summary: "Turn one strong idea or a few voice notes into a month of posts across formats, using patterns from your own best posts, with you approving everything before it goes out."
---

# Content repurposing engine

Turn one strong idea or a few voice notes into a month of posts across formats, using patterns from your own best posts, with you approving everything before it goes out.

| | |
|---|---|
| Theme | AI-run content and ads |
| Time | 2 hours a month plus 10 minutes a day |
| Works with | Any agent. Optional: a scheduling tool or social connector for drafts, and an image tool for carousels. |
| You get | A 30-day calendar, drafts in your voice for each channel, carousel scripts, and a monthly read of what worked |

## When to use it

- You know your topic but posting every day eats your week.
- Some posts do well and you cannot say why.
- You have talks, calls or voice notes that never become posts.

## What you get

- `patterns.md`: what your best posts share, from your own data.
- `calendar.csv`: 30 days, each with pillar, angle, format and channel.
- Drafts per day, carousel slide scripts and short video scripts.
- A monthly review with what to keep and drop.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Past posts with numbers | Export: text + likes, comments, reposts, impressions | Yes, 30+ posts |
| Raw ideas | Voice notes, call transcripts, notes | Yes |
| Channels | One main channel plus up to 2 others | Yes |
| Voice profile | From voice-matched-drafting | Recommended |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Mine your patterns.** Script on your own posts: what the top 10% share.
2. **Capture ideas.** Voice notes in, transcripts out, tagged by pillar.
3. **Snowball.** One pillar into 10+ angles, each into formats.
4. **Calendar.** 30 days, one main channel, a mix of formats.
5. **Draft and approve.** Weekly batch, cleanup pass, your OK.
6. **Review.** Monthly: keep, change or drop each pattern.

## Copy-paste prompts

### 1. Mine my patterns

Run once a month with an export.

```text
Use the content-repurposing-engine skill.
Here is my post export: {{attached}}. Main channel: {{channel}}.
Run post_patterns.py, read top_posts.md, and write patterns.md with 5-8 patterns, each with 2 of my real examples. Mark patterns based on fewer than 3 posts as "test".
```

### 2. Voice note to posts

After each voice note.

```text
Here is a voice note transcript: {{paste}}.
Pull out every postable idea (a claim, story, number, mistake, tip). For each, give the pillar, 2 angles and the best format. Then draft the strongest one as a {{format}} for {{channel}} using patterns.md and my voice profile. Use only what I said; mark gaps [NEED: ...].
```

### 3. Snowball a month

Monthly.

```text
Use the content-repurposing-engine skill.
Pillars: {{3-4 pillars}}. Ideas folder: {{attached}}. Channels: {{main}} + {{others}}.
Build calendar.csv for {{month}} following step 4. Show it before drafting anything.
```

### 4. Carousel script

For one calendar slot.

```text
Turn this idea into a {{8}}-slide carousel: {{idea}}.
Slide 1: hook (under 10 words). Slides 2-7: one point each, under 25 words, concrete. Last slide: takeaway or question. Add a one-line visual note per slide. Only facts from the idea.
```

## Scoring rubric

**Before approving a week**

- [ ] Each post uses a pattern from patterns.md (or is marked as a test)
- [ ] Hook in the first line, under about 12 words
- [ ] One idea per post
- [ ] Every fact traces to the ideas folder
- [ ] Cleanup pass done; 0 strong AI-writing tells
- [ ] Other channels get adapted versions, not copies
- [ ] 2-3 open slots kept for timely posts

**Monthly**: patterns.md updated from data; top 5 posts explained; next month's pillar mix set.

## Templates

**calendar.csv**

`date,channel,pillar,angle,format,hook,source_idea,status`

**Angle bank**: how-to, mistake, story, contrarian, numbers, checklist, tools, before/after, customer question, myth vs fact, behind the scenes, prediction.

**Short video script**

```text
0-3s  hook line + on-screen text
3-15s  problem, with one concrete detail
15-45s  2-3 steps or the turn in the story
45-60s  takeaway; one question for comments
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`post_patterns.py` reads a CSV with a `text` column and any engagement columns (likes, comments, replies, reposts, shares, saves, impressions; optional author and format). It prints a top-vs-bottom comparison and writes `top_posts.md`.

```bash
python3 scripts/post_patterns.py posts.csv
```

With an `impressions` column it ranks by engagement rate; with an `author` column it ranks within each author.

## Example files

Invented data that shows the format of each input and output.

- `examples/example-posts.csv`: 40 made-up posts by a fictional mobile groomer.
- `examples/example-post_patterns-output.txt`: Real script output for the posts above.
- `examples/example-top_posts.md`: The top_posts.md the script wrote.
- `examples/example-patterns.md`: Patterns written from the output.
- `examples/example-calendar.csv`: The first week of a calendar.

## Troubleshooting and tips

- **Fewer than 30 posts.** Use the ideas and angle bank for a month, then run the script. Patterns from 10 posts are noise.
- **Drafts sound generic.** Feed more voice notes. Specific stories in, specific posts out. Pair with voice-matched-drafting.
- **Script says top and bottom look the same.** Your topics may matter more than form. Add a `pillar` column and compare by pillar by hand.
- **The export has odd column names.** Rename to text, likes, comments, reposts, impressions; the script also accepts replies, shares and saves.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `post_patterns.py`
