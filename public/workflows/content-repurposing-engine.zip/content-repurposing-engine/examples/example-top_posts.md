# Top posts (top 10% per account)

## score 0.1266 | text

5 tools in my van that pay for themselves:

-> short coat in winter
-> deposit at booking
-> dry paws

## score 0.1189 | text

3 things I check before every matted coat:

-> check ears
-> dry paws
-> short coat in winter
Which one do you skip?

## score 0.1066 | text

3 things I check before every matted coat:

-> brush first
-> short coat in winter
-> dry paws

## score 0.1036 | image

Two hours. That's what one matted doodle cost me today.

-> deposit at booking
-> short coat in winter
-> brush first
