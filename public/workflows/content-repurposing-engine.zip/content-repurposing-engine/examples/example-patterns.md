# Patterns (EXAMPLE DATA)

1. Number in the hook. 3 of the top 4 posts start with a number ("3 things", "5 tools", "Two hours"). None of the bottom half do.
2. Arrow lists. All top posts use a 3-item arrow list; the bottom half are one paragraph.
3. More lines, same length. Top posts use about twice as many lines at about the same character count. White space helps.
4. TEST: a question at the end. Only 1 top post ends with one; not enough data.
5. Avoid: greeting or mood hooks ("Happy Friday", "Busy week"). All in the bottom half.
