# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-posts.csv`: 40 made-up posts by a fictional mobile groomer.
- `example-post_patterns-output.txt`: Real script output for the posts above.
- `example-top_posts.md`: The top_posts.md the script wrote.
- `example-patterns.md`: Patterns written from the output.
- `example-calendar.csv`: The first week of a calendar.
