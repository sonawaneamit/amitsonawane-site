---
title: "Channel test cadence: prompts"
slug: "channel-test-cadence-prompts"
theme: "Growth experiments"
type: "prompts"
---

# Channel test cadence: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Pick my first tests

Start here.

```text
Use the channel-test-cadence skill.
Product: {{product}}. Buyer: {{buyer}}. Price: {{price}}. Target cost per paying user: {{target}}. My hourly value: {{value}}.
Score these channels {{list or "suggest 8"}} and write test rows for the top 2: hypothesis, budget, hours, time box, kill line, tracking.
```

## 2. Weekly review

Every week.

```text
Here is test_log.csv: {{attached}}. Run test_log.py with target {{target}} and hourly {{value}}.
For each running test: on track or not, against its kill line. Give the call and the single change for any ITERATE. Update the decision and learning columns.
```

## 3. Creator brief

Before contacting creators.

```text
Use the channel-test-cadence skill, creator test design.
Product: {{product}}. Buyer: {{buyer}}. Budget: {{total}}.
Write: the creator profile to look for; a short outreach message (I will send it myself); a brief (problem, product, must-say, must-not-say, disclosure); and a pay structure with base plus bonus that fits the budget across 5-10 creators.
```

## 4. Review prompt plan

For apps.

```text
My app: {{what it does}}. Main value moments: {{list}}.
Pick the best moment for the native review prompt and say why. Write the trigger conditions (for example: 3rd completed booking, no error in the session). Confirm the plan has no gating and uses the platform's native API.
```
