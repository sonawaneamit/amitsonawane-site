---
title: "Channel test cadence"
slug: "channel-test-cadence"
theme: "Growth experiments"
theme_slug: "growth-experiments"
theme_order: 6
order: 18
summary: "Test growth channels one at a time on a fixed cadence with a written hypothesis, a budget and a kill line, count your own hours as cost, and go deep on the one that pays. Includes creator tests and an honest review prompt for apps."
---

# Channel test cadence

Test growth channels one at a time on a fixed cadence with a written hypothesis, a budget and a kill line, count your own hours as cost, and go deep on the one that pays. Includes creator tests and an honest review prompt for apps.

| | |
|---|---|
| Theme | Growth experiments |
| Time | 30 minutes a week to run the log, plus the tests |
| Works with | Any agent. A spreadsheet or CSV for the log. |
| You get | A test log with a call per test, a per-channel cost per paying user, and a creator test and review-prompt plan |

## When to use it

- You have a product people pay for, and no reliable channel yet.
- You try many channels at once and cannot say which works.
- You want to test creators or app store reviews without wasting money.

## What you get

- `test_log.csv` with a hypothesis, budget, kill line and outcome per test.
- A weekly summary: cost per paying user by test and channel, with a call.
- A creator test brief and an in-app review prompt plan.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Target cost per paying user | What you can afford to pay for one customer | Yes |
| Your hourly value | To cost your own time | Yes |
| Candidate channels | 5-10 ideas | Yes |
| Tracking | Sign-up source, promo codes, or UTM links | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **List channels.** Score each on reach, fit, cost and speed.
2. **Write the test.** Hypothesis, budget, time box, kill line, metric.
3. **Run one channel deep.** One or two tests at a time, 2-4 weeks each.
4. **Log weekly.** Cost, hours, sign-ups, paid users.
5. **Call it.** Double down, iterate, or stop.
6. **Go deep.** Put most effort into the winner before adding more.

## Copy-paste prompts

### 1. Pick my first tests

Start here.

```text
Use the channel-test-cadence skill.
Product: {{product}}. Buyer: {{buyer}}. Price: {{price}}. Target cost per paying user: {{target}}. My hourly value: {{value}}.
Score these channels {{list or "suggest 8"}} and write test rows for the top 2: hypothesis, budget, hours, time box, kill line, tracking.
```

### 2. Weekly review

Every week.

```text
Here is test_log.csv: {{attached}}. Run test_log.py with target {{target}} and hourly {{value}}.
For each running test: on track or not, against its kill line. Give the call and the single change for any ITERATE. Update the decision and learning columns.
```

### 3. Creator brief

Before contacting creators.

```text
Use the channel-test-cadence skill, creator test design.
Product: {{product}}. Buyer: {{buyer}}. Budget: {{total}}.
Write: the creator profile to look for; a short outreach message (I will send it myself); a brief (problem, product, must-say, must-not-say, disclosure); and a pay structure with base plus bonus that fits the budget across 5-10 creators.
```

### 4. Review prompt plan

For apps.

```text
My app: {{what it does}}. Main value moments: {{list}}.
Pick the best moment for the native review prompt and say why. Write the trigger conditions (for example: 3rd completed booking, no error in the session). Confirm the plan has no gating and uses the platform's native API.
```

## Scoring rubric

**Before a test starts**

- [ ] Hypothesis with a number and a deadline
- [ ] Budget and hours set
- [ ] Kill line written
- [ ] Tracking in place (link, code or survey option)
- [ ] Only 1-2 tests running

**After a test**: call made, learning written, next step chosen. Stopped tests stay in the log.

## Templates

**test_log.csv**

`test_id,channel,hypothesis,start,end,cost,hours,reach,clicks,signups,paid,revenue,decision,learning`

**Creator pay**: base fee per post + bonus per paying user through their code, capped per month. Paid in full for the base even if results are poor.

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`test_log.py` adds hours times your hourly value to cost, then prints cost per paying user and a call per test, and a per-channel summary.

```bash
python3 scripts/test_log.py test_log.csv --target-cpa 150 --hourly 40
```

`--target-cpa` here means your target cost per paying user.

## Example files

Invented data that shows the format of each input and output.

- `examples/example-test_log.csv`: Four made-up tests.
- `examples/example-test_log-output.txt`: Real script output with target 150 and hourly 40.
- `examples/example-decision.md`: What to do with the output.

## Troubleshooting and tips

- **Cannot tell which channel a user came from.** Add a required "how did you hear about us" field at sign-up, plus unique codes per test.
- **Every test looks like ITERATE.** Time boxes too short or volume too low. Run fewer tests, longer.
- **A creator brought nothing.** Pay the base anyway, log it, and look at audience fit before the next pick.
- **Review prompt never shows.** The stores rate-limit it, and it may not show in development builds. Do not build a custom pop-up to replace it.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `test_log.py`
