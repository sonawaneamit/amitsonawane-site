#!/usr/bin/env python3
"""Channel test log summary. Standard library only.

Input: test_log.csv, one row per test (see the template in examples/).
Columns: test_id, channel, hypothesis, start, end, cost, hours, reach,
clicks, signups, paid, revenue, decision, learning
Computes per test and per channel: cost per signup, cost per paying user
(cost + hours * your hourly value), signup->paid rate, and a suggested call
against your target cost per paying user.

Usage:
  python3 test_log.py test_log.csv --target-cpa 50 [--hourly 40]
"""
import csv, sys
from collections import defaultdict

def f(v):
    try:
        return float(str(v).replace(",", "").replace("$", "") or 0)
    except ValueError:
        return 0.0

def main():
    if len(sys.argv) < 2 or "--target-cpa" not in sys.argv:
        sys.exit(__doc__)
    target = float(sys.argv[sys.argv.index("--target-cpa") + 1])
    hourly = float(sys.argv[sys.argv.index("--hourly") + 1]) if "--hourly" in sys.argv else 0
    rows = list(csv.DictReader(open(sys.argv[1], newline="", encoding="utf-8-sig")))
    ch = defaultdict(lambda: defaultdict(float))
    print(f"{'test':<10}{'channel':<18}{'cost':>8}{'signups':>9}{'paid':>6}{'cost/paid':>11}  call")
    for r in rows:
        cost = f(r["cost"]) + f(r.get("hours")) * hourly
        su, paid = f(r["signups"]), f(r["paid"])
        cpp = cost / paid if paid else None
        call = ("DOUBLE DOWN" if cpp is not None and cpp <= target else
                "ITERATE" if (cpp is not None and cpp <= 2 * target) or (paid == 0 and su >= 10) else "STOP")
        print(f"{r['test_id']:<10}{r['channel'][:17]:<18}{cost:>8.0f}{su:>9.0f}{paid:>6.0f}{(f'{cpp:.0f}' if cpp else '-'):>11}  {call}")
        for k, v in (("cost", cost), ("signups", su), ("paid", paid), ("revenue", f(r.get("revenue"))), ("tests", 1)):
            ch[r["channel"]][k] += v
    print("\nBy channel:")
    for name, t in sorted(ch.items(), key=lambda kv: (kv[1]["cost"] / kv[1]["paid"]) if kv[1]["paid"] else 1e9):
        cpp = t["cost"] / t["paid"] if t["paid"] else None
        conv = t["paid"] / t["signups"] if t["signups"] else 0
        print(f"- {name}: {int(t['tests'])} tests, cost {t['cost']:.0f}, paid {t['paid']:.0f}, cost/paid {cpp:.0f}, signup->paid {conv:.0%}" if cpp else f"- {name}: {int(t['tests'])} tests, cost {t['cost']:.0f}, no paying users yet")

if __name__ == "__main__":
    main()
