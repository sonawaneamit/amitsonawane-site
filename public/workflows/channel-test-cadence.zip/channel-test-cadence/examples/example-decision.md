# Decision (EXAMPLE DATA)

- Forum replies are cheapest per paying user, but limited by hours. Keep at 5 hours a week.
- Cold email is at target and has the best signup-to-paid rate. Go deep: build the 2-van segment and scale sending (see cold-outbound-at-volume).
- Micro creators are under target, driven by one creator. Rebook that creator; test 3 similar ones.
- Paid social is at about 2x target. One change: send ads to the 2-van segment with the deposit angle. Stop if still above 2x after 2 weeks.
