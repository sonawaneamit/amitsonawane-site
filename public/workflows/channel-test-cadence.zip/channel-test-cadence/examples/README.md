# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-test_log.csv`: Four made-up tests.
- `example-test_log-output.txt`: Real script output with target 150 and hourly 40.
- `example-decision.md`: What to do with the output.
