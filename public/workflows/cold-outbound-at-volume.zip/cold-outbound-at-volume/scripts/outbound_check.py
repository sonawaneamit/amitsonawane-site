#!/usr/bin/env python3
"""Cold outbound setup check. Standard library only.

  dns   checks MX, SPF, DMARC and common DKIM selectors for each sending domain
        (DNS-over-HTTPS, so it runs anywhere without dig)
  plan  works out how many sending inboxes and domains a daily volume needs at
        a conservative per-inbox cap, and how long warmup takes

Usage:
  python3 outbound_check.py dns mydomain-mail.com [another-domain.com ...] [--selectors google,selector1]
  python3 outbound_check.py plan --per-day 300 [--cap 30] [--inboxes-per-domain 2] [--warmup-days 21]
"""
import json, math, sys, urllib.request

SELECTORS = ["google", "selector1", "selector2", "default", "k1", "s1", "s2", "mail", "dkim"]

def txt(name, rtype="TXT"):
    url = f"https://dns.google/resolve?name={name}&type={rtype}"
    with urllib.request.urlopen(url, timeout=15) as r:
        ans = json.loads(r.read()).get("Answer", [])
    return [a["data"].replace('" "', "").strip('"') for a in ans]

def dns(domains, selectors):
    for d in domains:
        print(f"\n# {d}")
        mx = txt(d, "MX")
        print(f"- MX: {'ok (' + str(len(mx)) + ' records)' if mx else 'MISSING: replies and bounces will fail'}")
        spf = [t for t in txt(d) if t.lower().startswith("v=spf1")]
        if not spf:
            print("- SPF: MISSING")
        else:
            s = spf[0]
            note = "" if len(spf) == 1 else "  <- more than one SPF record breaks SPF"
            if "+all" in s:
                note += "  <- +all lets anyone send as you"
            print(f"- SPF: {s}{note}")
        dm = [t for t in txt(f"_dmarc.{d}") if t.lower().startswith("v=dmarc1")]
        if not dm:
            print("- DMARC: MISSING (add at least v=DMARC1; p=none; rua=mailto:you@yourdomain)")
        else:
            print(f"- DMARC: {dm[0]}")
        found, empty_sel = [], []
        for sel in selectors:
            recs = [t for t in txt(f"{sel}._domainkey.{d}", "TXT") + txt(f"{sel}._domainkey.{d}", "CNAME") if t]
            if recs:
                empty = all(t.replace(" ", "").rstrip(";").endswith("p=") for t in recs if "p=" in t) and any("p=" in t for t in recs)
                (empty_sel if empty else found).append(sel)
        print(f"- DKIM: {'found for selector(s) ' + ', '.join(found) if found else 'not found on common selectors (check the selector your provider gave you)'}")
        if empty_sel:
            print(f"- DKIM: empty key (p=) on {', '.join(empty_sel)}: revoked or a block-all record, not usable for signing")

def plan(args):
    def opt(n, d):
        return float(args[args.index(n) + 1]) if n in args else d
    per_day, cap = opt("--per-day", 300), opt("--cap", 30)
    ipd, warm = opt("--inboxes-per-domain", 2), opt("--warmup-days", 21)
    inboxes = math.ceil(per_day / cap)
    domains = math.ceil(inboxes / ipd)
    print(f"daily new emails: {int(per_day)} at {int(cap)} per inbox per day")
    print(f"inboxes: {inboxes}, sending domains: {domains} ({int(ipd)} inboxes each)")
    print(f"warmup before full volume: about {int(warm)} days; start each inbox at 5-10 a day and add a few per day")
    print(f"monthly new contacts at full volume (22 working days): {int(per_day * 22):,}")
    print("keep the main company domain out of cold sending; use separate domains that point to your real site")

if __name__ == "__main__":
    a = sys.argv[1:]
    if not a:
        sys.exit(__doc__)
    if a[0] == "dns":
        sels, doms = SELECTORS, []
        rest = a[1:]
        if "--selectors" in rest:
            i = rest.index("--selectors")
            sels = rest[i + 1].split(",")
            rest = rest[:i] + rest[i + 2:]
        dns(rest, sels)
    elif a[0] == "plan":
        plan(a)
    else:
        sys.exit(__doc__)
