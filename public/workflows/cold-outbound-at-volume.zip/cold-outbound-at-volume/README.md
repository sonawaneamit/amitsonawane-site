---
title: "Cold outbound that stays out of spam"
slug: "cold-outbound-at-volume"
theme: "Find and reach customers"
theme_slug: "find-and-reach-customers"
theme_order: 4
order: 13
summary: "Set up separate sending domains, authenticate and warm them, write short signal-based emails, send at low per-inbox caps, and run a weekly review on replies, bounces and complaints, inside the law."
---

# Cold outbound that stays out of spam

Set up separate sending domains, authenticate and warm them, write short signal-based emails, send at low per-inbox caps, and run a weekly review on replies, bounces and complaints, inside the law.

| | |
|---|---|
| Theme | Find and reach customers |
| Time | 1 day to set up, 3 weeks of warmup, then 1 hour a week |
| Works with | Any agent with web and DNS access. Any sending tool that supports multiple inboxes, throttling and unsubscribe links. |
| You get | Authenticated sending domains, a capacity plan, a 3-step sequence, a compliance checklist and a weekly scorecard |

## When to use it

- You have a scored lead list with real signals (see lead-sourcing-enrichment).
- You want 100 to a few thousand new conversations a month by email.
- Your current cold emails land in spam or get no replies.

## What you get

- A capacity plan: inboxes, domains, warmup time.
- DNS checks passing for every sending domain.
- A 3-step sequence with a personal first line per lead.
- A compliance checklist and a weekly scorecard with stop rules.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Lead list | leads_scored.csv, tier A | Yes |
| Offer | One clear thing you can do for them | Yes |
| Daily volume goal | 300 new emails a day | Yes |
| Business postal address | For the footer | Yes |
| Sending tool | Any with throttling and unsubscribe | Yes |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Plan capacity.** Volume / per-inbox cap = inboxes; 2-3 inboxes per domain.
2. **Set up domains.** Separate domains, SPF, DKIM, DMARC, MX, redirect to the real site.
3. **Warm up.** About 3 weeks, small daily volume growing slowly.
4. **Write the sequence.** 3 short emails, one ask, signal-led first line.
5. **Launch small.** One segment, 50-100 leads, read results.
6. **Weekly review.** Replies, bounces, complaints; stop rules.

## Copy-paste prompts

### 1. Plan and set up

Start here.

```text
Use the cold-outbound-at-volume skill.
Daily volume goal: {{n}}. Main domain: {{domain}}. Sending tool: {{tool}}. Markets: {{countries}}.
Make the capacity plan, propose sending domain names, list the DNS records each needs, and run the dns check once they exist. List every compliance item for my markets. Wait for my OK before buying domains or changing DNS.
```

### 2. Write the sequence

After warmup starts.

```text
Use the cold-outbound-at-volume skill.
Segment: {{segment}}. Offer: {{offer}}. Proof I can mention: {{facts only}}.
Postal address: {{address}}.
Write the 3-email sequence and 3 versions of the first line using the signal column from {{attached rows}}. Follow every rule in step 4, then run the writing-cleanup-pass skill on it.
```

### 3. Weekly review

Every week.

```text
Here are this week's numbers by domain, inbox, segment and email version: {{paste or attach}}.
Fill the scorecard, apply the stop rules, and tell me the one change to make next week and why. List any inbox or domain to pause.
```

### 4. Reply handling

For each positive or unclear reply.

```text
Lead: {{row}}. Their reply: {{paste}}. My calendar link: {{link}}.
Draft a short answer that addresses exactly what they asked, offers one next step, and does not repeat the pitch. If they asked to stop, write the suppression note instead.
```

## Scoring rubric

**Weekly scorecard**

| Metric | Healthy | Stop rule |
|---|---|---|
| Bounce rate | under 2% | above 3%: pause inbox, clean list |
| Spam complaint rate | under 0.1% | above 0.3%: pause domain |
| Reply rate | 3%+ is a usual starting target | under 1% after 300 sends: change segment or offer |
| Positive replies | rising | 0 after 300 sends: rethink offer |
| Unsubscribes processed | 100% within 2 days | any missed: fix before sending more |

Targets are starting points, not guarantees. Compare your own weeks.

**Pre-send checklist**: DNS passes, warmup done, footer has postal address and unsubscribe, subject is honest, first line uses a real signal, suppression list loaded.

## Templates

**Email 1**

```text
Subject: {{2-5 word subject}}

Hi {{first name}},

{{signal line: what you saw and when}}. {{one sentence on the problem it usually brings}}.

We {{offer in one line, with one fact}}.

Worth a look for {{company}}?

{{name}}
{{company}}, {{postal address}}
Not relevant? {{one-click unsubscribe link}}
```

**DNS records to add per sending domain**

| Type | Host | Value |
|---|---|---|
| MX | @ | your provider's mail servers |
| TXT | @ | v=spf1 include:{{provider}} ~all |
| TXT or CNAME | {{selector}}._domainkey | from your provider |
| TXT | _dmarc | v=DMARC1; p=none; rua=mailto:dmarc@{{domain}} |

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`outbound_check.py` has two modes.

```bash
python3 scripts/outbound_check.py plan --per-day 300 --cap 30 --inboxes-per-domain 2
python3 scripts/outbound_check.py dns getexample.com examplehq.com --selectors google,s1
```

`dns` uses a public DNS-over-HTTPS resolver. It checks MX, SPF (and flags multiple records or `+all`), DMARC, and DKIM on common selectors plus any you pass. Pass the selector your provider gave you; common ones are only a guess.

## Example files

Invented data that shows the format of each input and output.

- `examples/example-plan-output.txt`: Real output of the plan mode.
- `examples/example-dns-output.txt`: Real output of `dns example.com --selectors google`. example.com is a reserved domain that publishes block-all records.
- `examples/example-sequence.md`: A 3-email sequence for a made-up booking app.
- `examples/example-scorecard.md`: A filled weekly scorecard.

## Troubleshooting and tips

- **Everything lands in spam.** Check DNS with the script, slow down, remove links and images, and make sure warmup ran for 2+ weeks.
- **High bounces.** The list is stale or emails were guessed. Verify mailboxes before sending; never guess addresses.
- **Replies are angry.** The segment or reason is wrong. Narrow the ICP and use stronger signals.
- **Lots of opens, no replies.** Open tracking is unreliable (privacy features load images). Judge by replies only.
- **Want to go faster.** Add inboxes and domains, warmed, rather than raising per-inbox caps.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `outbound_check.py`
