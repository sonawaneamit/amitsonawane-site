---
title: "Cold outbound that stays out of spam: prompts"
slug: "cold-outbound-at-volume-prompts"
theme: "Find and reach customers"
type: "prompts"
---

# Cold outbound that stays out of spam: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Plan and set up

Start here.

```text
Use the cold-outbound-at-volume skill.
Daily volume goal: {{n}}. Main domain: {{domain}}. Sending tool: {{tool}}. Markets: {{countries}}.
Make the capacity plan, propose sending domain names, list the DNS records each needs, and run the dns check once they exist. List every compliance item for my markets. Wait for my OK before buying domains or changing DNS.
```

## 2. Write the sequence

After warmup starts.

```text
Use the cold-outbound-at-volume skill.
Segment: {{segment}}. Offer: {{offer}}. Proof I can mention: {{facts only}}.
Postal address: {{address}}.
Write the 3-email sequence and 3 versions of the first line using the signal column from {{attached rows}}. Follow every rule in step 4, then run the writing-cleanup-pass skill on it.
```

## 3. Weekly review

Every week.

```text
Here are this week's numbers by domain, inbox, segment and email version: {{paste or attach}}.
Fill the scorecard, apply the stop rules, and tell me the one change to make next week and why. List any inbox or domain to pause.
```

## 4. Reply handling

For each positive or unclear reply.

```text
Lead: {{row}}. Their reply: {{paste}}. My calendar link: {{link}}.
Draft a short answer that addresses exactly what they asked, offers one next step, and does not repeat the pitch. If they asked to stop, write the suppression note instead.
```
