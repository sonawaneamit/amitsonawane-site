# Sequence: mobile groomers hiring (EXAMPLE DATA)

## Email 1 (day 0)
Subject: second groomer

Hi Ana,

Saw Paws on Wheels is hiring a second groomer. Splitting one phone and one paper diary across two vans is usually where double bookings start.

We give each van its own booking link and calendar, and clients pay a deposit when they book.

Worth a look for Paws on Wheels?

Sam
Example Booking, 100 Example St, Springfield
Not relevant? Unsubscribe in one click: {{link}}

## Email 2 (day 3, same thread)
One more thing: groomers on two vans tell us the deposit alone cut their no-shows. Happy to send a 2-minute video of the setup if useful.

## Email 3 (day 7, same thread)
Should I close this out? A one-word reply either way is fine.
