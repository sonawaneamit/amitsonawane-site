# Week 3 (EXAMPLE DATA)

| Domain | Sent | Bounce | Complaints | Replies | Positive |
|---|---|---|---|---|---|
| getexample.com | 600 | 1.2% | 0 | 4.1% | 1.3% |
| examplehq.com | 600 | 3.4% | 1 | 2.0% | 0.5% |

Actions: pause examplehq.com inbox 2 (bounce above 3%), verify the segment it used. Next week's single change: test the "second van" first line on the vet clinic segment.
