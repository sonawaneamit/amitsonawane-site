# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-plan-output.txt`: Real output of the plan mode.
- `example-dns-output.txt`: Real output of `dns example.com --selectors google`. example.com is a reserved domain that publishes block-all records.
- `example-sequence.md`: A 3-email sequence for a made-up booking app.
- `example-scorecard.md`: A filled weekly scorecard.
