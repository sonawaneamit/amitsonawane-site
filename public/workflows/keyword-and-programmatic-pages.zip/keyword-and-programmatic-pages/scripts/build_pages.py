#!/usr/bin/env python3
"""Programmatic page builder. Standard library only.

Fills a markdown template once per CSV row and writes one file per row.
Template placeholders look like {{column_name}}. Rows missing any column the
template uses are skipped and listed, so thin pages never get published.

Slug: a "slug" column if present, otherwise the first placeholder in the template.

Usage:
  python3 build_pages.py data.csv template.md out_dir [--min-words 300]
"""
import csv, os, re, sys

def slugify(s):
    s = re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")
    return s[:80] or "page"

def main():
    if len(sys.argv) < 4:
        sys.exit(__doc__)
    data, tpl_path, out = sys.argv[1:4]
    min_words = int(sys.argv[sys.argv.index("--min-words") + 1]) if "--min-words" in sys.argv else 300
    tpl = open(tpl_path, encoding="utf-8").read()
    fields = list(dict.fromkeys(re.findall(r"{{\s*(\w+)\s*}}", tpl)))  # template order
    os.makedirs(out, exist_ok=True)
    made, skipped, thin, seen = 0, [], [], set()
    with open(data, newline="", encoding="utf-8") as f:
        for n, row in enumerate(csv.DictReader(f), start=2):
            missing = [k for k in fields if not (row.get(k) or "").strip()]
            if missing:
                skipped.append(f"line {n}: missing {', '.join(missing)}"); continue
            page = re.sub(r"{{\s*(\w+)\s*}}", lambda m: row[m.group(1)].strip(), tpl)
            slug = slugify(row.get("slug") or row[fields[0]])
            if slug in seen:
                skipped.append(f"line {n}: duplicate slug {slug}"); continue
            seen.add(slug)
            words = len(re.sub(r"[#>*_`\-|]", " ", page).split())
            if words < min_words:
                thin.append(f"{slug} ({words} words)")
            with open(os.path.join(out, slug + ".md"), "w", encoding="utf-8") as g:
                g.write(page)
            made += 1
    print(f"built {made} pages in {out}/")
    for s in skipped:
        print("SKIPPED", s)
    for t in thin:
        print("THIN (add unique data before publishing):", t)

if __name__ == "__main__":
    main()
