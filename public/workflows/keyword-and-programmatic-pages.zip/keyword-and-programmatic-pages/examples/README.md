# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-keywords.csv`: Scored keyword candidates.
- `example-data.csv`: Data sheet rows for the city template (the Denver row will be skipped).
- `example-build-log.txt`: What build_pages.py prints for that data.
