---
title: "Keyword and programmatic pages: prompts"
slug: "keyword-and-programmatic-pages-prompts"
theme: "Get found in search and AI answers"
type: "prompts"
---

# Keyword and programmatic pages: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the full workflow

Paste with the skill loaded.

```text
Use the keyword-and-programmatic-pages skill.

Product or idea: {{product}}
Seeds: {{seed terms}}
Market: {{country}}, {{language}}
Keyword tool export: {{attached or "none"}}
Data I have: {{dataset or "none yet"}}

Expand and score keywords, then show me 3 candidate clusters with your pick before you design any page.
```

## 2. Score a keyword export

Attach an export from any keyword tool.

```text
Here is a keyword export with difficulty and volume: {{paste or attach}}.
Product: {{product}}.

Group keywords into clusters around a main keyword. For each cluster: main keyword, difficulty, volume, number of children, total child volume, intent match (1-5), and a note on why it is or is not winnable.
Rank clusters by (total volume x intent match) / (difficulty + 10). Recommend one in 3 lines.
```

## 3. Design the page template

After picking a cluster.

```text
Main keyword: {{keyword}}. Page type: one page per {{entity}}. Example searches: {{5 child keywords}}.

Look at the current top 5 results for 2 of those searches. Then write template.md with {{column}} placeholders: title, meta description, H1, first-screen answer, unique-data block, entity-specific section, FAQ (3 questions), links to hub and siblings, call to action.
List every column data.csv needs, with the source I should use for each.
```

## 4. Fill the data sheet

When the agent can research entities.

```text
Fill data.csv for these entities: {{list}}. Columns: {{columns}}.
Use only sources you can cite and add a source_url per row. Leave a cell empty if you cannot verify it. Do not estimate.
```

## 5. Quality review

After generating pages.

```text
Read 10 random pages in pages/. Score each 1-5 on: answers the search in the first screen, unique data, entity-specific content, and whether a searcher would prefer it to the current top result.
List pages that read like copies of each other and the data that would make them different.
```
