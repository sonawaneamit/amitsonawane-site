---
title: "Keyword and programmatic pages"
slug: "keyword-and-programmatic-pages"
theme: "Get found in search and AI answers"
theme_slug: "search-and-ai-answers"
theme_order: 1
order: 2
summary: "Pick a low-competition keyword with many long-tail variants, build the product or page set around it, and generate one genuinely useful page per entity from your own data."
---

# Keyword and programmatic pages

Pick a low-competition keyword with many long-tail variants, build the product or page set around it, and generate one genuinely useful page per entity from your own data.

| | |
|---|---|
| Theme | Get found in search and AI answers |
| Time | 1 to 2 days to research and build, then 3 to 6 months for search traffic |
| Works with | Any agent with web access. A keyword tool helps; the bundled scripts cover autocomplete research and page generation. |
| You get | A chosen keyword cluster, a page template, a data sheet, generated pages and a launch checklist |

## When to use it

- You are choosing a niche, domain or first pages for a new product.
- You have a dataset (places, tools, templates, integrations, prices) that maps to many searches.
- Your site gets little search traffic and you need a plan that does not depend on followers.

## What you get

- `keywords.csv`: seed and long-tail keywords with difficulty, volume and intent where available.
- `cluster.md`: the chosen main keyword, its children, and the page types to build.
- `template.md` and `data.csv`: one page template and one row of real data per page.
- `pages/`: generated pages, with a list of pages too thin to publish.
- `launch.md`: indexing, linking and first-backlink checklist.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Product or idea | Booking app for mobile groomers | Yes |
| Seed terms | groomer booking, mobile grooming, dog grooming prices | Yes |
| Keyword tool access | Any tool with difficulty scores, or none | Optional |
| Data you own or can gather | Prices by city from public listings | For programmatic pages |
| Market | US, English | Default |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Expand seeds.** Autocomplete, related searches, questions, competitors' page titles.
2. **Score keywords.** Difficulty, volume, number of child keywords, buyer intent.
3. **Pick one cluster.** A main keyword you can rank for within months, with many long-tail children.
4. **Design the page type.** One template per entity, with a unique-data block on every page.
5. **Build the data sheet.** One row per page from data you own or can verify.
6. **Generate and gate.** Build pages, skip rows with missing data, flag thin pages.
7. **Launch.** Hub pages, internal links, sitemap, submit for indexing, first backlinks.

## Copy-paste prompts

### 1. Run the full workflow

Paste with the skill loaded.

```text
Use the keyword-and-programmatic-pages skill.

Product or idea: {{product}}
Seeds: {{seed terms}}
Market: {{country}}, {{language}}
Keyword tool export: {{attached or "none"}}
Data I have: {{dataset or "none yet"}}

Expand and score keywords, then show me 3 candidate clusters with your pick before you design any page.
```

### 2. Score a keyword export

Attach an export from any keyword tool.

```text
Here is a keyword export with difficulty and volume: {{paste or attach}}.
Product: {{product}}.

Group keywords into clusters around a main keyword. For each cluster: main keyword, difficulty, volume, number of children, total child volume, intent match (1-5), and a note on why it is or is not winnable.
Rank clusters by (total volume x intent match) / (difficulty + 10). Recommend one in 3 lines.
```

### 3. Design the page template

After picking a cluster.

```text
Main keyword: {{keyword}}. Page type: one page per {{entity}}. Example searches: {{5 child keywords}}.

Look at the current top 5 results for 2 of those searches. Then write template.md with {{column}} placeholders: title, meta description, H1, first-screen answer, unique-data block, entity-specific section, FAQ (3 questions), links to hub and siblings, call to action.
List every column data.csv needs, with the source I should use for each.
```

### 4. Fill the data sheet

When the agent can research entities.

```text
Fill data.csv for these entities: {{list}}. Columns: {{columns}}.
Use only sources you can cite and add a source_url per row. Leave a cell empty if you cannot verify it. Do not estimate.
```

### 5. Quality review

After generating pages.

```text
Read 10 random pages in pages/. Score each 1-5 on: answers the search in the first screen, unique data, entity-specific content, and whether a searcher would prefer it to the current top result.
List pages that read like copies of each other and the data that would make them different.
```

## Scoring rubric

**Cluster score** = (monthly volume of main + children) x intent match (1-5) / (difficulty + 10)

| Check | Good | Bad |
|---|---|---|
| Difficulty (0-100 tool scale) | under 20 | over 40 for a new site |
| Child keywords | 50+ | under 10 |
| Top 10 today | forums, thin pages, old posts | big brands with exact-match pages |
| Intent | searcher wants what you sell | learning only |

**Page gate:** publish only when every placeholder is filled from a source, the page has 300+ words with a unique-data block, and it beats the current top result for the searcher.

## Templates

**template.md (city page example)**

```markdown
---
title: "Mobile dog grooming in {{city}}: prices and booking ({{year}})"
description: "Typical mobile grooming prices in {{city}}, {{state}}, from {{listing_count}} local listings."
---
# Mobile dog grooming in {{city}}, {{state}}

Typical price for a full groom: **{{median_price}}** (range {{price_low}} to {{price_high}}), from {{listing_count}} public listings checked {{checked_date}}.

## Prices by dog size
{{size_price_table}}

## What is different in {{city}}
{{local_notes}}

## Nearby
{{sibling_links}}

[Book a mobile groomer in {{city}}]({{cta_url}})
```

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`keyword_suggest.py` expands seeds through search autocomplete (modes: alphabet, questions, compare, reviews) into `suggestions.csv`. The endpoint is unofficial; keep runs small.

```bash
python3 scripts/keyword_suggest.py "groomer booking app" "mobile dog grooming" --mode alphabet --country us
python3 scripts/keyword_suggest.py "mobile dog grooming" --mode questions
```

`build_pages.py` fills a markdown template once per CSV row, skips rows with missing data, and flags thin pages. The file name comes from a `slug` column, or the first placeholder in the template.

```bash
python3 scripts/build_pages.py data.csv template.md pages --min-words 300
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-keywords.csv`: Scored keyword candidates.
- `examples/example-data.csv`: Data sheet rows for the city template (the Denver row will be skipped).
- `examples/example-build-log.txt`: What build_pages.py prints for that data.

## Troubleshooting and tips

- **Every keyword looks too hard.** Go longer: add who, where, size, price or use case. Forums and thin pages in the top 10 mean a well-made page can win.
- **Pages are not getting indexed.** Publish smaller batches, link every page from a hub, add unique data, and check the page indexing report in Search Console.
- **No keyword tool.** Use autocomplete for variants, Search Console for what you already rank for, and the results page to judge difficulty.
- **Thin pages.** Drop them. Fifty strong pages beat five hundred thin ones.
- **Traffic but no signups.** The cluster has learning intent. Add a tool or calculator to the page, or pick a cluster closer to buying.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `keyword_suggest.py`, `build_pages.py`
