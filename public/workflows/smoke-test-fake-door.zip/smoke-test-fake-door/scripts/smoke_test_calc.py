#!/usr/bin/env python3
"""Smoke-test scorecard. Standard library only.

Give it the numbers from each variant of a fake-door or pre-sell test and the
pass line you wrote down before launch. It reports the conversion rate with a
95% range (Wilson interval) and a call: PASS, KILL or KEEP RUNNING.

Rules:
  PASS          the low end of the range is at or above your pass line
  KILL          the high end of the range is below your kill line
  KEEP RUNNING  anything else (not enough data yet)

Usage:
  python3 smoke_test_calc.py --pass 0.05 --kill 0.01 "Promise A:400:31" "Promise B:380:9"
  (each variant is "name:visitors:conversions"; conversions can be signups or deposits)
"""
import math, sys

def wilson(k, n, z=1.96):
    if n == 0:
        return 0.0, 0.0
    p = k / n
    d = 1 + z * z / n
    c = p + z * z / (2 * n)
    m = z * math.sqrt(p * (1 - p) / n + z * z / (4 * n * n))
    return (c - m) / d, (c + m) / d

def main():
    args = sys.argv[1:]
    if "--pass" not in args or "--kill" not in args:
        sys.exit(__doc__)
    pass_line = float(args[args.index("--pass") + 1])
    kill_line = float(args[args.index("--kill") + 1])
    variants = [a for a in args if a.count(":") == 2]
    print(f"pass line {pass_line:.1%}, kill line {kill_line:.1%}\n")
    print(f"{'variant':<24}{'visitors':>9}{'conv':>6}{'rate':>8}   95% range        call")
    for v in variants:
        name, n, k = v.rsplit(":", 2)
        n, k = int(n), int(k)
        lo, hi = wilson(k, n)
        call = "PASS" if lo >= pass_line else "KILL" if hi < kill_line else "KEEP RUNNING"
        rate = k / n if n else 0
        print(f"{name:<24}{n:>9}{k:>6}{rate:>8.1%}   {lo:>6.1%} - {hi:<6.1%}   {call}")


if __name__ == "__main__":
    main()
