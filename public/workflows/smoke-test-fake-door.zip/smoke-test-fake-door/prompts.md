---
title: "Smoke test with a fake door and payment link: prompts"
slug: "smoke-test-fake-door-prompts"
theme: "Validate before you build"
type: "prompts"
---

# Smoke test with a fake door and payment link: copy-paste prompts

Load SKILL.md into your agent first (see README.md). Replace every `{{placeholder}}` before you send.

## 1. Run the whole smoke test setup

Paste with the skill file loaded.

```text
Use the smoke-test-fake-door skill.

Promises:
1. {{promise 1}}
2. {{promise 2}}
Audience: {{audience}}
Price idea: {{price}} (deposit: {{deposit amount}})
Traffic: {{daily short videos on which platforms}} + {{ad budget per day or none}}
Test length: {{days}} days
Page tool: {{tool or "single HTML file"}}

Write test-plan.md first and show me the pass and kill lines before anything else. Then write landing-page.md per promise, mockups.md and content-calendar.md.
```

## 2. Mockup briefs

Use when you need images of a product that does not exist yet.

```text
Write briefs for 4 mobile screens that sell this promise: {{promise}}.

For each screen: name, the one thing the viewer should understand in 2 seconds, every element on the screen top to bottom, the exact text and numbers shown (realistic but clearly sample data), and the visual style ({{style or "clean, light, one accent color"}}).

Screen 1 is the result the promise names. Screen 2 is the one action that gets there. No settings, no login.
If you can generate images, generate them at 1080x1920.
```

## 3. Landing page copy

One page per promise.

```text
Write a landing page for this promise: {{promise}}
Audience: {{audience}}
Customer quotes to use: {{3-5 quotes}}
Offer: {{waitlist | refundable deposit of $X, refund date}}

Structure: headline (10 words max), subheadline, mockup placeholder, 3 bullets built from the quotes, the offer stated plainly, one button, FAQ (launch date, what happens to my deposit, refunds).
Under 300 words. Plain words a 12-year-old understands. No fake numbers, testimonials or logos. Say clearly that it is early access.
```

## 4. 14 days of short videos

Run once per promise.

```text
Write 14 short video scripts (15-40 seconds) for this promise: {{promise}}.
Audience: {{audience}}. Pains and quotes: {{paste top pains and quotes}}.

Keep one format every day: {{format, e.g. "problem in 2 seconds -> mockup on screen -> link in bio"}}.
Mix: 6 problem hooks, 4 result hooks, 2 "I'm building this, should I?", 2 answers to comments (invent plausible comment prompts, label them as examples).

For each: day, hook type, first spoken line, on-screen text, shot list (3-5 shots), call to action. Never say the product exists. Say "I'm building" or "early access".
```

## 5. Read the results

At the end of the test. Paste results.md.

```text
Here is results.md and test-plan.md.

For each promise: visitors, signups, deposits, conversion rate with a 95% range, and the call (PASS, KILL or KEEP RUNNING) against the lines in test-plan.md. Do not move the lines.
Then: which hook drove the most page visits, what people asked in comments, and the next 3 actions for each promise.
```
