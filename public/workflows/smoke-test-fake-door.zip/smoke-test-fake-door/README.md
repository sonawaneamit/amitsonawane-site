---
title: "Smoke test with a fake door and payment link"
slug: "smoke-test-fake-door"
theme: "Validate before you build"
theme_slug: "validate-before-you-build"
theme_order: 3
order: 10
summary: "Put a promise in front of real people before you build: a mockup, a one-page offer, daily short videos and a way to sign up or pay a deposit. Let the numbers pick the idea."
---

# Smoke test with a fake door and payment link

Put a promise in front of real people before you build: a mockup, a one-page offer, daily short videos and a way to sign up or pay a deposit. Let the numbers pick the idea.

| | |
|---|---|
| Theme | Validate before you build |
| Time | 2 hours to set up, then 7 to 21 days of daily posting |
| Works with | Any agent for copy, mockups and scripts. You publish the page and the videos. |
| You get | A live test page, 14+ video scripts, a pass/kill call per idea backed by numbers |

## When to use it

- You have 1 to 5 promises and want to know which one people will act on.
- You want to know whether people will pay before you write code.
- You can post short videos or run a small ad budget for 1 to 3 weeks.

## What you get

- `test-plan.md`: promise, audience, traffic plan, pass and kill lines, written before launch.
- `landing-page.md`: copy for a one-page offer with a waitlist or deposit button.
- `mockups.md`: briefs (or generated images) for 3 to 5 screens that show the product.
- `content-calendar.md`: 14 short video scripts with hooks, one per day.
- `results.md`: daily numbers and the final call per idea.

## Inputs

| Input | Example | Needed |
|---|---|---|
| Promises | 2 promises from pain-point mining | Yes |
| Audience | Solo mobile dog groomers in the US | Yes |
| Price idea | $19/month, early-bird deposit $10 | Yes |
| Traffic | Daily short videos + $10/day ads | Yes |
| Page tool | Any landing page builder or a single HTML file | Optional |

## How to run it

1. Load `SKILL.md` into your agent (paste it, attach it, or save it in your agent's skills folder).
2. Paste prompt 1 below with your placeholders filled in.
3. Answer the agent's questions, then review each output file before you act on it.

What the agent does:

1. **Write the test plan.** Promise, audience, traffic source, pass and kill lines. Written before anything goes live.
2. **Make the mockup.** 3 to 5 screens that show the result, not the settings. Generated images or quick design-tool frames.
3. **Write the page.** One page, one promise, one button: waitlist or refundable deposit.
4. **Set up the door.** Signup form or payment link, a thank-you page that tells the truth, and tracking for visits and clicks.
5. **Write 14 days of content.** Short videos that show the problem and the mockup. Same format, new hook each day.
6. **Run and log.** Post daily, log views, visits, clicks, signups and deposits.
7. **Call it.** Pass, kill or keep running, per idea, against the lines you set.

## Copy-paste prompts

### 1. Run the whole smoke test setup

Paste with the skill file loaded.

```text
Use the smoke-test-fake-door skill.

Promises:
1. {{promise 1}}
2. {{promise 2}}
Audience: {{audience}}
Price idea: {{price}} (deposit: {{deposit amount}})
Traffic: {{daily short videos on which platforms}} + {{ad budget per day or none}}
Test length: {{days}} days
Page tool: {{tool or "single HTML file"}}

Write test-plan.md first and show me the pass and kill lines before anything else. Then write landing-page.md per promise, mockups.md and content-calendar.md.
```

### 2. Mockup briefs

Use when you need images of a product that does not exist yet.

```text
Write briefs for 4 mobile screens that sell this promise: {{promise}}.

For each screen: name, the one thing the viewer should understand in 2 seconds, every element on the screen top to bottom, the exact text and numbers shown (realistic but clearly sample data), and the visual style ({{style or "clean, light, one accent color"}}).

Screen 1 is the result the promise names. Screen 2 is the one action that gets there. No settings, no login.
If you can generate images, generate them at 1080x1920.
```

### 3. Landing page copy

One page per promise.

```text
Write a landing page for this promise: {{promise}}
Audience: {{audience}}
Customer quotes to use: {{3-5 quotes}}
Offer: {{waitlist | refundable deposit of $X, refund date}}

Structure: headline (10 words max), subheadline, mockup placeholder, 3 bullets built from the quotes, the offer stated plainly, one button, FAQ (launch date, what happens to my deposit, refunds).
Under 300 words. Plain words a 12-year-old understands. No fake numbers, testimonials or logos. Say clearly that it is early access.
```

### 4. 14 days of short videos

Run once per promise.

```text
Write 14 short video scripts (15-40 seconds) for this promise: {{promise}}.
Audience: {{audience}}. Pains and quotes: {{paste top pains and quotes}}.

Keep one format every day: {{format, e.g. "problem in 2 seconds -> mockup on screen -> link in bio"}}.
Mix: 6 problem hooks, 4 result hooks, 2 "I'm building this, should I?", 2 answers to comments (invent plausible comment prompts, label them as examples).

For each: day, hook type, first spoken line, on-screen text, shot list (3-5 shots), call to action. Never say the product exists. Say "I'm building" or "early access".
```

### 5. Read the results

At the end of the test. Paste results.md.

```text
Here is results.md and test-plan.md.

For each promise: visitors, signups, deposits, conversion rate with a 95% range, and the call (PASS, KILL or KEEP RUNNING) against the lines in test-plan.md. Do not move the lines.
Then: which hook drove the most page visits, what people asked in comments, and the next 3 actions for each promise.
```

## Scoring rubric

Set these lines in `test-plan.md` before launch. Starting points for cold traffic:

| Action | Pass | Kill |
|---|---|---|
| Waitlist signup | 5%+ of visitors | under 1% |
| Refundable deposit | 1%+ of visitors, or 10+ deposits | 0 deposits after 300 visitors |
| Button click (any) | 10%+ of visitors | under 3% |

- Call PASS only when the low end of the 95% range clears the pass line.
- Call KILL only when the high end of the range is below the kill line.
- Views and likes are hook signals. Only page actions count as demand.

## Templates

**Test plan row**

```text
Promise ID: P1
Promise: {{one line}}
Audience: {{who}}
Traffic: {{source}}, {{posts per day}} posts/day, {{budget}}/day ads
Action: {{waitlist | deposit $X}}
Pass line: {{x}}% of visitors (min 300 visitors)
Kill line: {{y}}% of visitors
Dates: {{start}} to {{end}}
```

**Thank-you page (deposit)**

```text
You're in. Thanks for reserving early access.
{{product}} is in development. We expect to open it to deposit holders by {{date}}.
Your ${{amount}} deposit comes off your first payment. If we do not launch by {{date}}, we refund it in full, automatically.
Questions or want a refund now? Reply to your receipt email.
```

**Daily log row (results.md)**

`| date | promise | posts | views | page visits | clicks | signups | deposits | ad spend | notes |`

## Scripts

Python 3, standard library only. No installs. Run them yourself or let your agent run them.

`smoke_test_calc.py` turns visitors and conversions into a rate with a 95% range and a PASS / KILL / KEEP RUNNING call.

```bash
python3 scripts/smoke_test_calc.py --pass 0.05 --kill 0.01 "P1 deposits+reminders:400:31" "P2 route plan:380:9"
```

## Example files

Invented data that shows the format of each input and output.

- `examples/example-test-plan.md`: A locked test plan for two promises.
- `examples/example-landing-page.md`: Landing page copy for P1.
- `examples/example-content-calendar.md`: The first 4 of 14 daily video scripts.
- `examples/example-results.md`: Daily log totals and the final call.

## Troubleshooting and tips

- **Lots of views, no page visits.** The hook works and the link path does not. Put the link where the platform allows, say it out loud in the video, and make the page load in under 2 seconds on a phone.
- **Visits but no clicks.** The page does not match the video. Use the same words and the same mockup the video showed.
- **Clicks but no deposits.** The price or trust is off. Make the refund terms bigger and clearer, or test the waitlist as a second step.
- **Not enough traffic to call it.** Add a small ad budget pointed at the page, or extend once by 7 days. Do not lower the pass line.
- **Testing many ideas at once.** Keep the format, budget and posting time identical across ideas so only the promise differs.
- **A promise passes.** Talk to the people who paid before you build. They tell you what the first version must do.

## Files in this folder

- `SKILL.md`: the skill file your agent follows
- `prompts.md`: the prompts above, on their own
- `examples/`: example inputs and outputs
- `scripts/`: `smoke_test_calc.py`
