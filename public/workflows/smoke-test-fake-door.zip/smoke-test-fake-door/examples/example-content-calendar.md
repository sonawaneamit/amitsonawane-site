# Content calendar: P1 (EXAMPLE DATA)
Format every day: problem in 2 seconds -> mockup on screen -> "early access, link in bio".

| Day | Hook type | First spoken line | On-screen text | CTA |
|---|---|---|---|---|
| 1 | Problem | "I drove 40 minutes to a house where nobody answered." | No-show #3 this month | Early access, link in bio |
| 2 | Result | "This is what a booking looks like when the client already paid." | $15 deposit: paid | Reserve a spot |
| 3 | Building | "I'm building a booking app for mobile groomers. Should deposits be required?" | Yes or no? | Comment below |
| 4 | Problem | "How do you ask a client for a deposit without sounding rude?" | You don't. The app does. | Link in bio |
