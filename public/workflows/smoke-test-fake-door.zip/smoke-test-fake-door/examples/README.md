# Examples

Everything in this folder is EXAMPLE DATA, invented to show the format. Replace it with your own.

- `example-test-plan.md`: A locked test plan for two promises.
- `example-landing-page.md`: Landing page copy for P1.
- `example-content-calendar.md`: The first 4 of 14 daily video scripts.
- `example-results.md`: Daily log totals and the final call.
