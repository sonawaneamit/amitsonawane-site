# Results (EXAMPLE DATA)

| Promise | Visitors | Clicks | Deposits | Rate | 95% range | Call |
|---|---|---|---|---|---|---|
| P1 deposits | 400 | 88 | 31 | 7.8% | 5.5% - 10.8% | PASS |
| P2 route plan | 380 | 41 | 9 | 2.4% | 1.3% - 4.4% | KEEP RUNNING (7 more days) |

Best hook: day 1 "I drove 40 minutes..." drove 34% of P1 visits.
Comments: 11 people asked whether clients can pay by card at the door.
Next for P1: email all 31 depositors, book 5 calls, scope the build.
