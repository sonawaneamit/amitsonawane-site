# Test plan (EXAMPLE DATA)
Written 1 Oct. Not edited after launch.

| ID | Promise | Action | Traffic | Pass | Kill | Dates |
|---|---|---|---|---|---|---|
| P1 | A booking link that takes a deposit up front, so you never drive 40 minutes for nothing again | $10 refundable deposit | 2 short videos/day + $10/day ads | 1% of visitors or 10 deposits | 0 deposits after 300 visitors | 1-21 Oct |
| P2 | A weekly route built from your bookings in one click | $10 refundable deposit | same | same | same | 1-21 Oct |

Minimum sample: 300 visitors per promise.
