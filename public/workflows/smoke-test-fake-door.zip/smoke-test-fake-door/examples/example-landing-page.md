# Landing page: P1 (EXAMPLE DATA)

**Stop driving to no-shows.**

Booking for solo mobile groomers that takes a deposit when the client books. Set it up in 5 minutes.

[mockup: booking confirmation screen showing "$15 deposit paid"]

- "Third no-show this month." Clients pay a small deposit when they book, so they show up.
- "I hate chasing people for money." The app asks for you. You never send an awkward text.
- "Too expensive for a one-person business." One plan, $19 a month, no add-ons.

**Reserve early access: $10 deposit, taken off your first month. Full refund if we do not launch by 15 January.**

[Reserve my spot]

FAQ
- When does it launch? We are building it now. Deposit holders get access first, by 15 January.
- What happens to my deposit? It comes off your first payment.
- Can I get a refund? Yes, any time before launch. Reply to your receipt email.
